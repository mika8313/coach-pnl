/**
 * Pruebas unitarias para el servicio de autenticación
 */
const AuthService = require('../../src/services/AuthService');
const SecurityService = require('../../src/services/SecurityService');
const User = require('../../src/models/User');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Mock de dependencias
jest.mock('../../src/models/User');
jest.mock('bcryptjs');
jest.mock('jsonwebtoken');
jest.mock('../../src/services/SecurityService');

describe('AuthService', () => {
  beforeEach(() => {
    // Limpiar todos los mocks antes de cada prueba
    jest.clearAllMocks();
  });

  describe('register', () => {
    it('debe registrar un nuevo usuario correctamente', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'hashedPassword123',
        save: jest.fn().mockResolvedValue(true)
      };
      
      User.findOne.mockResolvedValue(null); // Usuario no existe
      User.mockImplementation(() => mockUser);
      SecurityService.hashPassword.mockResolvedValue('hashedPassword123');
      SecurityService.generateToken.mockReturnValue('token123');
      
      // Ejecutar función a probar
      const result = await AuthService.register({
        name: 'Test User',
        email: 'test@example.com',
        password: 'Password123!'
      });
      
      // Verificaciones
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(SecurityService.hashPassword).toHaveBeenCalledWith('Password123!');
      expect(mockUser.save).toHaveBeenCalled();
      expect(SecurityService.generateToken).toHaveBeenCalledWith({ user: { id: 'user123' } });
      expect(result).toEqual({
        token: 'token123',
        user: {
          id: 'user123',
          name: 'Test User',
          email: 'test@example.com'
        }
      });
    });

    it('debe lanzar un error si el usuario ya existe', async () => {
      // Configurar mocks
      User.findOne.mockResolvedValue({ email: 'test@example.com' }); // Usuario ya existe
      
      // Ejecutar y verificar
      await expect(AuthService.register({
        name: 'Test User',
        email: 'test@example.com',
        password: 'Password123!'
      })).rejects.toThrow('Usuario ya existe');
      
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(SecurityService.hashPassword).not.toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('debe iniciar sesión correctamente con credenciales válidas', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'hashedPassword123'
      };
      
      User.findOne.mockResolvedValue(mockUser);
      SecurityService.verifyPassword.mockResolvedValue(true);
      SecurityService.generateToken.mockReturnValue('token123');
      
      // Ejecutar función a probar
      const result = await AuthService.login({
        email: 'test@example.com',
        password: 'Password123!'
      });
      
      // Verificaciones
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(SecurityService.verifyPassword).toHaveBeenCalledWith('Password123!', 'hashedPassword123');
      expect(SecurityService.generateToken).toHaveBeenCalledWith({ user: { id: 'user123' } });
      expect(result).toEqual({
        token: 'token123',
        user: {
          id: 'user123',
          name: 'Test User',
          email: 'test@example.com'
        }
      });
    });

    it('debe lanzar un error si el usuario no existe', async () => {
      // Configurar mocks
      User.findOne.mockResolvedValue(null); // Usuario no existe
      
      // Ejecutar y verificar
      await expect(AuthService.login({
        email: 'nonexistent@example.com',
        password: 'Password123!'
      })).rejects.toThrow('Credenciales inválidas');
      
      expect(User.findOne).toHaveBeenCalledWith({ email: 'nonexistent@example.com' });
      expect(SecurityService.verifyPassword).not.toHaveBeenCalled();
    });

    it('debe lanzar un error si la contraseña es incorrecta', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'hashedPassword123'
      };
      
      User.findOne.mockResolvedValue(mockUser);
      SecurityService.verifyPassword.mockResolvedValue(false); // Contraseña incorrecta
      
      // Ejecutar y verificar
      await expect(AuthService.login({
        email: 'test@example.com',
        password: 'WrongPassword123!'
      })).rejects.toThrow('Credenciales inválidas');
      
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(SecurityService.verifyPassword).toHaveBeenCalledWith('WrongPassword123!', 'hashedPassword123');
      expect(SecurityService.generateToken).not.toHaveBeenCalled();
    });
  });

  describe('getUserById', () => {
    it('debe obtener un usuario por ID correctamente', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'hashedPassword123'
      };
      
      User.findById.mockResolvedValue(mockUser);
      
      // Ejecutar función a probar
      const result = await AuthService.getUserById('user123');
      
      // Verificaciones
      expect(User.findById).toHaveBeenCalledWith('user123');
      expect(result).toEqual({
        id: 'user123',
        name: 'Test User',
        email: 'test@example.com'
      });
    });

    it('debe lanzar un error si el usuario no existe', async () => {
      // Configurar mocks
      User.findById.mockResolvedValue(null); // Usuario no existe
      
      // Ejecutar y verificar
      await expect(AuthService.getUserById('nonexistent123')).rejects.toThrow('Usuario no encontrado');
      
      expect(User.findById).toHaveBeenCalledWith('nonexistent123');
    });
  });

  describe('updateUser', () => {
    it('debe actualizar un usuario correctamente', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'hashedPassword123',
        save: jest.fn().mockResolvedValue(true)
      };
      
      User.findById.mockResolvedValue(mockUser);
      
      // Ejecutar función a probar
      const result = await AuthService.updateUser('user123', {
        name: 'Updated Name'
      });
      
      // Verificaciones
      expect(User.findById).toHaveBeenCalledWith('user123');
      expect(mockUser.name).toBe('Updated Name');
      expect(mockUser.save).toHaveBeenCalled();
      expect(result).toEqual({
        id: 'user123',
        name: 'Updated Name',
        email: 'test@example.com'
      });
    });

    it('debe lanzar un error si el usuario no existe', async () => {
      // Configurar mocks
      User.findById.mockResolvedValue(null); // Usuario no existe
      
      // Ejecutar y verificar
      await expect(AuthService.updateUser('nonexistent123', {
        name: 'Updated Name'
      })).rejects.toThrow('Usuario no encontrado');
      
      expect(User.findById).toHaveBeenCalledWith('nonexistent123');
    });
  });

  describe('changePassword', () => {
    it('debe cambiar la contraseña correctamente', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'oldHashedPassword',
        save: jest.fn().mockResolvedValue(true)
      };
      
      User.findById.mockResolvedValue(mockUser);
      SecurityService.verifyPassword.mockResolvedValue(true);
      SecurityService.hashPassword.mockResolvedValue('newHashedPassword');
      
      // Ejecutar función a probar
      const result = await AuthService.changePassword('user123', {
        currentPassword: 'OldPassword123!',
        newPassword: 'NewPassword123!'
      });
      
      // Verificaciones
      expect(User.findById).toHaveBeenCalledWith('user123');
      expect(SecurityService.verifyPassword).toHaveBeenCalledWith('OldPassword123!', 'oldHashedPassword');
      expect(SecurityService.hashPassword).toHaveBeenCalledWith('NewPassword123!');
      expect(mockUser.password).toBe('newHashedPassword');
      expect(mockUser.save).toHaveBeenCalled();
      expect(result).toBe(true);
    });

    it('debe lanzar un error si la contraseña actual es incorrecta', async () => {
      // Configurar mocks
      const mockUser = {
        _id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password: 'oldHashedPassword'
      };
      
      User.findById.mockResolvedValue(mockUser);
      SecurityService.verifyPassword.mockResolvedValue(false); // Contraseña incorrecta
      
      // Ejecutar y verificar
      await expect(AuthService.changePassword('user123', {
        currentPassword: 'WrongPassword123!',
        newPassword: 'NewPassword123!'
      })).rejects.toThrow('Contraseña actual incorrecta');
      
      expect(User.findById).toHaveBeenCalledWith('user123');
      expect(SecurityService.verifyPassword).toHaveBeenCalledWith('WrongPassword123!', 'oldHashedPassword');
      expect(SecurityService.hashPassword).not.toHaveBeenCalled();
    });
  });
});
