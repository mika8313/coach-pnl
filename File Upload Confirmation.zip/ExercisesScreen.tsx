import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../context/ThemeContext';
import Icon from 'react-native-vector-icons/Ionicons';

// Datos de ejemplo para los ejercicios de PNL
const mockExercises = [
  {
    id: '1',
    title: 'Círculo de Excelencia',
    type: 'anchoring',
    description: 'Técnica para anclar estados emocionales positivos y acceder a ellos cuando los necesites',
    duration: 10,
    level: 'beginners',
    completed: false,
    image: 'circle_of_excellence'
  },
  {
    id: '2',
    title: 'Línea del Tiempo',
    type: 'timeline',
    description: 'Visualiza tu pasado, presente y futuro para resolver conflictos y planificar objetivos',
    duration: 15,
    level: 'intermediate',
    completed: false,
    image: 'timeline'
  },
  {
    id: '3',
    title: 'Recadrage de Creencias',
    type: 'beliefs',
    description: 'Identifica y transforma creencias limitantes en creencias potenciadoras',
    duration: 20,
    level: 'advanced',
    completed: false,
    image: 'reframing'
  },
  {
    id: '4',
    title: 'Anclaje de Recursos',
    type: 'anchoring',
    description: 'Aprende a activar estados emocionales positivos mediante anclajes físicos',
    duration: 12,
    level: 'beginners',
    completed: true,
    image: 'resource_anchoring'
  },
  {
    id: '5',
    title: 'Visualización Guiada',
    type: 'visualization',
    description: 'Técnica de visualización para manifestar tus objetivos y reducir la ansiedad',
    duration: 15,
    level: 'beginners',
    completed: false,
    image: 'guided_visualization'
  },
];

const ExercisesScreen = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const [exercises, setExercises] = useState(mockExercises);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  // Filtrar ejercicios según categoría y tipo seleccionados
  const filteredExercises = exercises.filter(exercise => {
    const categoryMatch = selectedCategory === 'all' || exercise.level === selectedCategory;
    const typeMatch = selectedType === 'all' || exercise.type === selectedType;
    return categoryMatch && typeMatch;
  });

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    header: {
      padding: 20,
      alignItems: 'center',
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 8,
    },
    subtitle: {
      fontSize: 16,
      color: theme.text,
      opacity: 0.8,
      textAlign: 'center',
      marginBottom: 20,
    },
    filterContainer: {
      marginBottom: 20,
    },
    filterTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
      paddingHorizontal: 20,
    },
    categoryContainer: {
      paddingHorizontal: 10,
    },
    categoryScroll: {
      flexDirection: 'row',
      paddingHorizontal: 10,
    },
    categoryButton: {
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 20,
      marginHorizontal: 5,
      backgroundColor: theme.card,
      borderWidth: 1,
      borderColor: theme.border,
    },
    categoryButtonSelected: {
      backgroundColor: theme.primary,
    },
    categoryText: {
      color: theme.text,
      fontWeight: '500',
    },
    categoryTextSelected: {
      color: 'white',
    },
    typeContainer: {
      marginTop: 15,
      paddingHorizontal: 10,
    },
    exerciseList: {
      paddingHorizontal: 20,
      paddingBottom: 20,
    },
    exerciseCard: {
      backgroundColor: theme.card,
      borderRadius: 15,
      marginBottom: 15,
      overflow: 'hidden',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 2,
    },
    exerciseImage: {
      width: '100%',
      height: 150,
      backgroundColor: theme.primary + '20',
    },
    exerciseImagePlaceholder: {
      width: '100%',
      height: 150,
      backgroundColor: theme.primary + '20',
      justifyContent: 'center',
      alignItems: 'center',
    },
    exerciseContent: {
      padding: 15,
    },
    exerciseHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
    },
    exerciseTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      flex: 1,
    },
    exerciseType: {
      fontSize: 12,
      color: theme.primary,
      backgroundColor: theme.primary + '20',
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 12,
      overflow: 'hidden',
    },
    exerciseDescription: {
      fontSize: 14,
      color: theme.text,
      opacity: 0.8,
      marginBottom: 15,
    },
    exerciseFooter: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    exerciseDuration: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    durationText: {
      fontSize: 14,
      color: theme.text,
      opacity: 0.7,
      marginLeft: 5,
    },
    exerciseButton: {
      backgroundColor: theme.primary,
      paddingHorizontal: 15,
      paddingVertical: 8,
      borderRadius: 8,
    },
    exerciseButtonText: {
      color: 'white',
      fontWeight: 'bold',
    },
    completedBadge: {
      position: 'absolute',
      top: 10,
      right: 10,
      backgroundColor: theme.success,
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 12,
      zIndex: 1,
    },
    completedText: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingVertical: 50,
    },
    emptyText: {
      fontSize: 16,
      color: theme.text,
      opacity: 0.7,
      textAlign: 'center',
    },
  });

  // Renderizar cada ejercicio
  const renderExerciseItem = ({ item }) => (
    <TouchableOpacity style={styles.exerciseCard}>
      {item.completed && (
        <View style={styles.completedBadge}>
          <Text style={styles.completedText}>{t('exercises.completed')}</Text>
        </View>
      )}
      <View style={styles.exerciseImagePlaceholder}>
        <Icon name={getIconForExerciseType(item.type)} size={50} color={theme.primary} />
      </View>
      <View style={styles.exerciseContent}>
        <View style={styles.exerciseHeader}>
          <Text style={styles.exerciseTitle}>{item.title}</Text>
          <Text style={styles.exerciseType}>{t(`exercises.exerciseTypes.${item.type}`)}</Text>
        </View>
        <Text style={styles.exerciseDescription}>{item.description}</Text>
        <View style={styles.exerciseFooter}>
          <View style={styles.exerciseDuration}>
            <Icon name="time-outline" size={16} color={theme.text} />
            <Text style={styles.durationText}>{item.duration} {t('exercises.minutes')}</Text>
          </View>
          <TouchableOpacity style={styles.exerciseButton}>
            <Text style={styles.exerciseButtonText}>
              {item.completed ? t('exercises.continueExercise') : t('exercises.startExercise')}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  // Obtener icono según el tipo de ejercicio
  const getIconForExerciseType = (type) => {
    switch (type) {
      case 'anchoring':
        return 'anchor-outline';
      case 'timeline':
        return 'git-branch-outline';
      case 'beliefs':
        return 'bulb-outline';
      case 'visualization':
        return 'eye-outline';
      case 'reframing':
        return 'refresh-outline';
      default:
        return 'fitness-outline';
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('exercises.title')}</Text>
        <Text style={styles.subtitle}>{t('exercises.subtitle')}</Text>
      </View>

      <View style={styles.filterContainer}>
        <Text style={styles.filterTitle}>{t('exercises.categories.all')}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryContainer}>
          <View style={styles.categoryScroll}>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedCategory === 'all' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedCategory('all')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === 'all' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.categories.all')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedCategory === 'beginners' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedCategory('beginners')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === 'beginners' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.categories.beginners')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedCategory === 'intermediate' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedCategory('intermediate')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === 'intermediate' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.categories.intermediate')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedCategory === 'advanced' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedCategory('advanced')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === 'advanced' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.categories.advanced')}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.typeContainer}>
          <View style={styles.categoryScroll}>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedType === 'all' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedType('all')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedType === 'all' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.categories.all')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedType === 'anchoring' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedType('anchoring')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedType === 'anchoring' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.exerciseTypes.anchoring')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedType === 'timeline' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedType('timeline')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedType === 'timeline' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.exerciseTypes.timeline')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedType === 'beliefs' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedType('beliefs')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedType === 'beliefs' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.exerciseTypes.beliefs')}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedType === 'visualization' && styles.categoryButtonSelected,
              ]}
              onPress={() => setSelectedType('visualization')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedType === 'visualization' && styles.categoryTextSelected,
                ]}
              >
                {t('exercises.exerciseTypes.visualization')}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>

      {filteredExercises.length > 0 ? (
        <FlatList
          data={filteredExercises}
          renderItem={renderExerciseItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.exerciseList}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Icon name="search-outline" size={50} color={theme.disabled} />
          <Text style={styles.emptyText}>No se encontraron ejercicios con los filtros seleccionados.</Text>
        </View>
      )}
    </View>
  );
};

export default ExercisesScreen;
