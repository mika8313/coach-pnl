/**
 * Configuración para pruebas automatizadas
 */
const testConfig = {
  // Configuración general de pruebas
  general: {
    testEnvironment: "node",
    testTimeout: 30000, // 30 segundos
    maxWorkers: 4,
    verbose: true,
    bail: 0, // No detener después de fallos
    collectCoverage: true,
    coverageThreshold: {
      global: {
        statements: 70,
        branches: 60,
        functions: 70,
        lines: 70
      }
    }
  },
  
  // Configuración de pruebas unitarias
  unit: {
    testMatch: ["**/__tests__/**/*.unit.js", "**/?(*.)+(unit|spec).js"],
    setupFiles: ["./test/setup/unit.js"],
    moduleNameMapper: {
      "^@/(.*)$": "<rootDir>/src/$1"
    }
  },
  
  // Configuración de pruebas de integración
  integration: {
    testMatch: ["**/__tests__/**/*.integration.js", "**/?(*.)+(integration).js"],
    setupFiles: ["./test/setup/integration.js"],
    globalSetup: "./test/setup/global-setup.js",
    globalTeardown: "./test/setup/global-teardown.js"
  },
  
  // Configuración de pruebas end-to-end
  e2e: {
    testMatch: ["**/__tests__/**/*.e2e.js", "**/?(*.)+(e2e).js"],
    setupFiles: ["./test/setup/e2e.js"],
    globalSetup: "./test/setup/e2e-setup.js",
    globalTeardown: "./test/setup/e2e-teardown.js"
  },
  
  // Configuración de mocks
  mocks: {
    // Mocks para APIs externas
    openai: {
      baseUrl: "http://localhost:9001",
      mockResponses: {
        chat: "./test/mocks/openai/chat-responses.json",
        embeddings: "./test/mocks/openai/embeddings-responses.json",
        whisper: "./test/mocks/openai/whisper-responses.json"
      }
    },
    elevenlabs: {
      baseUrl: "http://localhost:9002",
      mockResponses: {
        voices: "./test/mocks/elevenlabs/voices-responses.json",
        tts: "./test/mocks/elevenlabs/tts-responses.json"
      }
    }
  },
  
  // Configuración de datos de prueba
  testData: {
    users: "./test/data/users.json",
    exercises: "./test/data/exercises.json",
    conversations: "./test/data/conversations.json",
    journalEntries: "./test/data/journal-entries.json"
  }
};

module.exports = testConfig;
