/**
 * Servicio para gestionar la internacionalización en el backend
 */
class I18nService {
  // Idiomas soportados
  #supportedLanguages = ['es', 'en', 'fr'];
  
  // Idioma por defecto
  #defaultLanguage = 'es';
  
  // Traducciones para mensajes del sistema
  #translations = {
    es: {
      errors: {
        serverError: 'Error en el servidor',
        notFound: 'Recurso no encontrado',
        unauthorized: 'No autorizado',
        invalidCredentials: 'Credenciales inválidas',
        fieldsRequired: 'Todos los campos son obligatorios',
        emailExists: 'El email ya está registrado',
        passwordsDoNotMatch: 'Las contraseñas no coinciden',
        invalidToken: 'Token no válido',
        audioRequired: 'Datos de audio requeridos',
        textRequired: 'El texto es obligatorio'
      },
      success: {
        registered: 'Usuario registrado correctamente',
        loggedIn: 'Inicio de sesión exitoso',
        profileUpdated: 'Perfil actualizado correctamente',
        goalAdded: 'Meta añadida correctamente',
        goalUpdated: 'Meta actualizada correctamente',
        goalDeleted: 'Meta eliminada correctamente',
        exerciseCompleted: 'Ejercicio completado correctamente',
        journalEntryAdded: 'Entrada de diario añadida correctamente',
        journalEntryUpdated: 'Entrada de diario actualizada correctamente',
        journalEntryDeleted: 'Entrada de diario eliminada correctamente',
        audioGenerated: 'Audio generado correctamente'
      },
      pnl: {
        welcomeMessage: 'Hola, soy tu coach de PNL. ¿En qué puedo ayudarte hoy?',
        exerciseIntro: 'Este ejercicio te ayudará a desarrollar tu potencial utilizando técnicas de PNL.',
        journalPrompt: 'Reflexiona sobre tu día y escribe tus pensamientos, emociones y logros.'
      }
    },
    en: {
      errors: {
        serverError: 'Server error',
        notFound: 'Resource not found',
        unauthorized: 'Unauthorized',
        invalidCredentials: 'Invalid credentials',
        fieldsRequired: 'All fields are required',
        emailExists: 'Email already registered',
        passwordsDoNotMatch: 'Passwords do not match',
        invalidToken: 'Invalid token',
        audioRequired: 'Audio data required',
        textRequired: 'Text is required'
      },
      success: {
        registered: 'User registered successfully',
        loggedIn: 'Login successful',
        profileUpdated: 'Profile updated successfully',
        goalAdded: 'Goal added successfully',
        goalUpdated: 'Goal updated successfully',
        goalDeleted: 'Goal deleted successfully',
        exerciseCompleted: 'Exercise completed successfully',
        journalEntryAdded: 'Journal entry added successfully',
        journalEntryUpdated: 'Journal entry updated successfully',
        journalEntryDeleted: 'Journal entry deleted successfully',
        audioGenerated: 'Audio generated successfully'
      },
      pnl: {
        welcomeMessage: 'Hello, I am your NLP coach. How can I help you today?',
        exerciseIntro: 'This exercise will help you develop your potential using NLP techniques.',
        journalPrompt: 'Reflect on your day and write down your thoughts, emotions, and achievements.'
      }
    },
    fr: {
      errors: {
        serverError: 'Erreur du serveur',
        notFound: 'Ressource non trouvée',
        unauthorized: 'Non autorisé',
        invalidCredentials: 'Identifiants invalides',
        fieldsRequired: 'Tous les champs sont obligatoires',
        emailExists: 'Email déjà enregistré',
        passwordsDoNotMatch: 'Les mots de passe ne correspondent pas',
        invalidToken: 'Token invalide',
        audioRequired: 'Données audio requises',
        textRequired: 'Le texte est obligatoire'
      },
      success: {
        registered: 'Utilisateur enregistré avec succès',
        loggedIn: 'Connexion réussie',
        profileUpdated: 'Profil mis à jour avec succès',
        goalAdded: 'Objectif ajouté avec succès',
        goalUpdated: 'Objectif mis à jour avec succès',
        goalDeleted: 'Objectif supprimé avec succès',
        exerciseCompleted: 'Exercice terminé avec succès',
        journalEntryAdded: 'Entrée de journal ajoutée avec succès',
        journalEntryUpdated: 'Entrée de journal mise à jour avec succès',
        journalEntryDeleted: 'Entrée de journal supprimée avec succès',
        audioGenerated: 'Audio généré avec succès'
      },
      pnl: {
        welcomeMessage: 'Bonjour, je suis votre coach PNL. Comment puis-je vous aider aujourd\'hui?',
        exerciseIntro: 'Cet exercice vous aidera à développer votre potentiel en utilisant des techniques de PNL.',
        journalPrompt: 'Réfléchissez à votre journée et notez vos pensées, émotions et réalisations.'
      }
    }
  };

  /**
   * Obtiene un mensaje traducido
   * @param {string} key - Clave del mensaje (formato: 'categoria.subcategoria.mensaje')
   * @param {string} language - Idioma deseado
   * @returns {string} - Mensaje traducido
   */
  translate(key, language = this.#defaultLanguage) {
    // Verificar si el idioma es soportado
    if (!this.#supportedLanguages.includes(language)) {
      console.warn(`Idioma ${language} no soportado, usando ${this.#defaultLanguage} por defecto`);
      language = this.#defaultLanguage;
    }
    
    // Dividir la clave en partes
    const parts = key.split('.');
    
    // Navegar por el objeto de traducciones
    let translation = this.#translations[language];
    for (const part of parts) {
      if (translation && translation[part]) {
        translation = translation[part];
      } else {
        console.warn(`Traducción no encontrada para la clave ${key} en idioma ${language}`);
        
        // Intentar con el idioma por defecto
        let defaultTranslation = this.#translations[this.#defaultLanguage];
        for (const defaultPart of parts) {
          if (defaultTranslation && defaultTranslation[defaultPart]) {
            defaultTranslation = defaultTranslation[defaultPart];
          } else {
            return key; // Si no se encuentra ni siquiera en el idioma por defecto, devolver la clave
          }
        }
        
        return defaultTranslation;
      }
    }
    
    return translation;
  }

  /**
   * Verifica si un idioma es soportado
   * @param {string} language - Idioma a verificar
   * @returns {boolean} - true si el idioma es soportado, false en caso contrario
   */
  isSupported(language) {
    return this.#supportedLanguages.includes(language);
  }

  /**
   * Obtiene el idioma por defecto
   * @returns {string} - Idioma por defecto
   */
  getDefaultLanguage() {
    return this.#defaultLanguage;
  }

  /**
   * Obtiene todos los idiomas soportados
   * @returns {Array} - Lista de idiomas soportados
   */
  getSupportedLanguages() {
    return [...this.#supportedLanguages];
  }

  /**
   * Detecta el idioma preferido basado en el encabezado Accept-Language
   * @param {string} acceptLanguageHeader - Encabezado Accept-Language
   * @returns {string} - Idioma detectado o idioma por defecto
   */
  detectLanguage(acceptLanguageHeader) {
    if (!acceptLanguageHeader) {
      return this.#defaultLanguage;
    }
    
    // Parsear el encabezado Accept-Language
    const languages = acceptLanguageHeader.split(',')
      .map(lang => {
        const [language, q = 'q=1.0'] = lang.trim().split(';');
        const quality = parseFloat(q.split('=')[1]);
        return { language: language.split('-')[0], quality };
      })
      .sort((a, b) => b.quality - a.quality);
    
    // Encontrar el primer idioma soportado
    for (const { language } of languages) {
      if (this.#supportedLanguages.includes(language)) {
        return language;
      }
    }
    
    return this.#defaultLanguage;
  }
}

module.exports = new I18nService();
