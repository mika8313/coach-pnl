/**
 * Servicio para integrar las funcionalidades de voz en la aplicación
 * Combina TTS y STT para una experiencia de voz completa
 */
class VoiceIntegrationService {
  constructor() {
    this.TextToSpeechService = require('./TextToSpeechService');
    this.SpeechToTextService = require('./SpeechToTextService');
    this.OpenAIPNLService = require('./OpenAIPNLService');
    this.VoiceEmotionService = require('./VoiceEmotionService');
  }

  /**
   * Procesa una entrada de voz y genera una respuesta hablada
   * @param {Buffer} audioInput - Datos de audio de entrada
   * @param {Object} user - Información del usuario
   * @param {Array} conversationHistory - Historial de la conversación
   * @returns {Promise<Object>} - Resultado del procesamiento
   */
  async processVoiceInteraction(audioInput, user, conversationHistory = []) {
    try {
      // 1. Transcribir audio a texto
      const transcription = await this.SpeechToTextService.transcribeAudio(audioInput, {
        language: user.language || 'es'
      });

      // 2. Analizar emociones en la voz
      const voiceAnalysis = await this.VoiceEmotionService.analyzeVoiceEmotion(
        audioInput, 
        user.language || 'es'
      );

      // 3. Generar respuesta basada en PNL
      const pnlResponse = await this.OpenAIPNLService.generatePNLResponse(
        transcription.text,
        conversationHistory,
        voiceAnalysis.emotionalState ? 
          { state: voiceAnalysis.emotionalState, intensity: voiceAnalysis.emotionalIntensity } : 
          { state: 'neutral', intensity: 0.5 },
        user.language || 'es'
      );

      // 4. Convertir respuesta a voz
      const voicePreferences = user.preferences?.voice || {
        voiceType: 'female1',
        voiceSpeed: 1.0
      };

      const audioResponse = await this.TextToSpeechService.textToSpeech(
        pnlResponse.message,
        user.language || 'es',
        voicePreferences.voiceType,
        voicePreferences.voiceSpeed
      );

      // 5. Devolver resultado completo
      return {
        input: {
          text: transcription.text,
          language: transcription.language,
          emotionalAnalysis: {
            state: voiceAnalysis.emotionalState,
            intensity: voiceAnalysis.emotionalIntensity
          },
          voiceCharacteristics: voiceAnalysis.voiceAnalysis
        },
        response: {
          text: pnlResponse.message,
          techniques: pnlResponse.techniques,
          audio: audioResponse, // En una implementación real, esto sería una URL o un buffer
          voiceSettings: {
            type: voicePreferences.voiceType,
            speed: voicePreferences.voiceSpeed
          }
        }
      };
    } catch (error) {
      console.error('Error en procesamiento de voz:', error);
      throw error;
    }
  }

  /**
   * Actualiza las preferencias de voz del usuario
   * @param {Object} user - Usuario a actualizar
   * @param {Object} voicePreferences - Nuevas preferencias de voz
   * @returns {Promise<Object>} - Preferencias actualizadas
   */
  async updateVoicePreferences(user, voicePreferences) {
    try {
      // En una implementación real, esto actualizaría la base de datos
      // Por ahora, solo devolvemos las preferencias actualizadas
      
      const updatedPreferences = {
        voiceType: voicePreferences.voiceType || 'female1',
        voiceSpeed: parseFloat(voicePreferences.voiceSpeed) || 1.0
      };
      
      return updatedPreferences;
    } catch (error) {
      console.error('Error actualizando preferencias de voz:', error);
      throw error;
    }
  }

  /**
   * Obtiene las voces disponibles para un usuario
   * @param {Object} user - Usuario
   * @returns {Promise<Object>} - Voces disponibles
   */
  async getAvailableVoices(user) {
    try {
      const language = user.language || 'es';
      return this.TextToSpeechService.getAvailableVoices(language);
    } catch (error) {
      console.error('Error obteniendo voces disponibles:', error);
      throw error;
    }
  }
}

module.exports = new VoiceIntegrationService();
