import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../context/ThemeContext';
import Icon from 'react-native-vector-icons/Ionicons';

// Datos de ejemplo para los mensajes del chat
const initialMessages = [
  {
    id: '1',
    text: 'Hola, soy tu coach de PNL. ¿En qué puedo ayudarte hoy?',
    sender: 'ai',
    timestamp: new Date().getTime() - 1000 * 60 * 5, // 5 minutos atrás
  },
];

const ChatScreen = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const [messages, setMessages] = useState(initialMessages);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const flatListRef = useRef(null);

  // Simular respuesta de la IA
  const simulateAIResponse = async (userMessage) => {
    setIsLoading(true);
    
    // Simular retraso de red/procesamiento
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Respuestas de ejemplo basadas en PNL
    const nlpResponses = [
      "Entiendo cómo te sientes. ¿Podrías decirme más sobre cuándo comenzaste a notar este patrón?",
      "Parece que hay una creencia limitante ahí. ¿Qué pasaría si consideraras una perspectiva diferente?",
      "Vamos a explorar eso. Imagina que ya has superado este desafío, ¿cómo te sentirías?",
      "Esa es una observación interesante. ¿Cómo resuena eso con tus valores fundamentales?",
      "Podríamos trabajar en un ejercicio de anclaje para ayudarte con eso. ¿Te gustaría probarlo?",
      "Cuando describes esa situación, ¿qué imágenes vienen a tu mente? ¿Son claras o borrosas?",
      "Vamos a reformular eso. En lugar de verlo como un problema, ¿cómo podría ser una oportunidad?",
    ];
    
    // Seleccionar una respuesta aleatoria
    const randomResponse = nlpResponses[Math.floor(Math.random() * nlpResponses.length)];
    
    const aiMessage = {
      id: Date.now().toString(),
      text: randomResponse,
      sender: 'ai',
      timestamp: new Date().getTime(),
    };
    
    setMessages(prevMessages => [...prevMessages, aiMessage]);
    setIsLoading(false);
  };

  // Enviar mensaje
  const handleSendMessage = () => {
    if (inputText.trim() === '') return;
    
    const newMessage = {
      id: Date.now().toString(),
      text: inputText.trim(),
      sender: 'user',
      timestamp: new Date().getTime(),
    };
    
    setMessages(prevMessages => [...prevMessages, newMessage]);
    setInputText('');
    
    // Simular respuesta de la IA
    simulateAIResponse(inputText);
  };

  // Iniciar/detener grabación de voz
  const toggleRecording = () => {
    setIsRecording(!isRecording);
    
    if (isRecording) {
      // Aquí se detendría la grabación y se procesaría el audio
      // En una implementación real, se enviaría a Whisper API
      
      // Simular texto reconocido
      setTimeout(() => {
        const recognizedText = "Me gustaría trabajar en mi confianza para hablar en público";
        setInputText(recognizedText);
        setIsRecording(false);
      }, 1500);
    }
  };

  // Reproducir respuesta con voz
  const toggleSpeaking = (messageText) => {
    setIsSpeaking(!isSpeaking);
    
    if (!isSpeaking) {
      // Aquí se enviaría el texto a ElevenLabs API y se reproduciría el audio
      // En esta simulación, solo cambiamos el estado
      setTimeout(() => {
        setIsSpeaking(false);
      }, 3000);
    }
  };

  // Desplazarse al último mensaje cuando se envía uno nuevo
  useEffect(() => {
    if (flatListRef.current && messages.length > 0) {
      flatListRef.current.scrollToEnd({ animated: true });
    }
  }, [messages]);

  // Formatear la hora del mensaje
  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    chatContainer: {
      flex: 1,
      padding: 10,
    },
    messageContainer: {
      marginVertical: 5,
      maxWidth: '80%',
    },
    userMessageContainer: {
      alignSelf: 'flex-end',
      backgroundColor: theme.primary,
      borderRadius: 20,
      borderBottomRightRadius: 5,
      padding: 12,
    },
    aiMessageContainer: {
      alignSelf: 'flex-start',
      backgroundColor: theme.card,
      borderRadius: 20,
      borderBottomLeftRadius: 5,
      padding: 12,
    },
    userMessageText: {
      color: 'white',
      fontSize: 16,
    },
    aiMessageText: {
      color: theme.text,
      fontSize: 16,
    },
    messageTime: {
      fontSize: 12,
      marginTop: 5,
      alignSelf: 'flex-end',
    },
    userMessageTime: {
      color: 'rgba(255, 255, 255, 0.7)',
    },
    aiMessageTime: {
      color: theme.text,
      opacity: 0.6,
    },
    inputContainer: {
      flexDirection: 'row',
      padding: 10,
      backgroundColor: theme.card,
      borderTopWidth: 1,
      borderTopColor: theme.border,
      alignItems: 'center',
    },
    textInput: {
      flex: 1,
      backgroundColor: theme.background,
      borderRadius: 20,
      paddingHorizontal: 15,
      paddingVertical: 10,
      marginRight: 10,
      color: theme.text,
    },
    sendButton: {
      backgroundColor: theme.primary,
      width: 40,
      height: 40,
      borderRadius: 20,
      justifyContent: 'center',
      alignItems: 'center',
    },
    recordButton: {
      backgroundColor: isRecording ? theme.error : theme.secondary,
      width: 40,
      height: 40,
      borderRadius: 20,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 10,
    },
    loadingContainer: {
      alignSelf: 'flex-start',
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 20,
      padding: 15,
      marginVertical: 5,
    },
    loadingText: {
      color: theme.text,
      marginLeft: 10,
      fontSize: 16,
    },
    speakButton: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.primary + '20',
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 15,
      marginTop: 5,
    },
    speakButtonText: {
      color: theme.primary,
      marginLeft: 5,
      fontSize: 12,
    },
    dateHeader: {
      alignSelf: 'center',
      backgroundColor: theme.primary + '30',
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 10,
      marginVertical: 10,
    },
    dateHeaderText: {
      color: theme.text,
      fontSize: 12,
    },
  });

  // Renderizar cada mensaje
  const renderMessage = ({ item, index }) => {
    const isUser = item.sender === 'user';
    
    return (
      <View style={[
        styles.messageContainer,
        isUser ? styles.userMessageContainer : styles.aiMessageContainer
      ]}>
        <Text style={isUser ? styles.userMessageText : styles.aiMessageText}>
          {item.text}
        </Text>
        <Text style={[
          styles.messageTime,
          isUser ? styles.userMessageTime : styles.aiMessageTime
        ]}>
          {formatMessageTime(item.timestamp)}
        </Text>
        
        {!isUser && (
          <TouchableOpacity 
            style={styles.speakButton}
            onPress={() => toggleSpeaking(item.text)}
          >
            <Icon 
              name={isSpeaking ? "stop-circle-outline" : "volume-medium-outline"} 
              size={14} 
              color={theme.primary} 
            />
            <Text style={styles.speakButtonText}>
              {isSpeaking ? t('chat.stopSpeaking') : t('chat.speakResponse')}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.chatContainer}
      />
      
      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={theme.primary} size="small" />
          <Text style={styles.loadingText}>{t('chat.thinking')}</Text>
        </View>
      )}
      
      <View style={styles.inputContainer}>
        <TouchableOpacity 
          style={styles.recordButton}
          onPress={toggleRecording}
        >
          <Icon 
            name={isRecording ? "stop-outline" : "mic-outline"} 
            size={20} 
            color="white" 
          />
        </TouchableOpacity>
        
        <TextInput
          style={styles.textInput}
          placeholder={t('chat.placeholder')}
          placeholderTextColor={theme.disabled}
          value={inputText}
          onChangeText={setInputText}
          multiline
        />
        
        <TouchableOpacity 
          style={styles.sendButton}
          onPress={handleSendMessage}
          disabled={inputText.trim() === ''}
        >
          <Icon name="send-outline" size={20} color="white" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default ChatScreen;
