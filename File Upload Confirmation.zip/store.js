/**
 * Configuración para la preparación de la aplicación para App Store y Google Play
 */
const storeConfig = {
  // Información general de la aplicación
  appInfo: {
    name: "PNL Coach",
    description: "Aplicación de coaching con IA especializada en Programación Neuro-Lingüística (PNL)",
    version: "1.0.0",
    category: "Health & Fitness",
    contentRating: "12+",
    keywords: [
      "coaching",
      "pnl",
      "programación neurolingüística",
      "desarrollo personal",
      "inteligencia artificial",
      "bienestar",
      "meditación",
      "mindfulness"
    ]
  },
  
  // Configuración específica para App Store (iOS)
  appStore: {
    // Información de contacto para App Store
    contactInfo: {
      firstName: "Jean",
      lastName: "Dupont",
      email: "contact@pnlcoach.com",
      phone: "+33123456789"
    },
    
    // Información de precios y disponibilidad
    pricing: {
      price: 0.00, // Gratis con compras in-app
      freeTrial: true,
      subscriptionModel: true,
      subscriptionPeriods: ["monthly", "yearly"],
      availableCountries: "all"
    },
    
    // Información de revisión para App Store
    review: {
      notes: "Esta aplicación utiliza técnicas de PNL (Programación Neuro-Lingüística) para coaching personal. Incluye un chatbot de IA, ejercicios interactivos y análisis de voz. Las credenciales de prueba son: usuario: reviewer@apple.com, contraseña: Test1234!",
      demoAccount: {
        username: "reviewer@apple.com",
        password: "Test1234!"
      },
      attachments: []
    },
    
    // Metadatos para App Store
    metadata: {
      subtitle: "Tu coach de PNL personal",
      promotionalText: "Transforma tu vida con técnicas de PNL y coaching personalizado con IA",
      supportUrl: "https://pnlcoach.com/support",
      marketingUrl: "https://pnlcoach.com",
      privacyPolicyUrl: "https://pnlcoach.com/privacy"
    }
  },
  
  // Configuración específica para Google Play (Android)
  googlePlay: {
    // Información de contacto para Google Play
    contactInfo: {
      email: "contact@pnlcoach.com",
      phone: "+33123456789",
      website: "https://pnlcoach.com"
    },
    
    // Información de precios y disponibilidad
    pricing: {
      price: 0.00, // Gratis con compras in-app
      countries: "all",
      inAppProducts: true
    },
    
    // Información de categorización
    categorization: {
      category: "Health & Fitness",
      contentRating: "Teen",
      targetAudience: ["teens", "adults"]
    },
    
    // Metadatos para Google Play
    metadata: {
      shortDescription: "Aplicación de coaching con IA especializada en PNL",
      fullDescription: "PNL Coach es una aplicación completa de coaching con IA especializada en Programación Neuro-Lingüística (PNL). Ofrece un chatbot inteligente, ejercicios interactivos, seguimiento de progreso, integración de voz y soporte multilingüe. Transforma tu vida con técnicas de PNL personalizadas y coaching adaptado a tus necesidades.",
      promoVideo: "https://youtube.com/watch?v=pnlcoach",
      privacyPolicyUrl: "https://pnlcoach.com/privacy",
      termsOfServiceUrl: "https://pnlcoach.com/terms"
    }
  },
  
  // Recursos gráficos necesarios para las tiendas
  graphicAssets: {
    // Iconos de la aplicación
    icons: {
      appIcon: "/assets/icon.png", // 1024x1024 px
      adaptiveIcon: {
        foreground: "/assets/adaptive-icon-foreground.png", // 108x108 px
        background: "/assets/adaptive-icon-background.png" // 108x108 px
      }
    },
    
    // Capturas de pantalla
    screenshots: {
      // iPhone (6.5 pulgadas)
      iphone65: [
        "/assets/screenshots/iphone65/screenshot1.png",
        "/assets/screenshots/iphone65/screenshot2.png",
        "/assets/screenshots/iphone65/screenshot3.png"
      ],
      // iPhone (5.5 pulgadas)
      iphone55: [
        "/assets/screenshots/iphone55/screenshot1.png",
        "/assets/screenshots/iphone55/screenshot2.png",
        "/assets/screenshots/iphone55/screenshot3.png"
      ],
      // iPad
      ipad: [
        "/assets/screenshots/ipad/screenshot1.png",
        "/assets/screenshots/ipad/screenshot2.png",
        "/assets/screenshots/ipad/screenshot3.png"
      ],
      // Android (teléfono)
      androidPhone: [
        "/assets/screenshots/android-phone/screenshot1.png",
        "/assets/screenshots/android-phone/screenshot2.png",
        "/assets/screenshots/android-phone/screenshot3.png"
      ],
      // Android (tablet)
      androidTablet: [
        "/assets/screenshots/android-tablet/screenshot1.png",
        "/assets/screenshots/android-tablet/screenshot2.png",
        "/assets/screenshots/android-tablet/screenshot3.png"
      ]
    },
    
    // Imágenes promocionales
    promotional: {
      featureGraphic: "/assets/promotional/feature-graphic.png", // 1024x500 px
      promoGraphic: "/assets/promotional/promo-graphic.png", // 180x120 px
      tvBanner: "/assets/promotional/tv-banner.png", // 1280x720 px
      appPreview: "/assets/promotional/app-preview.mp4" // Video de 15-30 segundos
    }
  },
  
  // Configuración de compras in-app
  inAppPurchases: {
    subscriptions: [
      {
        id: "com.pnlcoach.app.subscription.monthly",
        name: "Suscripción Mensual",
        description: "Acceso completo a todas las funcionalidades premium durante 1 mes",
        price: 4.99,
        billingPeriod: "monthly",
        trialPeriod: "7 days"
      },
      {
        id: "com.pnlcoach.app.subscription.yearly",
        name: "Suscripción Anual",
        description: "Acceso completo a todas las funcionalidades premium durante 1 año",
        price: 39.99,
        billingPeriod: "yearly",
        trialPeriod: "7 days"
      }
    ],
    consumables: [
      {
        id: "com.pnlcoach.app.credits.small",
        name: "Paquete de 100 Créditos",
        description: "100 créditos para usar en ejercicios premium",
        price: 2.99
      },
      {
        id: "com.pnlcoach.app.credits.medium",
        name: "Paquete de 300 Créditos",
        description: "300 créditos para usar en ejercicios premium",
        price: 7.99
      },
      {
        id: "com.pnlcoach.app.credits.large",
        name: "Paquete de 500 Créditos",
        description: "500 créditos para usar en ejercicios premium",
        price: 11.99
      }
    ]
  },
  
  // Lista de verificación para publicación
  publishingChecklist: {
    legal: [
      "Política de privacidad",
      "Términos de servicio",
      "Cumplimiento GDPR",
      "Cumplimiento CCPA"
    ],
    technical: [
      "Pruebas en múltiples dispositivos",
      "Optimización de rendimiento",
      "Gestión de memoria",
      "Manejo de errores",
      "Compatibilidad con versiones anteriores"
    ],
    content: [
      "Capturas de pantalla para todas las plataformas",
      "Iconos en todos los tamaños requeridos",
      "Descripciones y metadatos",
      "Palabras clave optimizadas"
    ],
    security: [
      "Cifrado de datos sensibles",
      "Autenticación segura",
      "Protección contra ataques comunes",
      "Validación de entradas"
    ]
  }
};

export default storeConfig;
