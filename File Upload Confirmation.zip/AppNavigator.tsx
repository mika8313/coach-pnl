import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from 'react-i18next';
import Icon from 'react-native-vector-icons/Ionicons';

// Importar pantallas
// Pantallas de autenticación
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';

// Pantallas principales
import HomeScreen from '../screens/main/HomeScreen';
import ChatScreen from '../screens/main/ChatScreen';
import ExercisesScreen from '../screens/main/ExercisesScreen';
import ProfileScreen from '../screens/main/ProfileScreen';
import JournalScreen from '../screens/main/JournalScreen';

// Definir tipos para los parámetros de navegación
type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

type AuthStackParamList = {
  Welcome: undefined;
  Login: undefined;
  Register: undefined;
};

type MainTabParamList = {
  Home: undefined;
  Chat: undefined;
  Exercises: undefined;
  Journal: undefined;
  Profile: undefined;
};

// Crear navegadores
const RootStack = createStackNavigator<RootStackParamList>();
const AuthStack = createStackNavigator<AuthStackParamList>();
const MainTab = createBottomTabNavigator<MainTabParamList>();

// Navegador de autenticación
const AuthNavigator = () => {
  const { theme } = useTheme();
  
  return (
    <AuthStack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: { backgroundColor: theme.background }
      }}
    >
      <AuthStack.Screen 
        name="Welcome" 
        component={WelcomeScreen} 
        options={{ headerShown: false }}
      />
      <AuthStack.Screen 
        name="Login" 
        component={LoginScreen} 
      />
      <AuthStack.Screen 
        name="Register" 
        component={RegisterScreen} 
      />
    </AuthStack.Navigator>
  );
};

// Navegador principal con tabs
const MainNavigator = () => {
  const { theme } = useTheme();
  const { t } = useTranslation();
  
  return (
    <MainTab.Navigator
      screenOptions={{
        tabBarActiveTintColor: theme.primary,
        tabBarInactiveTintColor: theme.disabled,
        tabBarStyle: {
          backgroundColor: theme.card,
          borderTopColor: theme.border,
          paddingBottom: 5,
          paddingTop: 5,
          height: 60,
        },
        headerStyle: {
          backgroundColor: theme.background,
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <MainTab.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{
          title: t('navigation.home'),
          tabBarIcon: ({ color, size }) => (
            <Icon name="home-outline" color={color} size={size} />
          ),
        }}
      />
      <MainTab.Screen 
        name="Chat" 
        component={ChatScreen} 
        options={{
          title: t('navigation.chat'),
          tabBarIcon: ({ color, size }) => (
            <Icon name="chatbubble-ellipses-outline" color={color} size={size} />
          ),
        }}
      />
      <MainTab.Screen 
        name="Exercises" 
        component={ExercisesScreen} 
        options={{
          title: t('navigation.exercises'),
          tabBarIcon: ({ color, size }) => (
            <Icon name="fitness-outline" color={color} size={size} />
          ),
        }}
      />
      <MainTab.Screen 
        name="Journal" 
        component={JournalScreen} 
        options={{
          title: t('navigation.journal'),
          tabBarIcon: ({ color, size }) => (
            <Icon name="journal-outline" color={color} size={size} />
          ),
        }}
      />
      <MainTab.Screen 
        name="Profile" 
        component={ProfileScreen} 
        options={{
          title: t('navigation.profile'),
          tabBarIcon: ({ color, size }) => (
            <Icon name="person-outline" color={color} size={size} />
          ),
        }}
      />
    </MainTab.Navigator>
  );
};

// Navegador raíz que decide entre Auth y Main
const AppNavigator = () => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    // Aquí se podría mostrar una pantalla de carga
    return null;
  }
  
  return (
    <RootStack.Navigator screenOptions={{ headerShown: false }}>
      {isAuthenticated ? (
        <RootStack.Screen name="Main" component={MainNavigator} />
      ) : (
        <RootStack.Screen name="Auth" component={AuthNavigator} />
      )}
    </RootStack.Navigator>
  );
};

export default AppNavigator;
