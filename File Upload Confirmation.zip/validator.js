/**
 * Middleware para validación de datos de entrada
 */
const { validationResult } = require('express-validator');
const SecurityService = require('../services/SecurityService');

/**
 * Middleware para validar resultados de express-validator
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      errors: errors.array(),
      message: req.translate ? req.translate('errors.invalidInput') : 'Datos de entrada inválidos'
    });
  }
  next();
};

/**
 * Middleware para sanitizar datos de entrada
 */
const sanitizeInput = (req, res, next) => {
  // Sanitizar body
  if (req.body) {
    req.body = SecurityService.sanitizeInput(req.body);
  }
  
  // Sanitizar query params
  if (req.query) {
    req.query = SecurityService.sanitizeInput(req.query);
  }
  
  // Sanitizar params
  if (req.params) {
    req.params = SecurityService.sanitizeInput(req.params);
  }
  
  next();
};

/**
 * Middleware para validar fortaleza de contraseña
 */
const validatePasswordStrength = (req, res, next) => {
  const { password } = req.body;
  
  if (!password) {
    return next();
  }
  
  const validation = SecurityService.validatePasswordStrength(password);
  
  if (!validation.isValid) {
    return res.status(400).json({
      message: req.translate ? req.translate('errors.weakPassword') : 'La contraseña no cumple con los requisitos mínimos de seguridad',
      validation
    });
  }
  
  next();
};

module.exports = {
  validateRequest,
  sanitizeInput,
  validatePasswordStrength
};
