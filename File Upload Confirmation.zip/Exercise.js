const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ExerciseSchema = new Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['anchoring', 'timeline', 'beliefs', 'visualization', 'reframing'],
    required: true
  },
  level: {
    type: String,
    enum: ['beginners', 'intermediate', 'advanced'],
    required: true
  },
  duration: {
    type: Number,
    required: true,
    min: 1
  },
  steps: [{
    order: Number,
    title: String,
    description: String,
    audioPrompt: String,
    imageUrl: String
  }],
  benefits: [String],
  languages: {
    es: {
      title: String,
      description: String,
      steps: [{
        title: String,
        description: String,
        audioPrompt: String
      }],
      benefits: [String]
    },
    en: {
      title: String,
      description: String,
      steps: [{
        title: String,
        description: String,
        audioPrompt: String
      }],
      benefits: [String]
    },
    fr: {
      title: String,
      description: String,
      steps: [{
        title: String,
        description: String,
        audioPrompt: String
      }],
      benefits: [String]
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Exercise', ExerciseSchema);
