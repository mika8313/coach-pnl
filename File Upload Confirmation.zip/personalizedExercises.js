const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const Exercise = require('../models/Exercise');
const User = require('../models/User');
const OpenAIPNLService = require('../services/OpenAIPNLService');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   POST api/exercises/personalized
 * @desc    Generar un ejercicio personalizado basado en el estado emocional y objetivos
 * @access  Private
 */
router.post('/personalized', auth, async (req, res) => {
  try {
    const { emotionalState, language = 'es' } = req.body;
    
    // Obtener usuario y sus objetivos
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    // Si no se proporciona un estado emocional, usar uno neutral
    const userEmotionalState = emotionalState || { state: 'neutral', intensity: 0.5 };
    
    // Generar ejercicio personalizado
    const exercise = await OpenAIPNLService.generatePersonalizedExercise(
      user,
      userEmotionalState,
      user.goals || [],
      language
    );
    
    res.json(exercise);
  } catch (err) {
    console.error('Error generando ejercicio personalizado:', err.message);
    res.status(500).send('Error en el servidor');
  }
});

module.exports = router;
