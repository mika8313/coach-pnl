import React from 'react';
import { useTranslation } from 'react-i18next';

const Footer: React.FC = () => {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-zen-dark text-white py-8">
      <div className="container-zen">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.about')}</h3>
            <p className="text-zen-cream opacity-80">
              {t('footer.aboutText')}
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.links')}</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-zen-cream opacity-80 hover:opacity-100 transition-opacity">
                  {t('footer.termsOfService')}
                </a>
              </li>
              <li>
                <a href="#" className="text-zen-cream opacity-80 hover:opacity-100 transition-opacity">
                  {t('footer.privacyPolicy')}
                </a>
              </li>
              <li>
                <a href="#" className="text-zen-cream opacity-80 hover:opacity-100 transition-opacity">
                  {t('footer.contact')}
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.newsletter')}</h3>
            <p className="text-zen-cream opacity-80 mb-4">
              {t('footer.newsletterText')}
            </p>
            <div className="flex">
              <input 
                type="email" 
                placeholder={t('footer.emailPlaceholder')}
                className="px-4 py-2 rounded-l-lg focus:outline-none flex-grow"
              />
              <button className="bg-zen-green px-4 py-2 rounded-r-lg hover:bg-opacity-90 transition-colors">
                {t('footer.subscribe')}
              </button>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t border-zen-cream border-opacity-20 text-center">
          <p className="text-zen-cream opacity-60">
            &copy; {currentYear} PNL Coach. {t('footer.allRightsReserved')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
