# Política de Privacidad - PNL Coach

Fecha de última actualización: 10 de abril de 2025

## 1. Introducción

Bienvenido a PNL Coach. Valoramos y respetamos su privacidad. Esta Política de Privacidad explica cómo recopilamos, utilizamos, divulgamos y protegemos su información cuando utiliza nuestra aplicación móvil PNL Coach ("la Aplicación").

Por favor, lea esta política detenidamente para entender nuestras prácticas con respecto a sus datos personales y cómo los trataremos.

## 2. Información que recopilamos

### 2.1 Información proporcionada por usted

- **Información de registro**: Cuando crea una cuenta, recopilamos su nombre, dirección de correo electrónico y contraseña.
- **Información de perfil**: Información adicional que decide proporcionar, como fotografía de perfil, preferencias de idioma y objetivos personales.
- **Contenido generado por el usuario**: Entradas de diario, conversaciones con el coach de IA, ejercicios completados y cualquier otro contenido que cree mientras utiliza la Aplicación.
- **Grabaciones de voz**: Cuando utiliza las funciones de interacción por voz, recopilamos grabaciones de audio temporales para procesar sus solicitudes.

### 2.2 Información recopilada automáticamente

- **Información del dispositivo**: Tipo de dispositivo, sistema operativo, identificadores únicos de dispositivo.
- **Información de uso**: Cómo interactúa con la Aplicación, funciones que utiliza, tiempo de uso, patrones de navegación.
- **Información de diagnóstico**: Registros de errores, problemas de rendimiento.

## 3. Cómo utilizamos su información

Utilizamos la información recopilada para:

- Proporcionar, mantener y mejorar la Aplicación.
- Personalizar su experiencia y ofrecer contenido adaptado a sus necesidades.
- Procesar y responder a sus solicitudes, preguntas y comentarios.
- Enviar notificaciones relacionadas con su cuenta o actividad en la Aplicación.
- Analizar tendencias de uso y mejorar nuestros servicios.
- Detectar, investigar y prevenir actividades fraudulentas o no autorizadas.
- Cumplir con obligaciones legales.

## 4. Compartición de información

No vendemos su información personal a terceros. Podemos compartir su información en las siguientes circunstancias:

- **Proveedores de servicios**: Compartimos información con proveedores de servicios que nos ayudan a operar, desarrollar o mejorar la Aplicación (como servicios de alojamiento, análisis y procesamiento de pagos).
- **Cumplimiento legal**: Podemos divulgar información si creemos de buena fe que es necesario para cumplir con la ley, regulaciones, procesos legales o solicitudes gubernamentales.
- **Protección de derechos**: Podemos divulgar información para proteger los derechos, la propiedad o la seguridad de nuestra empresa, nuestros usuarios u otros.
- **Con su consentimiento**: Podemos compartir información con terceros cuando nos dé su consentimiento para hacerlo.

## 5. Seguridad de datos

Implementamos medidas de seguridad técnicas, administrativas y físicas diseñadas para proteger la información personal contra pérdida, robo, uso indebido y acceso no autorizado. Sin embargo, ningún sistema de seguridad es impenetrable y no podemos garantizar la seguridad absoluta de su información.

## 6. Sus derechos y opciones

Dependiendo de su ubicación, puede tener ciertos derechos con respecto a sus datos personales, incluyendo:

- Acceder a sus datos personales.
- Corregir datos inexactos o incompletos.
- Eliminar sus datos personales.
- Restringir u oponerse al procesamiento de sus datos.
- Solicitar la portabilidad de sus datos.
- Retirar su consentimiento en cualquier momento.

Para ejercer estos derechos, contáctenos a través de la información proporcionada en la sección "Contáctenos".

## 7. Retención de datos

Conservamos su información personal mientras sea necesario para los fines establecidos en esta Política de Privacidad, a menos que la ley exija o permita un período de retención más largo. Cuando ya no necesitemos usar su información, la eliminaremos o anonimizaremos.

## 8. Transferencias internacionales de datos

Su información puede ser transferida y procesada en países distintos al suyo, donde nuestros servidores están ubicados. Estos países pueden tener leyes de protección de datos diferentes a las de su país. Tomamos medidas para garantizar que sus datos personales reciban un nivel adecuado de protección.

## 9. Cambios a esta política

Podemos actualizar esta Política de Privacidad periódicamente. Le notificaremos cualquier cambio material publicando la nueva Política de Privacidad en esta página y, si los cambios son significativos, le proporcionaremos una notificación más destacada.

## 10. Contáctenos

Si tiene preguntas o inquietudes sobre esta Política de Privacidad o nuestras prácticas de datos, contáctenos en:

Email: privacy@pnlcoach.com

PNL Coach
123 Avenue de la Programmation
75000 Paris, France
