# Documentación de PNL Coach

## Introducción

PNL Coach es una aplicación móvil completa de coaching con IA especializada en Programación Neuro-Lingüística (PNL). La aplicación ofrece una experiencia personalizada de coaching a través de un chatbot inteligente, ejercicios interactivos, análisis de emociones, y seguimiento de progreso, todo ello con soporte para múltiples idiomas (español, francés e inglés) e integración de voz.

Este documento proporciona una visión general de la arquitectura, componentes, funcionalidades y guías de uso de la aplicación PNL Coach.

## Tabla de Contenidos

1. [Arquitectura del Sistema](#arquitectura-del-sistema)
2. [Componentes Principales](#componentes-principales)
3. [Tecnologías Utilizadas](#tecnologías-utilizadas)
4. [Instalación y Configuración](#instalación-y-configuración)
5. [Guía de Uso](#guía-de-uso)
6. [API REST](#api-rest)
7. [Integración con IA](#integración-con-ia)
8. [Sistema Multilingüe](#sistema-multilingüe)
9. [Integración de Voz](#integración-de-voz)
10. [Seguridad](#seguridad)
11. [Pruebas](#pruebas)
12. [Despliegue](#despliegue)
13. [Mantenimiento](#mantenimiento)
14. [Preguntas Frecuentes](#preguntas-frecuentes)

## Arquitectura del Sistema

PNL Coach sigue una arquitectura cliente-servidor con una aplicación móvil React Native en el frontend y un servidor Node.js con Express en el backend. La aplicación utiliza MongoDB como base de datos y se integra con servicios externos como OpenAI para las funcionalidades de IA y ElevenLabs para la síntesis de voz.

### Diagrama de Arquitectura

```
+-------------------+      +-------------------+      +-------------------+
|                   |      |                   |      |                   |
|  Aplicación Móvil |<---->|  Backend API REST |<---->|  Base de Datos    |
|  (React Native)   |      |  (Node.js/Express)|      |  (MongoDB)        |
|                   |      |                   |      |                   |
+-------------------+      +-------------------+      +-------------------+
         ^                          ^
         |                          |
         v                          v
+-------------------+      +-------------------+
|                   |      |                   |
|  OpenAI API       |      |  ElevenLabs API   |
|  (GPT-4, Whisper) |      |  (Síntesis Voz)   |
|                   |      |                   |
+-------------------+      +-------------------+
```

### Flujo de Datos

1. El usuario interactúa con la aplicación móvil
2. La aplicación móvil envía solicitudes al backend API REST
3. El backend procesa las solicitudes, interactúa con la base de datos y servicios externos
4. El backend devuelve respuestas a la aplicación móvil
5. La aplicación móvil actualiza la interfaz de usuario

## Componentes Principales

### Aplicación Móvil (Frontend)

- **Pantallas Principales**:
  - Bienvenida y Autenticación
  - Inicio (Dashboard)
  - Chat con Coach IA
  - Ejercicios de PNL
  - Progreso y Estadísticas
  - Perfil de Usuario

- **Componentes Clave**:
  - Sistema de Navegación
  - Interfaz de Chat
  - Reproductor de Ejercicios
  - Visualización de Progreso
  - Selector de Idioma
  - Interfaz de Voz

### Backend (API REST)

- **Módulos Principales**:
  - Autenticación y Gestión de Usuarios
  - Gestión de Ejercicios de PNL
  - Motor de Chat con IA
  - Análisis de Emociones
  - Seguimiento de Progreso
  - Integración de Voz (TTS/STT)
  - Sistema Multilingüe

- **Servicios**:
  - AuthService
  - OpenAIPNLService
  - ProgressTrackingService
  - VoiceIntegrationService
  - SecurityService
  - TextToSpeechService
  - SpeechToTextService
  - VoiceEmotionService
  - I18nService

## Tecnologías Utilizadas

### Frontend
- React Native
- TypeScript
- React Navigation
- Redux Toolkit
- Axios
- i18next
- React Native Voice
- React Native Sound

### Backend
- Node.js
- Express
- MongoDB
- Mongoose
- JWT
- bcrypt
- Axios
- Multer
- Express Validator
- Winston (logging)

### Servicios Externos
- OpenAI GPT-4 (Chatbot PNL)
- OpenAI Whisper (Reconocimiento de Voz)
- ElevenLabs (Síntesis de Voz)

### Herramientas de Desarrollo
- Jest (Pruebas)
- Detox (Pruebas E2E)
- ESLint
- Prettier
- Husky (Git Hooks)

## Instalación y Configuración

### Requisitos Previos
- Node.js 16+
- MongoDB 4.4+
- Xcode 13+ (para iOS)
- Android Studio (para Android)
- Cuenta de OpenAI con API Key
- Cuenta de ElevenLabs con API Key

### Configuración del Backend

1. Clonar el repositorio:
```bash
git clone https://github.com/pnlcoach/pnl-coach-app.git
cd pnl-coach-app/backend
```

2. Instalar dependencias:
```bash
npm install
```

3. Configurar variables de entorno:
```bash
cp .env.example .env
```

4. Editar el archivo `.env` con tus credenciales:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/pnl-coach
JWT_SECRET=tu_secreto_jwt
OPENAI_API_KEY=tu_clave_api_openai
ELEVENLABS_API_KEY=tu_clave_api_elevenlabs
```

5. Iniciar el servidor:
```bash
npm run dev
```

### Configuración de la Aplicación Móvil

1. Navegar al directorio de la aplicación móvil:
```bash
cd ../mobile
```

2. Instalar dependencias:
```bash
npm install
```

3. Instalar pods (solo iOS):
```bash
cd ios && pod install && cd ..
```

4. Configurar variables de entorno:
```bash
cp .env.example .env
```

5. Editar el archivo `.env` con la URL del backend:
```
API_URL=http://localhost:5000/api
```

6. Iniciar la aplicación:
```bash
# Para iOS
npm run ios

# Para Android
npm run android
```

## Guía de Uso

### Registro e Inicio de Sesión

1. Al abrir la aplicación por primera vez, se mostrará la pantalla de bienvenida
2. Selecciona "Crear una cuenta" para registrarte
3. Completa el formulario con tu nombre, correo electrónico y contraseña
4. Después de registrarte, serás redirigido a la pantalla principal
5. Para inicios posteriores, usa la opción "Iniciar sesión" con tu correo y contraseña

### Chat con Coach IA

1. Navega a la pestaña "Coach" en la barra inferior
2. Escribe tu mensaje en el campo de texto y presiona enviar
3. El coach IA responderá utilizando técnicas de PNL
4. Puedes usar el botón de micrófono para hablar en lugar de escribir
5. Las conversaciones se guardan automáticamente para futuras referencias

### Ejercicios de PNL

1. Navega a la pestaña "Ejercicios" en la barra inferior
2. Explora las diferentes categorías de ejercicios disponibles
3. Selecciona un ejercicio para ver sus detalles
4. Presiona "Comenzar" para iniciar el ejercicio
5. Sigue las instrucciones paso a paso
6. Al finalizar, recibirás retroalimentación y se registrará tu progreso

### Seguimiento de Progreso

1. Navega a la pestaña "Progreso" en la barra inferior
2. Visualiza estadísticas sobre tu uso de la aplicación
3. Revisa los ejercicios completados y técnicas practicadas
4. Consulta tu nivel actual y puntos de experiencia
5. Recibe recomendaciones personalizadas basadas en tu progreso

### Cambio de Idioma

1. Navega a la pestaña "Perfil" en la barra inferior
2. Selecciona "Configuración de idioma"
3. Elige entre español, francés o inglés
4. La aplicación se actualizará inmediatamente al nuevo idioma

## API REST

La API REST del backend sigue principios RESTful y utiliza JWT para autenticación. A continuación se detallan los principales endpoints:

### Autenticación

- `POST /api/auth/register` - Registrar un nuevo usuario
- `POST /api/auth/login` - Iniciar sesión
- `GET /api/auth/user` - Obtener información del usuario actual
- `PUT /api/auth/user` - Actualizar información del usuario
- `POST /api/auth/change-password` - Cambiar contraseña

### Ejercicios

- `GET /api/exercises` - Obtener lista de ejercicios
- `GET /api/exercises/:id` - Obtener un ejercicio específico
- `POST /api/exercises` - Crear un nuevo ejercicio
- `PUT /api/exercises/:id` - Actualizar un ejercicio
- `DELETE /api/exercises/:id` - Eliminar un ejercicio

### Chat

- `POST /api/chat/message` - Enviar mensaje al coach IA
- `GET /api/chat/conversations` - Obtener conversaciones del usuario
- `GET /api/chat/conversations/:id` - Obtener una conversación específica
- `DELETE /api/chat/conversations/:id` - Eliminar una conversación

### Progreso

- `POST /api/progress/exercise-completion` - Registrar finalización de ejercicio
- `POST /api/progress/journal-entry` - Registrar entrada de diario
- `POST /api/progress/coach-interaction` - Registrar interacción con coach
- `GET /api/progress/report` - Obtener informe de progreso
- `GET /api/progress/recommendations` - Obtener recomendaciones personalizadas
- `GET /api/progress/stats` - Obtener estadísticas de progreso

### Voz

- `POST /api/tts` - Convertir texto a voz
- `POST /api/stt` - Convertir voz a texto
- `POST /api/voice/interact` - Interacción completa por voz
- `PUT /api/voice/preferences` - Actualizar preferencias de voz
- `GET /api/voice/available-voices` - Obtener voces disponibles

### Internacionalización

- `GET /api/i18n/translations/:lang` - Obtener traducciones para un idioma
- `GET /api/i18n/available-languages` - Obtener idiomas disponibles

## Integración con IA

PNL Coach utiliza OpenAI GPT-4 para proporcionar coaching basado en técnicas de PNL. La integración se realiza a través del servicio `OpenAIPNLService` que implementa las siguientes funcionalidades:

### Generación de Respuestas PNL

El sistema utiliza prompts especializados para instruir al modelo GPT-4 a actuar como un coach de PNL, aplicando técnicas específicas como:

- Reencuadre (Reframing)
- Anclaje (Anchoring)
- Rapport
- Submodalidades
- Metamodelo
- Línea temporal
- Visualización

### Análisis de Estados Emocionales

El sistema analiza el texto y la voz del usuario para detectar estados emocionales, lo que permite al coach IA adaptar sus respuestas según el estado emocional actual del usuario.

### Generación de Ejercicios Personalizados

Basándose en el perfil del usuario, sus objetivos y su progreso, el sistema puede generar ejercicios de PNL personalizados adaptados a sus necesidades específicas.

## Sistema Multilingüe

PNL Coach implementa un sistema completo de internacionalización que soporta español, francés e inglés. El sistema incluye:

### Frontend

- Utiliza i18next para gestionar traducciones
- Detecta automáticamente el idioma del dispositivo
- Permite cambiar el idioma manualmente
- Almacena la preferencia de idioma del usuario

### Backend

- Middleware de idioma que detecta el idioma preferido del usuario
- Traducciones para todos los mensajes del sistema
- Adaptación de las respuestas de IA al idioma seleccionado
- Soporte multilingüe en síntesis y reconocimiento de voz

## Integración de Voz

PNL Coach integra capacidades avanzadas de voz para una experiencia más natural e inmersiva:

### Síntesis de Voz (TTS)

- Utiliza ElevenLabs para generar voz natural y expresiva
- Soporta múltiples idiomas (español, francés, inglés)
- Permite personalizar la voz (tipo, velocidad)
- Genera audio de alta calidad para las respuestas del coach

### Reconocimiento de Voz (STT)

- Utiliza OpenAI Whisper para transcripción precisa
- Soporta múltiples idiomas
- Funciona en entornos ruidosos
- Transcribe en tiempo real

### Análisis de Emociones en Voz

- Detecta estados emocionales a través de patrones de voz
- Identifica intensidad emocional
- Adapta las respuestas del coach según el estado emocional detectado

## Seguridad

PNL Coach implementa múltiples capas de seguridad para proteger los datos de los usuarios:

### Autenticación y Autorización

- JWT para autenticación de API
- Contraseñas hasheadas con bcrypt
- Middleware de autenticación para rutas protegidas
- Validación de roles y permisos

### Protección de Datos

- Cifrado de datos sensibles
- Sanitización de entradas para prevenir inyecciones
- Validación de datos con express-validator
- Políticas de CORS configuradas

### Limitación de Tasa

- Protección contra ataques de fuerza bruta
- Límites de solicitudes por IP
- Límites más estrictos para rutas sensibles

### Seguridad en Dispositivos Móviles

- Almacenamiento seguro de tokens
- Detección opcional de dispositivos rooteados/con jailbreak
- Bloqueo de capturas de pantalla en pantallas sensibles
- Cierre de sesión automático por inactividad

## Pruebas

PNL Coach incluye un conjunto completo de pruebas para garantizar la calidad y estabilidad del código:

### Pruebas Unitarias

- Pruebas para servicios individuales
- Mocks para dependencias externas
- Cobertura de código superior al 70%

### Pruebas de Integración

- Pruebas para rutas de API
- Verificación de flujos completos
- Base de datos de prueba separada

### Pruebas End-to-End (E2E)

- Pruebas de flujos de usuario completos
- Verificación de la interfaz de usuario
- Simulación de interacciones de usuario

### Ejecución de Pruebas

Para ejecutar las pruebas, utiliza los siguientes comandos:

```bash
# Ejecutar todas las pruebas
node scripts/run-tests.js

# Ejecutar pruebas unitarias del backend
cd backend && npm run test:unit

# Ejecutar pruebas de integración del backend
cd backend && npm run test:integration

# Ejecutar pruebas E2E de la aplicación móvil
cd mobile && npm run test:e2e
```

## Despliegue

### Backend

El backend puede desplegarse en cualquier servidor que soporte Node.js:

1. Clonar el repositorio en el servidor
2. Instalar dependencias: `npm install --production`
3. Configurar variables de entorno para producción
4. Iniciar el servidor: `npm start`

Recomendamos utilizar PM2 para gestionar el proceso en producción:

```bash
npm install -g pm2
pm2 start src/index.js --name pnl-coach-backend
```

### Aplicación Móvil

Para publicar la aplicación en las tiendas:

#### App Store (iOS)

1. Configurar app.json con los datos de la aplicación
2. Generar certificados y perfiles de aprovisionamiento
3. Construir la aplicación para producción: `npm run build:ios`
4. Subir el archivo IPA a App Store Connect
5. Completar la información de la aplicación
6. Enviar para revisión

#### Google Play (Android)

1. Configurar app.json con los datos de la aplicación
2. Generar una clave de firma
3. Construir la aplicación para producción: `npm run build:android`
4. Subir el archivo APK/AAB a Google Play Console
5. Completar la información de la aplicación
6. Publicar en Google Play

## Mantenimiento

### Actualizaciones

- Mantener las dependencias actualizadas regularmente
- Revisar y aplicar parches de seguridad
- Actualizar las integraciones con APIs externas cuando sea necesario

### Monitoreo

- Implementar logging para seguimiento de errores
- Configurar alertas para problemas críticos
- Monitorear el rendimiento de la aplicación

### Copias de Seguridad

- Realizar copias de seguridad regulares de la base de datos
- Almacenar copias de seguridad en ubicaciones seguras
- Probar la restauración de copias de seguridad periódicamente

## Preguntas Frecuentes

### ¿Cómo puedo cambiar el idioma de la aplicación?
Navega a la pestaña "Perfil", selecciona "Configuración de idioma" y elige el idioma deseado.

### ¿Mis conversaciones con el coach son privadas?
Sí, todas las conversaciones se almacenan de forma segura y solo son accesibles por ti.

### ¿Puedo usar la aplicación sin conexión a internet?
Algunas funcionalidades básicas están disponibles sin conexión, pero las funciones de IA y voz requieren conexión a internet.

### ¿Cómo se calculan mis puntos de experiencia y nivel?
Los puntos se obtienen completando ejercicios, interactuando con el coach y escribiendo en el diario. Tu nivel se calcula mediante una fórmula basada en tus puntos de experiencia.

### ¿Puedo exportar mis datos?
Sí, puedes exportar tus datos desde la sección de perfil. Recibirás un archivo con todas tus conversaciones, ejercicios completados y progreso.

### ¿Cómo puedo reportar un problema?
En la sección de perfil, selecciona "Soporte" y utiliza el formulario para reportar cualquier problema que encuentres.
