/**
 * Pruebas de integración para las rutas de autenticación
 */
const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const User = require('../../src/models/User');
const SecurityService = require('../../src/services/SecurityService');

describe('Auth Routes Integration Tests', () => {
  beforeAll(async () => {
    // Conectar a la base de datos de prueba
    await mongoose.connect(process.env.MONGODB_URI_TEST || 'mongodb://localhost:27017/pnl-coach-test', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    // Limpiar la colección de usuarios antes de las pruebas
    await User.deleteMany({});
  });

  afterAll(async () => {
    // Desconectar de la base de datos después de las pruebas
    await mongoose.connection.close();
  });

  describe('POST /api/auth/register', () => {
    it('debe registrar un nuevo usuario correctamente', async () => {
      const userData = {
        name: 'Test User',
        email: 'test@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(200);
      
      // Verificar respuesta
      expect(response.body).toHaveProperty('token');
      expect(response.body.user).toHaveProperty('id');
      expect(response.body.user.name).toBe(userData.name);
      expect(response.body.user.email).toBe(userData.email);
      expect(response.body.user).not.toHaveProperty('password');
      
      // Verificar que el usuario se guardó en la base de datos
      const savedUser = await User.findOne({ email: userData.email });
      expect(savedUser).not.toBeNull();
      expect(savedUser.name).toBe(userData.name);
    });

    it('debe devolver error si el usuario ya existe', async () => {
      const userData = {
        name: 'Existing User',
        email: 'existing@example.com',
        password: 'Password123!'
      };
      
      // Crear usuario primero
      await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(200);
      
      // Intentar crear el mismo usuario de nuevo
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(400);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('ya existe');
    });

    it('debe validar los campos requeridos', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Incomplete User'
          // Falta email y password
        })
        .expect(400);
      
      expect(response.body).toHaveProperty('errors');
      expect(response.body.errors.length).toBeGreaterThan(0);
    });
  });

  describe('POST /api/auth/login', () => {
    beforeEach(async () => {
      // Crear un usuario para las pruebas de login
      const hashedPassword = await SecurityService.hashPassword('Password123!');
      await User.create({
        name: 'Login Test User',
        email: 'login@example.com',
        password: hashedPassword
      });
    });

    it('debe iniciar sesión correctamente con credenciales válidas', async () => {
      const loginData = {
        email: 'login@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(200);
      
      expect(response.body).toHaveProperty('token');
      expect(response.body.user).toHaveProperty('id');
      expect(response.body.user.name).toBe('Login Test User');
      expect(response.body.user.email).toBe(loginData.email);
    });

    it('debe devolver error con credenciales inválidas', async () => {
      const loginData = {
        email: 'login@example.com',
        password: 'WrongPassword123!'
      };
      
      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('inválidas');
    });

    it('debe devolver error si el usuario no existe', async () => {
      const loginData = {
        email: 'nonexistent@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('inválidas');
    });
  });

  describe('GET /api/auth/user', () => {
    let token;
    let userId;
    
    beforeEach(async () => {
      // Crear un usuario y obtener token para las pruebas
      const userData = {
        name: 'Auth User',
        email: 'auth@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData);
      
      token = response.body.token;
      userId = response.body.user.id;
    });

    it('debe obtener el perfil del usuario autenticado', async () => {
      const response = await request(app)
        .get('/api/auth/user')
        .set('x-auth-token', token)
        .expect(200);
      
      expect(response.body).toHaveProperty('id', userId);
      expect(response.body).toHaveProperty('name', 'Auth User');
      expect(response.body).toHaveProperty('email', 'auth@example.com');
    });

    it('debe devolver error sin token de autenticación', async () => {
      const response = await request(app)
        .get('/api/auth/user')
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('No hay token');
    });

    it('debe devolver error con token inválido', async () => {
      const response = await request(app)
        .get('/api/auth/user')
        .set('x-auth-token', 'invalid-token')
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('Token no válido');
    });
  });

  describe('PUT /api/auth/user', () => {
    let token;
    let userId;
    
    beforeEach(async () => {
      // Crear un usuario y obtener token para las pruebas
      const userData = {
        name: 'Update User',
        email: 'update@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData);
      
      token = response.body.token;
      userId = response.body.user.id;
    });

    it('debe actualizar el perfil del usuario correctamente', async () => {
      const updateData = {
        name: 'Updated Name',
        language: 'fr'
      };
      
      const response = await request(app)
        .put('/api/auth/user')
        .set('x-auth-token', token)
        .send(updateData)
        .expect(200);
      
      expect(response.body).toHaveProperty('id', userId);
      expect(response.body).toHaveProperty('name', 'Updated Name');
      expect(response.body).toHaveProperty('email', 'update@example.com');
      
      // Verificar que el usuario se actualizó en la base de datos
      const updatedUser = await User.findById(userId);
      expect(updatedUser.name).toBe('Updated Name');
      expect(updatedUser.language).toBe('fr');
    });

    it('debe devolver error sin autenticación', async () => {
      const updateData = {
        name: 'Updated Name'
      };
      
      const response = await request(app)
        .put('/api/auth/user')
        .send(updateData)
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('No hay token');
    });
  });

  describe('POST /api/auth/change-password', () => {
    let token;
    let userId;
    
    beforeEach(async () => {
      // Crear un usuario y obtener token para las pruebas
      const userData = {
        name: 'Password User',
        email: 'password@example.com',
        password: 'Password123!'
      };
      
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData);
      
      token = response.body.token;
      userId = response.body.user.id;
    });

    it('debe cambiar la contraseña correctamente', async () => {
      const passwordData = {
        currentPassword: 'Password123!',
        newPassword: 'NewPassword123!'
      };
      
      const response = await request(app)
        .post('/api/auth/change-password')
        .set('x-auth-token', token)
        .send(passwordData)
        .expect(200);
      
      expect(response.body).toHaveProperty('success', true);
      
      // Verificar que se puede iniciar sesión con la nueva contraseña
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'password@example.com',
          password: 'NewPassword123!'
        })
        .expect(200);
      
      expect(loginResponse.body).toHaveProperty('token');
    });

    it('debe devolver error si la contraseña actual es incorrecta', async () => {
      const passwordData = {
        currentPassword: 'WrongPassword123!',
        newPassword: 'NewPassword123!'
      };
      
      const response = await request(app)
        .post('/api/auth/change-password')
        .set('x-auth-token', token)
        .send(passwordData)
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('incorrecta');
    });
  });
});
