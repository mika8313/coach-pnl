const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const Exercise = require('../models/Exercise');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   GET api/exercises
 * @desc    Obtener todos los ejercicios
 * @access  Private
 */
router.get('/', auth, async (req, res) => {
  try {
    const { language = 'es', level, type } = req.query;
    
    // Construir filtro
    const filter = {};
    if (level) filter.level = level;
    if (type) filter.type = type;
    
    const exercises = await Exercise.find(filter);
    
    // Formatear respuesta según el idioma
    const formattedExercises = exercises.map(exercise => {
      const localizedData = exercise.languages[language] || exercise;
      return {
        id: exercise._id,
        title: localizedData.title || exercise.title,
        description: localizedData.description || exercise.description,
        type: exercise.type,
        level: exercise.level,
        duration: exercise.duration,
        steps: localizedData.steps || exercise.steps,
        benefits: localizedData.benefits || exercise.benefits
      };
    });
    
    res.json(formattedExercises);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/exercises/:id
 * @desc    Obtener un ejercicio específico
 * @access  Private
 */
router.get('/:id', auth, async (req, res) => {
  try {
    const { language = 'es' } = req.query;
    const exercise = await Exercise.findById(req.params.id);
    
    if (!exercise) {
      return res.status(404).json({ msg: 'Ejercicio no encontrado' });
    }
    
    // Formatear respuesta según el idioma
    const localizedData = exercise.languages[language] || {};
    const formattedExercise = {
      id: exercise._id,
      title: localizedData.title || exercise.title,
      description: localizedData.description || exercise.description,
      type: exercise.type,
      level: exercise.level,
      duration: exercise.duration,
      steps: localizedData.steps || exercise.steps,
      benefits: localizedData.benefits || exercise.benefits
    };
    
    res.json(formattedExercise);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Ejercicio no encontrado' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   POST api/exercises/complete/:id
 * @desc    Marcar un ejercicio como completado
 * @access  Private
 */
router.post('/complete/:id', auth, async (req, res) => {
  try {
    const exerciseId = req.params.id;
    const userId = req.user.id;
    
    // Verificar que el ejercicio existe
    const exercise = await Exercise.findById(exerciseId);
    if (!exercise) {
      return res.status(404).json({ msg: 'Ejercicio no encontrado' });
    }
    
    // Actualizar el progreso del usuario
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    // Verificar si el ejercicio ya está completado
    const alreadyCompleted = user.progress.completedExercises.includes(exerciseId);
    if (!alreadyCompleted) {
      // Añadir ejercicio a la lista de completados
      user.progress.completedExercises.push(exerciseId);
      user.progress.lastActivity = Date.now();
      
      // Actualizar racha (streak)
      const lastActivityDate = new Date(user.progress.lastActivity);
      const today = new Date();
      const diffDays = Math.floor((today - lastActivityDate) / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 1) {
        // Si la última actividad fue hoy o ayer, incrementar o mantener la racha
        user.progress.streak += 1;
      } else {
        // Si han pasado más días, reiniciar la racha
        user.progress.streak = 1;
      }
      
      await user.save();
    }
    
    res.json({ 
      msg: 'Ejercicio marcado como completado',
      progress: user.progress
    });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Ejercicio no encontrado' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   POST api/exercises
 * @desc    Crear un nuevo ejercicio (solo admin)
 * @access  Private/Admin
 */
router.post('/', [
  auth,
  [
    check('title', 'El título es obligatorio').not().isEmpty(),
    check('description', 'La descripción es obligatoria').not().isEmpty(),
    check('type', 'El tipo de ejercicio es obligatorio').isIn(['anchoring', 'timeline', 'beliefs', 'visualization', 'reframing']),
    check('level', 'El nivel es obligatorio').isIn(['beginners', 'intermediate', 'advanced']),
    check('duration', 'La duración es obligatoria').isNumeric()
  ]
], async (req, res) => {
  // Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    // Verificar si el usuario es admin (en una implementación real)
    // const user = await User.findById(req.user.id);
    // if (!user.isAdmin) {
    //   return res.status(401).json({ msg: 'No autorizado' });
    // }
    
    const { 
      title, 
      description, 
      type, 
      level, 
      duration, 
      steps, 
      benefits,
      languages 
    } = req.body;
    
    // Crear nuevo ejercicio
    const newExercise = new Exercise({
      title,
      description,
      type,
      level,
      duration,
      steps: steps || [],
      benefits: benefits || [],
      languages: languages || {}
    });
    
    const exercise = await newExercise.save();
    res.json(exercise);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

module.exports = router;
