const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const JournalEntrySchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  mood: {
    type: String,
    enum: ['great', 'good', 'neutral', 'bad', 'terrible'],
    required: true
  },
  moodIntensity: {
    type: Number,
    min: 1,
    max: 10,
    default: 5
  },
  notes: {
    type: String,
    required: true
  },
  achievements: [String],
  challenges: [String],
  insights: [String],
  tags: [String],
  relatedExercises: [{
    type: Schema.Types.ObjectId,
    ref: 'Exercise'
  }],
  emotionalAnalysis: {
    dominantEmotions: [String],
    emotionalTrends: [String],
    sentimentScore: Number
  },
  language: {
    type: String,
    enum: ['es', 'en', 'fr'],
    default: 'es'
  }
});

module.exports = mongoose.model('JournalEntry', JournalEntrySchema);
