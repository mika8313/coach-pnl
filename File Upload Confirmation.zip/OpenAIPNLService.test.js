/**
 * Pruebas unitarias para el servicio de PNL con OpenAI
 */
const OpenAIPNLService = require('../../src/services/OpenAIPNLService');
const axios = require('axios');
const config = require('../config');

// Mock de dependencias
jest.mock('axios');

describe('OpenAIPNLService', () => {
  beforeEach(() => {
    // Limpiar todos los mocks antes de cada prueba
    jest.clearAllMocks();
    
    // Configurar mock de process.env
    process.env.OPENAI_API_KEY = 'test-api-key';
  });

  describe('generatePNLResponse', () => {
    it('debe generar una respuesta de PNL correctamente', async () => {
      // Configurar mock de axios
      axios.post.mockResolvedValue({
        data: {
          choices: [
            {
              message: {
                content: 'Esta es una respuesta de PNL utilizando técnicas de reframing y anchoring.'
              }
            }
          ]
        }
      });
      
      // Datos de prueba
      const userMessage = 'Me siento ansioso por mi presentación mañana';
      const conversationHistory = [
        { role: 'user', content: 'Hola, necesito ayuda con mi ansiedad' },
        { role: 'assistant', content: 'Claro, puedo ayudarte con eso. ¿Qué te preocupa?' }
      ];
      const emotionalState = { state: 'anxious', intensity: 0.8 };
      const language = 'es';
      
      // Ejecutar función a probar
      const result = await OpenAIPNLService.generatePNLResponse(
        userMessage,
        conversationHistory,
        emotionalState,
        language
      );
      
      // Verificaciones
      expect(axios.post).toHaveBeenCalledWith(
        'https://api.openai.com/v1/chat/completions',
        expect.objectContaining({
          model: 'gpt-4',
          messages: expect.arrayContaining([
            { role: 'system', content: expect.stringContaining('coach de PNL') },
            { role: 'user', content: 'Hola, necesito ayuda con mi ansiedad' },
            { role: 'assistant', content: 'Claro, puedo ayudarte con eso. ¿Qué te preocupa?' },
            { role: 'user', content: 'Me siento ansioso por mi presentación mañana' }
          ])
        }),
        expect.objectContaining({
          headers: {
            'Authorization': 'Bearer test-api-key',
            'Content-Type': 'application/json'
          }
        })
      );
      
      expect(result).toEqual({
        message: 'Esta es una respuesta de PNL utilizando técnicas de reframing y anchoring.',
        techniques: ['reframing', 'anchoring']
      });
    });

    it('debe manejar errores de la API correctamente', async () => {
      // Configurar mock de axios para simular un error
      axios.post.mockRejectedValue(new Error('Error de API'));
      
      // Datos de prueba
      const userMessage = 'Me siento ansioso por mi presentación mañana';
      const conversationHistory = [];
      const emotionalState = { state: 'anxious', intensity: 0.8 };
      const language = 'es';
      
      // Ejecutar y verificar
      await expect(OpenAIPNLService.generatePNLResponse(
        userMessage,
        conversationHistory,
        emotionalState,
        language
      )).rejects.toThrow('Error generando respuesta de PNL');
      
      expect(axios.post).toHaveBeenCalled();
    });
  });

  describe('analyzeEmotionalState', () => {
    it('debe analizar el estado emocional correctamente', async () => {
      // Configurar mock de axios
      axios.post.mockResolvedValue({
        data: {
          choices: [
            {
              message: {
                content: JSON.stringify({
                  primaryEmotion: 'anxiety',
                  intensity: 0.75,
                  secondaryEmotions: ['fear', 'worry'],
                  analysis: 'El usuario muestra signos de ansiedad relacionada con una presentación futura.'
                })
              }
            }
          ]
        }
      });
      
      // Datos de prueba
      const text = 'Me siento muy nervioso por mi presentación de mañana, no puedo dormir pensando en ello';
      const language = 'es';
      
      // Ejecutar función a probar
      const result = await OpenAIPNLService.analyzeEmotionalState(text, language);
      
      // Verificaciones
      expect(axios.post).toHaveBeenCalledWith(
        'https://api.openai.com/v1/chat/completions',
        expect.objectContaining({
          model: 'gpt-4',
          messages: expect.arrayContaining([
            { role: 'system', content: expect.stringContaining('analizar el estado emocional') },
            { role: 'user', content: expect.stringContaining('Me siento muy nervioso') }
          ])
        }),
        expect.any(Object)
      );
      
      expect(result).toEqual({
        primaryEmotion: 'anxiety',
        intensity: 0.75,
        secondaryEmotions: ['fear', 'worry'],
        analysis: 'El usuario muestra signos de ansiedad relacionada con una presentación futura.'
      });
    });

    it('debe manejar respuestas JSON inválidas', async () => {
      // Configurar mock de axios con respuesta no JSON
      axios.post.mockResolvedValue({
        data: {
          choices: [
            {
              message: {
                content: 'Esto no es un JSON válido'
              }
            }
          ]
        }
      });
      
      // Datos de prueba
      const text = 'Me siento muy nervioso';
      const language = 'es';
      
      // Ejecutar función a probar
      const result = await OpenAIPNLService.analyzeEmotionalState(text, language);
      
      // Verificaciones
      expect(result).toEqual({
        primaryEmotion: 'unknown',
        intensity: 0.5,
        secondaryEmotions: [],
        analysis: 'No se pudo analizar el estado emocional'
      });
    });
  });

  describe('generatePersonalizedExercise', () => {
    it('debe generar un ejercicio personalizado correctamente', async () => {
      // Configurar mock de axios
      axios.post.mockResolvedValue({
        data: {
          choices: [
            {
              message: {
                content: JSON.stringify({
                  title: 'Anclaje de Confianza',
                  description: 'Este ejercicio te ayudará a crear un ancla para acceder a un estado de confianza',
                  steps: [
                    'Recuerda un momento en que te sentiste completamente confiado',
                    'Intensifica esa sensación',
                    'Crea un gesto como ancla'
                  ],
                  duration: 15,
                  difficulty: 'intermediate',
                  techniques: ['anchoring', 'visualization']
                })
              }
            }
          ]
        }
      });
      
      // Datos de prueba
      const userProfile = {
        emotionalState: 'anxiety',
        goals: ['Mejorar confianza', 'Reducir estrés'],
        completedExercises: ['Respiración consciente', 'Reencuadre positivo']
      };
      const language = 'es';
      
      // Ejecutar función a probar
      const result = await OpenAIPNLService.generatePersonalizedExercise(userProfile, language);
      
      // Verificaciones
      expect(axios.post).toHaveBeenCalledWith(
        'https://api.openai.com/v1/chat/completions',
        expect.objectContaining({
          model: 'gpt-4',
          messages: expect.arrayContaining([
            { role: 'system', content: expect.stringContaining('ejercicio personalizado de PNL') },
            { role: 'user', content: expect.stringContaining('Mejorar confianza') }
          ])
        }),
        expect.any(Object)
      );
      
      expect(result).toEqual({
        title: 'Anclaje de Confianza',
        description: 'Este ejercicio te ayudará a crear un ancla para acceder a un estado de confianza',
        steps: [
          'Recuerda un momento en que te sentiste completamente confiado',
          'Intensifica esa sensación',
          'Crea un gesto como ancla'
        ],
        duration: 15,
        difficulty: 'intermediate',
        techniques: ['anchoring', 'visualization']
      });
    });
  });
});
