import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-zen-cream to-zen-gray rounded-3xl mb-12">
        <div className="container-zen text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-zen-dark mb-6">
            {t('home.hero.title')}
          </h1>
          <p className="text-xl md:text-2xl text-neutral-darkest max-w-3xl mx-auto mb-8">
            {t('home.hero.subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/register" className="btn btn-primary text-lg px-8 py-3">
              {t('home.hero.startButton')}
            </Link>
            <Link to="/login" className="btn btn-secondary text-lg px-8 py-3">
              {t('home.hero.loginButton')}
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 mb-12">
        <div className="container-zen">
          <h2 className="text-3xl md:text-4xl font-bold text-zen-dark text-center mb-12">
            {t('home.features.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature1.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature1.description')}</p>
            </div>

            {/* Feature 2 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature2.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature2.description')}</p>
            </div>

            {/* Feature 3 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature3.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature3.description')}</p>
            </div>

            {/* Feature 4 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature4.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature4.description')}</p>
            </div>

            {/* Feature 5 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature5.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature5.description')}</p>
            </div>

            {/* Feature 6 */}
            <div className="card hover:shadow-lg transition-shadow">
              <div className="bg-zen-green bg-opacity-10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zen-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.features.feature6.title')}</h3>
              <p className="text-neutral-darkest">{t('home.features.feature6.description')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12 bg-zen-cream rounded-3xl mb-12">
        <div className="container-zen">
          <h2 className="text-3xl md:text-4xl font-bold text-zen-dark text-center mb-12">
            {t('home.howItWorks.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-soft">
                <span className="text-2xl font-bold text-zen-green">1</span>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.howItWorks.step1.title')}</h3>
              <p className="text-neutral-darkest">{t('home.howItWorks.step1.description')}</p>
            </div>

            {/* Step 2 */}
            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-soft">
                <span className="text-2xl font-bold text-zen-green">2</span>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.howItWorks.step2.title')}</h3>
              <p className="text-neutral-darkest">{t('home.howItWorks.step2.description')}</p>
            </div>

            {/* Step 3 */}
            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-soft">
                <span className="text-2xl font-bold text-zen-green">3</span>
              </div>
              <h3 className="text-xl font-bold text-zen-dark mb-2">{t('home.howItWorks.step3.title')}</h3>
              <p className="text-neutral-darkest">{t('home.howItWorks.step3.description')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 mb-12">
        <div className="container-zen">
          <div className="bg-zen-green rounded-3xl p-8 md:p-12 text-white text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">{t('home.cta.title')}</h2>
            <p className="text-xl max-w-3xl mx-auto mb-8">{t('home.cta.description')}</p>
            <Link to="/register" className="btn bg-white text-zen-dark hover:bg-zen-cream text-lg px-8 py-3 inline-block">
              {t('home.cta.button')}
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-12 mb-12">
        <div className="container-zen">
          <h2 className="text-3xl md:text-4xl font-bold text-zen-dark text-center mb-12">
            {t('home.testimonials.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="card">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-zen-green rounded-full flex items-center justify-center text-white font-bold mr-4">
                  {t('home.testimonials.testimonial1.initials')}
                </div>
                <div>
                  <h3 className="font-bold text-zen-dark">{t('home.testimonials.testimonial1.name')}</h3>
                  <p className="text-sm text-neutral-dark">{t('home.testimonials.testimonial1.location')}</p>
                </div>
              </div>
              <p className="text-neutral-darkest italic">"{t('home.testimonials.testimonial1.text')}"</p>
            </div>

            {/* Testimonial 2 */}
            <div className="card">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-zen-blue rounded-full flex items-center justify-center text-white font-bold mr-4">
                  {t('home.testimonials.testimonial2.initials')}
                </div>
                <div>
                  <h3 className="font-bold text-zen-dark">{t('home.testimonials.testimonial2.name')}</h3>
                  <p className="text-sm text-neutral-dark">{t('home.testimonials.testimonial2.location')}</p>
                </div>
              </div>
              <p className="text-neutral-darkest italic">"{t('home.testimonials.testimonial2.text')}"</p>
            </div>

            {/* Testimonial 3 */}
            <div className="card">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-zen-gray rounded-full flex items-center justify-center text-white font-bold mr-4">
                  {t('home.testimonials.testimonial3.initials')}
                </div>
                <div>
                  <h3 className="font-bold text-zen-dark">{t('home.testimonials.testimonial3.name')}</h3>
                  <p className="text-sm text-neutral-dark">{t('home.testimonials.testimonial3.location')}</p>
                </div>
              </div>
              <p className="text-neutral-darkest italic">"{t('home.testimonials.testimonial3.text')}"</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
