module.exports = {
  presets: ['module:metro-react-native-babel-preset'],
  plugins: [
    [
      'module-resolver',
      {
        root: ['./src'],
        extensions: ['.ios.js', '.android.js', '.js', '.ts', '.tsx', '.json'],
        alias: {
          '@': './src',
          '@components': './src/components',
          '@screens': './src/screens',
          '@navigation': './src/navigation',
          '@services': './src/services',
          '@hooks': './src/hooks',
          '@context': './src/context',
          '@utils': './src/utils',
          '@i18n': './src/i18n',
          '@assets': './src/assets',
          '@styles': './src/styles'
        }
      }
    ],
    'react-native-reanimated/plugin'
  ]
};
