const { OpenAI } = require('openai');
const dotenv = require('dotenv');

// Cargar variables de entorno
dotenv.config();

// Configuración de OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

/**
 * Servicio para integrar funcionalidades de IA de PNL con OpenAI
 */
class OpenAIPNLService {
  /**
   * Genera una respuesta de coaching PNL basada en el mensaje del usuario
   * @param {string} userMessage - Mensaje del usuario
   * @param {Array} conversationHistory - Historial de la conversación
   * @param {Object} emotionalState - Estado emocional detectado
   * @param {string} language - Idioma de la respuesta (es, en, fr)
   * @returns {Promise<Object>} - Respuesta generada y técnicas de PNL utilizadas
   */
  async generatePNLResponse(userMessage, conversationHistory, emotionalState, language = 'es') {
    try {
      // Preparar el historial de conversación para OpenAI
      const messages = this._prepareConversationHistory(conversationHistory);
      
      // Añadir instrucciones específicas de PNL según el estado emocional
      const systemPrompt = this._createPNLSystemPrompt(emotionalState, language);
      
      // Añadir el mensaje del sistema al principio
      messages.unshift({
        role: "system",
        content: systemPrompt
      });

      // Realizar la llamada a la API de OpenAI
      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: messages,
        max_tokens: 500,
        temperature: 0.7,
      });

      // Extraer técnicas de PNL utilizadas (simulado por ahora)
      const techniques = this._extractPNLTechniques(completion.choices[0].message.content);

      return {
        message: completion.choices[0].message.content,
        techniques: techniques
      };
    } catch (error) {
      console.error('Error generando respuesta PNL con OpenAI:', error);
      throw error;
    }
  }

  /**
   * Analiza el estado emocional del texto utilizando OpenAI
   * @param {string} text - Texto a analizar
   * @param {string} language - Idioma del texto
   * @returns {Promise<Object>} - Estado emocional detectado
   */
  async analyzeEmotionalState(text, language = 'es') {
    try {
      const prompt = `
        Analiza el siguiente texto y determina el estado emocional predominante del autor.
        Clasifica la emoción principal entre: neutral, happy, sad, angry, anxious, confident, confused, frustrated.
        También proporciona una intensidad de la emoción en una escala de 0 a 1, donde 0 es muy baja y 1 es muy alta.
        Responde en formato JSON con dos campos: "state" e "intensity".
        
        Texto: "${text}"
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Eres un analizador de emociones preciso. Responde solo en formato JSON válido." },
          { role: "user", content: prompt }
        ],
        max_tokens: 150,
        temperature: 0.3,
        response_format: { type: "json_object" }
      });

      // Parsear la respuesta JSON
      const response = JSON.parse(completion.choices[0].message.content);
      return {
        state: response.state,
        intensity: response.intensity
      };
    } catch (error) {
      console.error('Error analizando estado emocional con OpenAI:', error);
      // Proporcionar un valor por defecto en caso de error
      return {
        state: 'neutral',
        intensity: 0.5
      };
    }
  }

  /**
   * Analiza el texto del diario para extraer insights emocionales
   * @param {string} journalText - Texto del diario
   * @param {string} language - Idioma del texto
   * @returns {Promise<Object>} - Análisis emocional del texto
   */
  async analyzeJournalEmotions(journalText, language = 'es') {
    try {
      const prompt = `
        Analiza el siguiente texto de diario personal y extrae:
        1. Las emociones dominantes (lista de 2-4 emociones)
        2. Tendencias emocionales observables (ej: "increasing_positivity", "emotional_fluctuation")
        3. Una puntuación de sentimiento general de -1 (muy negativo) a 1 (muy positivo)
        
        Responde en formato JSON con tres campos: "dominantEmotions" (array), "emotionalTrends" (array), y "sentimentScore" (número).
        
        Texto del diario: "${journalText}"
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Eres un psicólogo especializado en análisis emocional. Responde solo en formato JSON válido." },
          { role: "user", content: prompt }
        ],
        max_tokens: 250,
        temperature: 0.4,
        response_format: { type: "json_object" }
      });

      // Parsear la respuesta JSON
      return JSON.parse(completion.choices[0].message.content);
    } catch (error) {
      console.error('Error analizando emociones del diario con OpenAI:', error);
      // Proporcionar un valor por defecto en caso de error
      return {
        dominantEmotions: ['neutral'],
        emotionalTrends: ['stable_emotional_state'],
        sentimentScore: 0
      };
    }
  }

  /**
   * Genera un ejercicio personalizado de PNL basado en el estado emocional y objetivos
   * @param {Object} user - Información del usuario
   * @param {string} emotionalState - Estado emocional actual
   * @param {Array} goals - Objetivos del usuario
   * @param {string} language - Idioma del ejercicio
   * @returns {Promise<Object>} - Ejercicio de PNL generado
   */
  async generatePersonalizedExercise(user, emotionalState, goals, language = 'es') {
    try {
      const goalDescriptions = goals.map(g => g.title).join(", ");
      
      const prompt = `
        Genera un ejercicio personalizado de PNL (Programación Neuro-Lingüística) para un usuario con las siguientes características:
        - Estado emocional actual: ${emotionalState.state} (intensidad: ${emotionalState.intensity})
        - Objetivos personales: ${goalDescriptions}
        
        El ejercicio debe incluir:
        1. Un título atractivo
        2. Una descripción breve pero motivadora
        3. El tipo de técnica PNL (anchoring, timeline, beliefs, visualization, reframing)
        4. Nivel de dificultad (beginners, intermediate, advanced)
        5. Duración estimada en minutos
        6. Pasos detallados para realizar el ejercicio (mínimo 3, máximo 7 pasos)
        7. Beneficios esperados (lista de 3-5 beneficios)
        
        Responde en formato JSON con los campos: "title", "description", "type", "level", "duration", "steps" (array de objetos con "order", "title", "description"), "benefits" (array).
        
        El ejercicio debe estar en ${language === 'es' ? 'español' : language === 'fr' ? 'francés' : 'inglés'}.
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Eres un coach experto en PNL que crea ejercicios personalizados efectivos. Responde solo en formato JSON válido." },
          { role: "user", content: prompt }
        ],
        max_tokens: 800,
        temperature: 0.7,
        response_format: { type: "json_object" }
      });

      // Parsear la respuesta JSON
      return JSON.parse(completion.choices[0].message.content);
    } catch (error) {
      console.error('Error generando ejercicio personalizado con OpenAI:', error);
      throw error;
    }
  }

  /**
   * Genera un resumen de la conversación con insights de PNL
   * @param {Array} conversationHistory - Historial completo de la conversación
   * @param {string} language - Idioma del resumen
   * @returns {Promise<Object>} - Resumen e insights de la conversación
   */
  async generateConversationSummary(conversationHistory, language = 'es') {
    try {
      // Preparar el historial de conversación para OpenAI
      const messages = this._prepareConversationHistory(conversationHistory);
      
      const prompt = `
        Analiza la siguiente conversación entre un usuario y un coach de PNL.
        Genera un resumen conciso de los temas principales discutidos y proporciona insights sobre:
        1. Patrones emocionales observados
        2. Creencias limitantes identificadas
        3. Técnicas de PNL que podrían ser útiles para futuras sesiones
        4. Recomendaciones para el desarrollo personal del usuario
        
        Responde en formato JSON con los campos: "summary", "emotionalPatterns", "limitingBeliefs", "recommendedTechniques", "personalRecommendations".
      `;

      // Añadir el prompt al final
      messages.push({
        role: "user",
        content: prompt
      });

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: messages,
        max_tokens: 800,
        temperature: 0.5,
        response_format: { type: "json_object" }
      });

      // Parsear la respuesta JSON
      return JSON.parse(completion.choices[0].message.content);
    } catch (error) {
      console.error('Error generando resumen de conversación con OpenAI:', error);
      // Proporcionar un valor por defecto en caso de error
      return {
        summary: "No se pudo generar un resumen de la conversación.",
        emotionalPatterns: [],
        limitingBeliefs: [],
        recommendedTechniques: [],
        personalRecommendations: []
      };
    }
  }

  /**
   * Prepara el historial de conversación para enviar a OpenAI
   * @param {Array} conversationHistory - Historial de la conversación
   * @returns {Array} - Mensajes formateados para OpenAI
   * @private
   */
  _prepareConversationHistory(conversationHistory) {
    // Limitar el historial a las últimas 10 interacciones para evitar tokens excesivos
    const recentHistory = conversationHistory.slice(-20);
    
    return recentHistory.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'assistant',
      content: msg.content
    }));
  }

  /**
   * Crea un prompt de sistema específico para PNL basado en el estado emocional
   * @param {Object} emotionalState - Estado emocional detectado
   * @param {string} language - Idioma de la respuesta
   * @returns {string} - Prompt de sistema para OpenAI
   * @private
   */
  _createPNLSystemPrompt(emotionalState, language) {
    const languageInstructions = {
      'es': 'Responde en español utilizando un tono cálido y empático.',
      'en': 'Respond in English using a warm and empathetic tone.',
      'fr': 'Réponds en français en utilisant un ton chaleureux et empathique.'
    };

    // Adaptar el enfoque según el estado emocional
    let emotionalApproach = '';
    switch (emotionalState.state) {
      case 'happy':
        emotionalApproach = 'Aprovecha este estado positivo para reforzar creencias potenciadoras y establecer anclajes positivos.';
        break;
      case 'sad':
        emotionalApproach = 'Utiliza técnicas de reframing para ayudar a ver diferentes perspectivas y timeline therapy para procesar emociones.';
        break;
      case 'angry':
        emotionalApproach = 'Emplea técnicas de calibración y rapport para calmar, seguido de reframing para canalizar la energía constructivamente.';
        break;
      case 'anxious':
        emotionalApproach = 'Incorpora técnicas de anclaje y respiración para reducir la ansiedad, seguido de visualización para crear sensación de control.';
        break;
      case 'confident':
        emotionalApproach = 'Refuerza este estado con técnicas de anclaje y utilízalo como recurso para establecer metas ambiciosas.';
        break;
      case 'confused':
        emotionalApproach = 'Utiliza metamodelo para aclarar información y chunking para descomponer conceptos complejos en partes manejables.';
        break;
      case 'frustrated':
        emotionalApproach = 'Aplica técnicas de reframing y submodalidades para cambiar la percepción de los obstáculos.';
        break;
      default:
        emotionalApproach = 'Utiliza preguntas poderosas para explorar el estado actual y técnicas de rapport para establecer conexión.';
    }

    return `
      Eres un coach experto en Programación Neuro-Lingüística (PNL) con años de experiencia.
      Tu objetivo es ayudar al usuario a superar bloqueos emocionales, desarrollar su potencial y alcanzar sus metas.
      
      El usuario está experimentando un estado emocional: ${emotionalState.state} con intensidad: ${emotionalState.intensity}.
      ${emotionalApproach}
      
      Utiliza las siguientes técnicas de PNL en tus respuestas:
      - Reframing (reformulación): Ayuda a ver situaciones desde diferentes perspectivas
      - Anchoring (anclaje): Asocia estados emocionales positivos con estímulos específicos
      - Rapport: Establece conexión y confianza mediante lenguaje y empatía
      - Metamodelo: Clarifica información mediante preguntas específicas
      - Timeline Therapy: Trabaja con la línea temporal para resolver conflictos
      - Visualización: Guía al usuario para crear imágenes mentales poderosas
      - Submodalidades: Modifica aspectos específicos de las representaciones internas
      
      Tus respuestas deben ser:
      1. Empáticas y comprensivas
      2. Orientadas a soluciones y recursos
      3. Enfocadas en el desarrollo personal
      4. Concisas pero impactantes (máximo 3-4 párrafos)
      
      ${languageInstructions[language] || languageInstructions['es']}
    `;
  }

  /**
   * Extrae las técnicas de PNL utilizadas en una respuesta
   * @param {string} response - Respuesta generada
   * @returns {Array} - Técnicas de PNL identificadas
   * @private
   */
  _extractPNLTechniques(response) {
    // En una implementación más avanzada, esto analizaría el texto para identificar técnicas
    // Por ahora, hacemos una detección simple basada en palabras clave
    
    const techniques = [];
    const techniquesKeywords = {
      'reframing': ['perspectiva', 'punto de vista', 'reformular', 'reencuadrar', 'reframe', 'otra forma de ver'],
      'anchoring': ['ancla', 'anclaje', 'anchor', 'asociar', 'recordar', 'sensación'],
      'rapport': ['entiendo', 'comprendo', 'conectar', 'conexión', 'confianza'],
      'timeline': ['pasado', 'futuro', 'línea del tiempo', 'timeline', 'cuando', 'antes', 'después'],
      'visualization': ['imagina', 'visualiza', 'imagen mental', 'ver en tu mente', 'picture'],
      'submodalities': ['color', 'brillo', 'tamaño', 'intensidad', 'volumen', 'tono'],
      'metamodel': ['específicamente', 'exactamente', 'qué quieres decir', 'cómo sabes', 'en qué sentido']
    };
    
    // Verificar cada técnica
    for (const [technique, keywords] of Object.entries(techniquesKeywords)) {
      for (const keyword of keywords) {
        if (response.toLowerCase().includes(keyword.toLowerCase())) {
          techniques.push(technique);
          break; // Si encontramos una palabra clave, no necesitamos buscar más para esta técnica
        }
      }
    }
    
    // Si no se detectó ninguna técnica, añadir una por defecto
    if (techniques.length === 0) {
      techniques.push('rapport');
    }
    
    return [...new Set(techniques)]; // Eliminar duplicados
  }
}

module.exports = new OpenAIPNLService();
