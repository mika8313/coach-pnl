/**
 * Servicio para gestionar la seguridad de la aplicación
 */
class SecurityService {
  constructor() {
    this.crypto = require('crypto');
    this.jwt = require('jsonwebtoken');
    this.bcrypt = require('bcryptjs');
  }

  /**
   * Genera un hash seguro para una contraseña
   * @param {string} password - Contraseña en texto plano
   * @returns {Promise<string>} - Hash de la contraseña
   */
  async hashPassword(password) {
    try {
      const salt = await this.bcrypt.genSalt(12); // Usar 12 rondas para mayor seguridad
      return await this.bcrypt.hash(password, salt);
    } catch (error) {
      console.error('Error generando hash de contraseña:', error);
      throw error;
    }
  }

  /**
   * Verifica si una contraseña coincide con su hash
   * @param {string} password - Contraseña en texto plano
   * @param {string} hash - Hash almacenado
   * @returns {Promise<boolean>} - true si coincide, false en caso contrario
   */
  async verifyPassword(password, hash) {
    try {
      return await this.bcrypt.compare(password, hash);
    } catch (error) {
      console.error('Error verificando contraseña:', error);
      throw error;
    }
  }

  /**
   * Genera un token JWT
   * @param {Object} payload - Datos a incluir en el token
   * @param {string} expiresIn - Tiempo de expiración (por defecto: 24h)
   * @returns {string} - Token JWT
   */
  generateToken(payload, expiresIn = '24h') {
    try {
      return this.jwt.sign(
        payload,
        process.env.JWT_SECRET,
        { expiresIn }
      );
    } catch (error) {
      console.error('Error generando token JWT:', error);
      throw error;
    }
  }

  /**
   * Verifica y decodifica un token JWT
   * @param {string} token - Token JWT
   * @returns {Object} - Payload decodificado
   */
  verifyToken(token) {
    try {
      return this.jwt.verify(token, process.env.JWT_SECRET);
    } catch (error) {
      console.error('Error verificando token JWT:', error);
      throw error;
    }
  }

  /**
   * Genera un token de restablecimiento de contraseña
   * @param {string} userId - ID del usuario
   * @returns {string} - Token de restablecimiento
   */
  generatePasswordResetToken(userId) {
    try {
      // Generar token con expiración corta (1 hora)
      return this.generateToken({ user: { id: userId } }, '1h');
    } catch (error) {
      console.error('Error generando token de restablecimiento:', error);
      throw error;
    }
  }

  /**
   * Genera un ID seguro
   * @param {number} length - Longitud del ID (por defecto: 16)
   * @returns {string} - ID seguro
   */
  generateSecureId(length = 16) {
    try {
      return this.crypto.randomBytes(length).toString('hex');
    } catch (error) {
      console.error('Error generando ID seguro:', error);
      throw error;
    }
  }

  /**
   * Sanitiza datos de entrada para prevenir inyecciones
   * @param {Object|string} input - Datos a sanitizar
   * @returns {Object|string} - Datos sanitizados
   */
  sanitizeInput(input) {
    if (typeof input === 'string') {
      // Sanitizar string
      return input
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\//g, '&#x2F;');
    } else if (typeof input === 'object' && input !== null) {
      // Sanitizar objeto recursivamente
      const sanitized = {};
      for (const key in input) {
        if (Object.prototype.hasOwnProperty.call(input, key)) {
          sanitized[key] = this.sanitizeInput(input[key]);
        }
      }
      return sanitized;
    }
    
    // Devolver otros tipos sin cambios
    return input;
  }

  /**
   * Valida la fortaleza de una contraseña
   * @param {string} password - Contraseña a validar
   * @returns {Object} - Resultado de la validación
   */
  validatePasswordStrength(password) {
    // Criterios de validación
    const minLength = 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    // Calcular puntuación (0-100)
    let score = 0;
    
    // Longitud (hasta 40 puntos)
    score += Math.min(password.length * 5, 40);
    
    // Complejidad (60 puntos)
    if (hasUppercase) score += 15;
    if (hasLowercase) score += 15;
    if (hasNumbers) score += 15;
    if (hasSpecialChars) score += 15;
    
    // Determinar nivel de fortaleza
    let strength = 'weak';
    if (score >= 80) {
      strength = 'strong';
    } else if (score >= 60) {
      strength = 'medium';
    }
    
    // Verificar requisitos mínimos
    const isValid = password.length >= minLength && 
                    hasUppercase && 
                    hasLowercase && 
                    hasNumbers;
    
    return {
      isValid,
      score,
      strength,
      feedback: {
        minLength: password.length >= minLength,
        hasUppercase,
        hasLowercase,
        hasNumbers,
        hasSpecialChars
      }
    };
  }

  /**
   * Genera recomendaciones de seguridad para el usuario
   * @returns {Array} - Lista de recomendaciones
   */
  generateSecurityRecommendations() {
    return [
      {
        title: 'Utiliza contraseñas fuertes',
        description: 'Crea contraseñas de al menos 12 caracteres con letras mayúsculas, minúsculas, números y símbolos.'
      },
      {
        title: 'Activa la autenticación de dos factores',
        description: 'Añade una capa adicional de seguridad a tu cuenta utilizando la autenticación de dos factores.'
      },
      {
        title: 'Actualiza regularmente la aplicación',
        description: 'Mantén la aplicación actualizada para beneficiarte de las últimas mejoras de seguridad.'
      },
      {
        title: 'No compartas tus credenciales',
        description: 'Nunca compartas tus credenciales de acceso con otras personas, ni siquiera con el soporte técnico.'
      },
      {
        title: 'Revisa los permisos de la aplicación',
        description: 'Verifica regularmente los permisos que has concedido a la aplicación en tu dispositivo.'
      }
    ];
  }

  /**
   * Genera un informe de seguridad para la aplicación
   * @returns {Object} - Informe de seguridad
   */
  generateSecurityReport() {
    return {
      encryptionMethods: [
        {
          name: 'Contraseñas',
          method: 'Bcrypt (12 rondas)',
          strength: 'Alta'
        },
        {
          name: 'Tokens de autenticación',
          method: 'JWT con firma HMAC SHA256',
          strength: 'Alta'
        },
        {
          name: 'Datos sensibles',
          method: 'AES-256-GCM',
          strength: 'Alta'
        }
      ],
      dataProtection: [
        {
          category: 'Datos de usuario',
          protection: 'Almacenados con hash y sal',
          access: 'Solo el propietario'
        },
        {
          category: 'Conversaciones',
          protection: 'Cifrado en tránsito y reposo',
          access: 'Solo el propietario'
        },
        {
          category: 'Entradas de diario',
          protection: 'Cifrado en tránsito y reposo',
          access: 'Solo el propietario'
        }
      ],
      apiSecurity: [
        {
          feature: 'Rate limiting',
          status: 'Implementado',
          details: '100 solicitudes por minuto por IP'
        },
        {
          feature: 'Validación de entrada',
          status: 'Implementado',
          details: 'Sanitización y validación de todos los datos de entrada'
        },
        {
          feature: 'CORS',
          status: 'Implementado',
          details: 'Restricción de origen cruzado configurada'
        }
      ],
      complianceStandards: [
        {
          standard: 'GDPR',
          status: 'Cumple',
          details: 'Implementación de consentimiento, derecho al olvido y portabilidad de datos'
        },
        {
          standard: 'CCPA',
          status: 'Cumple',
          details: 'Implementación de divulgación de información y opción de exclusión'
        },
        {
          standard: 'HIPAA',
          status: 'No aplicable',
          details: 'La aplicación no maneja información médica protegida'
        }
      ]
    };
  }
}

module.exports = new SecurityService();
