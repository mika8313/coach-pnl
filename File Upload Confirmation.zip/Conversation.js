const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const MessageSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: true
  },
  sender: {
    type: String,
    enum: ['user', 'ai'],
    required: true
  },
  emotionalState: {
    type: String,
    enum: ['neutral', 'happy', 'sad', 'angry', 'anxious', 'confident', 'confused', 'frustrated'],
    default: 'neutral'
  },
  emotionalIntensity: {
    type: Number,
    min: 0,
    max: 1,
    default: 0
  },
  audioUrl: String,
  timestamp: {
    type: Date,
    default: Date.now
  },
  language: {
    type: String,
    enum: ['es', 'en', 'fr'],
    default: 'es'
  },
  metadata: {
    voiceAnalysis: {
      pitch: Number,
      tempo: Number,
      volume: Number,
      voiceCharacteristics: [String]
    },
    nlpAnalysis: {
      sentimentScore: Number,
      keywords: [String],
      entities: [String],
      languagePatterns: [String]
    }
  }
});

// Agrupar mensajes en conversaciones
const ConversationSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    default: 'Nueva conversación'
  },
  messages: [MessageSchema],
  summary: String,
  tags: [String],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Actualizar la fecha de actualización antes de guardar
ConversationSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = {
  Message: mongoose.model('Message', MessageSchema),
  Conversation: mongoose.model('Conversation', ConversationSchema)
};
