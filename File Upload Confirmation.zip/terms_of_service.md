# Términos y Condiciones de Uso - PNL Coach

Fecha de última actualización: 10 de abril de 2025

## 1. Aceptación de los Términos

Al descargar, instalar o utilizar la aplicación PNL Coach ("la Aplicación"), usted acepta estar sujeto a estos Términos y Condiciones de Uso ("Términos"). Si no está de acuerdo con estos Términos, no debe acceder ni utilizar la Aplicación.

## 2. Descripción del Servicio

PNL Coach es una aplicación móvil de coaching con IA especializada en Programación Neuro-Lingüística (PNL) que ofrece:
- Chatbot inteligente basado en técnicas de PNL
- Ejercicios interactivos de coaching
- Sistema de seguimiento de progreso
- Integración de voz (síntesis y reconocimiento)
- Soporte multilingüe (francés, inglés, español)

## 3. Requisitos de Cuenta

### 3.1 Registro
Para utilizar todas las funcionalidades de la Aplicación, debe crear una cuenta proporcionando información precisa y completa. Usted es responsable de mantener la confidencialidad de su contraseña y de todas las actividades que ocurran bajo su cuenta.

### 3.2 Edad Mínima
Debe tener al menos 16 años para utilizar la Aplicación. Si tiene entre 16 y 18 años, debe tener el permiso de un padre o tutor legal para utilizar la Aplicación.

## 4. Licencia de Uso

Sujeto a estos Términos, le otorgamos una licencia limitada, no exclusiva, no transferible y revocable para descargar, instalar y utilizar la Aplicación para su uso personal y no comercial.

## 5. Restricciones de Uso

Usted acepta no:
- Utilizar la Aplicación para cualquier propósito ilegal o prohibido por estos Términos.
- Intentar acceder, alterar o interferir con cualquier aspecto de la Aplicación.
- Copiar, modificar, distribuir, vender o alquilar cualquier parte de la Aplicación.
- Realizar ingeniería inversa, descompilar o desensamblar la Aplicación.
- Utilizar la Aplicación de manera que pueda dañar, deshabilitar, sobrecargar o deteriorar nuestros servidores o redes.
- Utilizar la Aplicación como sustituto de tratamiento médico o psicológico profesional.

## 6. Contenido del Usuario

### 6.1 Propiedad
Usted conserva todos los derechos sobre cualquier contenido que cree, cargue o comparta a través de la Aplicación ("Contenido del Usuario").

### 6.2 Licencia
Al proporcionar Contenido del Usuario, usted otorga a PNL Coach una licencia mundial, no exclusiva, libre de regalías, sublicenciable y transferible para usar, reproducir, modificar, adaptar, publicar, traducir y distribuir dicho contenido en relación con la operación y provisión de la Aplicación.

### 6.3 Responsabilidad
Usted es el único responsable de su Contenido del Usuario y las consecuencias de compartirlo. No podemos garantizar la confidencialidad absoluta del Contenido del Usuario.

## 7. Propiedad Intelectual

La Aplicación y todo su contenido, características y funcionalidades son propiedad de PNL Coach o sus licenciantes y están protegidos por leyes de propiedad intelectual. No se le otorga ningún derecho o licencia con respecto a ninguna de las marcas comerciales anteriores.

## 8. Limitación de Responsabilidad

### 8.1 Descargo de Responsabilidad
La Aplicación se proporciona "tal cual" y "según disponibilidad" sin garantías de ningún tipo, ya sean expresas o implícitas.

### 8.2 No Asesoramiento Profesional
La Aplicación no proporciona asesoramiento médico, psicológico o profesional. El contenido de la Aplicación es solo para fines informativos y de autodesarrollo.

### 8.3 Limitación de Responsabilidad
En ningún caso PNL Coach será responsable por daños indirectos, incidentales, especiales, consecuentes o punitivos, incluyendo pérdida de beneficios, datos o uso.

## 9. Terminación

Podemos terminar o suspender su acceso a la Aplicación inmediatamente, sin previo aviso ni responsabilidad, por cualquier motivo, incluyendo, sin limitación, si incumple estos Términos.

## 10. Modificaciones

Nos reservamos el derecho, a nuestra sola discreción, de modificar o reemplazar estos Términos en cualquier momento. Le notificaremos cualquier cambio publicando los nuevos Términos en la Aplicación. Su uso continuado de la Aplicación después de dichos cambios constituye su aceptación de los nuevos Términos.

## 11. Ley Aplicable

Estos Términos se regirán e interpretarán de acuerdo con las leyes de Francia, sin tener en cuenta sus disposiciones sobre conflictos de leyes.

## 12. Contacto

Si tiene alguna pregunta sobre estos Términos, contáctenos en:

Email: terms@pnlcoach.com

PNL Coach
123 Avenue de la Programmation
75000 Paris, France
