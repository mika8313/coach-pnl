/**
 * Pruebas de integración para las rutas de ejercicios de PNL
 */
const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const User = require('../../src/models/User');
const Exercise = require('../../src/models/Exercise');
const SecurityService = require('../../src/services/SecurityService');

describe('Exercises Routes Integration Tests', () => {
  let token;
  let userId;
  let exerciseId;
  
  beforeAll(async () => {
    // Conectar a la base de datos de prueba
    await mongoose.connect(process.env.MONGODB_URI_TEST || 'mongodb://localhost:27017/pnl-coach-test', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    // Limpiar las colecciones antes de las pruebas
    await User.deleteMany({});
    await Exercise.deleteMany({});
    
    // Crear un usuario para las pruebas
    const hashedPassword = await SecurityService.hashPassword('Password123!');
    const user = await User.create({
      name: 'Exercise Test User',
      email: 'exercise@example.com',
      password: hashedPassword
    });
    
    userId = user._id;
    
    // Generar token para el usuario
    token = SecurityService.generateToken({ user: { id: userId } });
    
    // Crear un ejercicio de prueba
    const exercise = await Exercise.create({
      title: 'Ejercicio de Anclaje',
      description: 'Un ejercicio para crear anclajes emocionales positivos',
      type: 'anchoring',
      level: 'beginner',
      duration: 15,
      steps: [
        'Recuerda un momento en que te sentiste completamente confiado',
        'Intensifica esa sensación',
        'Crea un gesto como ancla'
      ],
      benefits: [
        'Aumenta la confianza',
        'Reduce la ansiedad',
        'Mejora el rendimiento'
      ],
      creator: userId
    });
    
    exerciseId = exercise._id;
  });

  afterAll(async () => {
    // Desconectar de la base de datos después de las pruebas
    await mongoose.connection.close();
  });

  describe('GET /api/exercises', () => {
    it('debe obtener todos los ejercicios', async () => {
      const response = await request(app)
        .get('/api/exercises')
        .set('x-auth-token', token)
        .expect(200);
      
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
      expect(response.body[0]).toHaveProperty('title', 'Ejercicio de Anclaje');
      expect(response.body[0]).toHaveProperty('type', 'anchoring');
    });

    it('debe filtrar ejercicios por tipo', async () => {
      // Crear otro ejercicio de tipo diferente
      await Exercise.create({
        title: 'Ejercicio de Reencuadre',
        description: 'Un ejercicio para reencuadrar situaciones negativas',
        type: 'reframing',
        level: 'intermediate',
        duration: 20,
        steps: ['Paso 1', 'Paso 2', 'Paso 3'],
        benefits: ['Beneficio 1', 'Beneficio 2'],
        creator: userId
      });
      
      const response = await request(app)
        .get('/api/exercises?type=anchoring')
        .set('x-auth-token', token)
        .expect(200);
      
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBe(1);
      expect(response.body[0]).toHaveProperty('type', 'anchoring');
    });

    it('debe filtrar ejercicios por nivel', async () => {
      const response = await request(app)
        .get('/api/exercises?level=beginner')
        .set('x-auth-token', token)
        .expect(200);
      
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
      expect(response.body[0]).toHaveProperty('level', 'beginner');
    });

    it('debe devolver error sin autenticación', async () => {
      const response = await request(app)
        .get('/api/exercises')
        .expect(401);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('No hay token');
    });
  });

  describe('GET /api/exercises/:id', () => {
    it('debe obtener un ejercicio por ID', async () => {
      const response = await request(app)
        .get(`/api/exercises/${exerciseId}`)
        .set('x-auth-token', token)
        .expect(200);
      
      expect(response.body).toHaveProperty('_id', exerciseId.toString());
      expect(response.body).toHaveProperty('title', 'Ejercicio de Anclaje');
      expect(response.body).toHaveProperty('steps');
      expect(Array.isArray(response.body.steps)).toBe(true);
      expect(response.body.steps.length).toBe(3);
    });

    it('debe devolver error si el ejercicio no existe', async () => {
      const fakeId = new mongoose.Types.ObjectId();
      
      const response = await request(app)
        .get(`/api/exercises/${fakeId}`)
        .set('x-auth-token', token)
        .expect(404);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('no encontrado');
    });
  });

  describe('POST /api/exercises', () => {
    it('debe crear un nuevo ejercicio', async () => {
      const exerciseData = {
        title: 'Nuevo Ejercicio',
        description: 'Descripción del nuevo ejercicio',
        type: 'visualization',
        level: 'advanced',
        duration: 25,
        steps: ['Paso 1', 'Paso 2', 'Paso 3', 'Paso 4'],
        benefits: ['Beneficio 1', 'Beneficio 2', 'Beneficio 3']
      };
      
      const response = await request(app)
        .post('/api/exercises')
        .set('x-auth-token', token)
        .send(exerciseData)
        .expect(201);
      
      expect(response.body).toHaveProperty('_id');
      expect(response.body).toHaveProperty('title', 'Nuevo Ejercicio');
      expect(response.body).toHaveProperty('creator', userId.toString());
      
      // Verificar que el ejercicio se guardó en la base de datos
      const savedExercise = await Exercise.findById(response.body._id);
      expect(savedExercise).not.toBeNull();
      expect(savedExercise.title).toBe('Nuevo Ejercicio');
    });

    it('debe validar los campos requeridos', async () => {
      const incompleteData = {
        title: 'Ejercicio Incompleto'
        // Faltan campos requeridos
      };
      
      const response = await request(app)
        .post('/api/exercises')
        .set('x-auth-token', token)
        .send(incompleteData)
        .expect(400);
      
      expect(response.body).toHaveProperty('errors');
      expect(response.body.errors.length).toBeGreaterThan(0);
    });
  });

  describe('PUT /api/exercises/:id', () => {
    it('debe actualizar un ejercicio existente', async () => {
      const updateData = {
        title: 'Ejercicio de Anclaje Actualizado',
        duration: 20
      };
      
      const response = await request(app)
        .put(`/api/exercises/${exerciseId}`)
        .set('x-auth-token', token)
        .send(updateData)
        .expect(200);
      
      expect(response.body).toHaveProperty('_id', exerciseId.toString());
      expect(response.body).toHaveProperty('title', 'Ejercicio de Anclaje Actualizado');
      expect(response.body).toHaveProperty('duration', 20);
      
      // Verificar que el ejercicio se actualizó en la base de datos
      const updatedExercise = await Exercise.findById(exerciseId);
      expect(updatedExercise.title).toBe('Ejercicio de Anclaje Actualizado');
      expect(updatedExercise.duration).toBe(20);
    });

    it('debe devolver error si el ejercicio no existe', async () => {
      const fakeId = new mongoose.Types.ObjectId();
      const updateData = {
        title: 'Ejercicio Inexistente'
      };
      
      const response = await request(app)
        .put(`/api/exercises/${fakeId}`)
        .set('x-auth-token', token)
        .send(updateData)
        .expect(404);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('no encontrado');
    });

    it('debe impedir que un usuario actualice ejercicios de otros usuarios', async () => {
      // Crear otro usuario
      const otherUser = await User.create({
        name: 'Other User',
        email: 'other@example.com',
        password: await SecurityService.hashPassword('Password123!')
      });
      
      // Crear ejercicio para el otro usuario
      const otherExercise = await Exercise.create({
        title: 'Ejercicio de Otro Usuario',
        description: 'Descripción',
        type: 'visualization',
        level: 'beginner',
        duration: 15,
        steps: ['Paso 1', 'Paso 2'],
        benefits: ['Beneficio 1'],
        creator: otherUser._id
      });
      
      const updateData = {
        title: 'Intento de Actualización'
      };
      
      const response = await request(app)
        .put(`/api/exercises/${otherExercise._id}`)
        .set('x-auth-token', token) // Token del primer usuario
        .send(updateData)
        .expect(403);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('No autorizado');
    });
  });

  describe('DELETE /api/exercises/:id', () => {
    it('debe eliminar un ejercicio existente', async () => {
      // Crear un ejercicio para eliminar
      const exerciseToDelete = await Exercise.create({
        title: 'Ejercicio para Eliminar',
        description: 'Este ejercicio será eliminado',
        type: 'reframing',
        level: 'beginner',
        duration: 10,
        steps: ['Paso 1', 'Paso 2'],
        benefits: ['Beneficio 1'],
        creator: userId
      });
      
      const response = await request(app)
        .delete(`/api/exercises/${exerciseToDelete._id}`)
        .set('x-auth-token', token)
        .expect(200);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('eliminado');
      
      // Verificar que el ejercicio se eliminó de la base de datos
      const deletedExercise = await Exercise.findById(exerciseToDelete._id);
      expect(deletedExercise).toBeNull();
    });

    it('debe devolver error si el ejercicio no existe', async () => {
      const fakeId = new mongoose.Types.ObjectId();
      
      const response = await request(app)
        .delete(`/api/exercises/${fakeId}`)
        .set('x-auth-token', token)
        .expect(404);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('no encontrado');
    });

    it('debe impedir que un usuario elimine ejercicios de otros usuarios', async () => {
      // Crear otro usuario
      const otherUser = await User.create({
        name: 'Delete Test User',
        email: 'delete@example.com',
        password: await SecurityService.hashPassword('Password123!')
      });
      
      // Crear ejercicio para el otro usuario
      const otherExercise = await Exercise.create({
        title: 'Ejercicio No Eliminable',
        description: 'Descripción',
        type: 'visualization',
        level: 'beginner',
        duration: 15,
        steps: ['Paso 1', 'Paso 2'],
        benefits: ['Beneficio 1'],
        creator: otherUser._id
      });
      
      const response = await request(app)
        .delete(`/api/exercises/${otherExercise._id}`)
        .set('x-auth-token', token) // Token del primer usuario
        .expect(403);
      
      expect(response.body).toHaveProperty('msg');
      expect(response.body.msg).toContain('No autorizado');
      
      // Verificar que el ejercicio no se eliminó
      const exercise = await Exercise.findById(otherExercise._id);
      expect(exercise).not.toBeNull();
    });
  });
});
