import React from 'react';
import { useLanguage } from '../../context/LanguageContext';

const LanguageSwitcher: React.FC = () => {
  const { language, changeLanguage } = useLanguage();

  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={() => changeLanguage('es')}
        className={`w-8 h-8 rounded-full flex items-center justify-center ${
          language === 'es' ? 'bg-zen-green text-white' : 'bg-zen-cream text-zen-dark'
        }`}
        title="Español"
      >
        ES
      </button>
      <button
        onClick={() => changeLanguage('en')}
        className={`w-8 h-8 rounded-full flex items-center justify-center ${
          language === 'en' ? 'bg-zen-green text-white' : 'bg-zen-cream text-zen-dark'
        }`}
        title="English"
      >
        EN
      </button>
      <button
        onClick={() => changeLanguage('fr')}
        className={`w-8 h-8 rounded-full flex items-center justify-center ${
          language === 'fr' ? 'bg-zen-green text-white' : 'bg-zen-cream text-zen-dark'
        }`}
        title="Français"
      >
        FR
      </button>
    </div>
  );
};

export default LanguageSwitcher;
