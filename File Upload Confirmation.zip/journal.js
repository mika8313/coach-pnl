const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const JournalEntry = require('../models/JournalEntry');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   GET api/journal
 * @desc    Obtener todas las entradas del diario del usuario
 * @access  Private
 */
router.get('/', auth, async (req, res) => {
  try {
    const { startDate, endDate, mood } = req.query;
    
    // Construir filtro
    const filter = { userId: req.user.id };
    
    // Filtrar por fecha
    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }
    
    // Filtrar por estado de ánimo
    if (mood) filter.mood = mood;
    
    const entries = await JournalEntry.find(filter).sort({ date: -1 });
    res.json(entries);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/journal/:id
 * @desc    Obtener una entrada específica del diario
 * @access  Private
 */
router.get('/:id', auth, async (req, res) => {
  try {
    const entry = await JournalEntry.findById(req.params.id);
    
    if (!entry) {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    
    // Verificar que la entrada pertenece al usuario
    if (entry.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'No autorizado' });
    }
    
    res.json(entry);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   POST api/journal
 * @desc    Crear una nueva entrada en el diario
 * @access  Private
 */
router.post('/', [
  auth,
  [
    check('mood', 'El estado de ánimo es obligatorio').isIn(['great', 'good', 'neutral', 'bad', 'terrible']),
    check('notes', 'Las notas son obligatorias').not().isEmpty()
  ]
], async (req, res) => {
  // Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { 
      mood, 
      moodIntensity, 
      notes, 
      achievements, 
      challenges, 
      insights, 
      tags,
      relatedExercises,
      language
    } = req.body;
    
    // Analizar emociones en el texto (simulado por ahora)
    const emotionalAnalysis = analyzeEmotions(notes);
    
    // Crear nueva entrada
    const newEntry = new JournalEntry({
      userId: req.user.id,
      mood,
      moodIntensity: moodIntensity || 5,
      notes,
      achievements: achievements || [],
      challenges: challenges || [],
      insights: insights || [],
      tags: tags || [],
      relatedExercises: relatedExercises || [],
      emotionalAnalysis,
      language: language || 'es'
    });
    
    const entry = await newEntry.save();
    res.json(entry);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   PUT api/journal/:id
 * @desc    Actualizar una entrada del diario
 * @access  Private
 */
router.put('/:id', [
  auth,
  [
    check('mood', 'El estado de ánimo es obligatorio').optional().isIn(['great', 'good', 'neutral', 'bad', 'terrible']),
    check('notes', 'Las notas son obligatorias').optional().not().isEmpty()
  ]
], async (req, res) => {
  // Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const entry = await JournalEntry.findById(req.params.id);
    
    if (!entry) {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    
    // Verificar que la entrada pertenece al usuario
    if (entry.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'No autorizado' });
    }
    
    // Actualizar campos
    const { 
      mood, 
      moodIntensity, 
      notes, 
      achievements, 
      challenges, 
      insights, 
      tags,
      relatedExercises,
      language
    } = req.body;
    
    if (mood) entry.mood = mood;
    if (moodIntensity) entry.moodIntensity = moodIntensity;
    if (notes) {
      entry.notes = notes;
      // Reanalizar emociones si cambian las notas
      entry.emotionalAnalysis = analyzeEmotions(notes);
    }
    if (achievements) entry.achievements = achievements;
    if (challenges) entry.challenges = challenges;
    if (insights) entry.insights = insights;
    if (tags) entry.tags = tags;
    if (relatedExercises) entry.relatedExercises = relatedExercises;
    if (language) entry.language = language;
    
    const updatedEntry = await entry.save();
    res.json(updatedEntry);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   DELETE api/journal/:id
 * @desc    Eliminar una entrada del diario
 * @access  Private
 */
router.delete('/:id', auth, async (req, res) => {
  try {
    const entry = await JournalEntry.findById(req.params.id);
    
    if (!entry) {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    
    // Verificar que la entrada pertenece al usuario
    if (entry.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'No autorizado' });
    }
    
    await entry.remove();
    res.json({ msg: 'Entrada eliminada' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Entrada no encontrada' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/journal/stats
 * @desc    Obtener estadísticas del diario
 * @access  Private
 */
router.get('/stats', auth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    // Construir filtro
    const filter = { userId: req.user.id };
    
    // Filtrar por fecha
    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }
    
    // Obtener todas las entradas del período
    const entries = await JournalEntry.find(filter);
    
    // Calcular estadísticas
    const moodCounts = {
      great: 0,
      good: 0,
      neutral: 0,
      bad: 0,
      terrible: 0
    };
    
    let totalMoodIntensity = 0;
    const dominantEmotions = {};
    const tags = {};
    
    entries.forEach(entry => {
      // Contar estados de ánimo
      moodCounts[entry.mood]++;
      
      // Sumar intensidad
      totalMoodIntensity += entry.moodIntensity;
      
      // Contar emociones dominantes
      if (entry.emotionalAnalysis && entry.emotionalAnalysis.dominantEmotions) {
        entry.emotionalAnalysis.dominantEmotions.forEach(emotion => {
          dominantEmotions[emotion] = (dominantEmotions[emotion] || 0) + 1;
        });
      }
      
      // Contar tags
      if (entry.tags) {
        entry.tags.forEach(tag => {
          tags[tag] = (tags[tag] || 0) + 1;
        });
      }
    });
    
    // Calcular promedios
    const avgMoodIntensity = entries.length > 0 ? totalMoodIntensity / entries.length : 0;
    
    // Ordenar emociones y tags por frecuencia
    const sortedEmotions = Object.entries(dominantEmotions)
      .sort((a, b) => b[1] - a[1])
      .map(([emotion, count]) => ({ emotion, count }));
    
    const sortedTags = Object.entries(tags)
      .sort((a, b) => b[1] - a[1])
      .map(([tag, count]) => ({ tag, count }));
    
    res.json({
      totalEntries: entries.length,
      moodDistribution: moodCounts,
      avgMoodIntensity,
      dominantEmotions: sortedEmotions.slice(0, 5), // Top 5
      topTags: sortedTags.slice(0, 5) // Top 5
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

// Importar el servicio de OpenAI PNL
const OpenAIPNLService = require('../services/OpenAIPNLService');

// Función para analizar emociones en el texto
async function analyzeEmotions(text) {
  try {
    return await OpenAIPNLService.analyzeJournalEmotions(text);
  } catch (error) {
    console.error('Error al analizar emociones del diario:', error);
    // Fallback en caso de error
    return {
      dominantEmotions: ['neutral'],
      emotionalTrends: ['stable_emotional_state'],
      sentimentScore: 0
    };
  }
}

module.exports = router;
