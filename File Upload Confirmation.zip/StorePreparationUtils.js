/**
 * Utilidades para optimización y preparación para App Store
 */
class StorePreparationUtils {
  /**
   * Genera los metadatos necesarios para la publicación en App Store
   * @param {Object} config - Configuración de la aplicación
   * @returns {Object} - Metadatos formateados para App Store Connect
   */
  static generateAppStoreMetadata(config) {
    const { appInfo, appStore } = config;
    
    return {
      name: {
        value: appInfo.name,
        locale: "es-ES"
      },
      subtitle: {
        value: appStore.metadata.subtitle,
        locale: "es-ES"
      },
      description: {
        value: appInfo.description,
        locale: "es-ES"
      },
      keywords: {
        value: appInfo.keywords.join(", "),
        locale: "es-ES"
      },
      promotionalText: {
        value: appStore.metadata.promotionalText,
        locale: "es-ES"
      },
      supportUrl: appStore.metadata.supportUrl,
      marketingUrl: appStore.metadata.marketingUrl,
      privacyPolicyUrl: appStore.metadata.privacyPolicyUrl
    };
  }
  
  /**
   * Genera los metadatos necesarios para la publicación en Google Play
   * @param {Object} config - Configuración de la aplicación
   * @returns {Object} - Metadatos formateados para Google Play Console
   */
  static generateGooglePlayMetadata(config) {
    const { appInfo, googlePlay } = config;
    
    return {
      title: {
        value: appInfo.name,
        locale: "es-ES"
      },
      shortDescription: {
        value: googlePlay.metadata.shortDescription,
        locale: "es-ES"
      },
      fullDescription: {
        value: googlePlay.metadata.fullDescription,
        locale: "es-ES"
      },
      video: googlePlay.metadata.promoVideo,
      privacyPolicyUrl: googlePlay.metadata.privacyPolicyUrl,
      termsOfServiceUrl: googlePlay.metadata.termsOfServiceUrl
    };
  }
  
  /**
   * Verifica que todos los recursos gráficos necesarios estén presentes
   * @param {Object} config - Configuración de la aplicación
   * @returns {Object} - Resultado de la verificación
   */
  static verifyGraphicAssets(config) {
    const { graphicAssets } = config;
    const missingAssets = [];
    
    // Verificar iconos
    if (!graphicAssets.icons.appIcon) {
      missingAssets.push("App Icon");
    }
    
    if (!graphicAssets.icons.adaptiveIcon.foreground || !graphicAssets.icons.adaptiveIcon.background) {
      missingAssets.push("Adaptive Icon");
    }
    
    // Verificar capturas de pantalla
    const screenshotCategories = [
      "iphone65", "iphone55", "ipad", "androidPhone", "androidTablet"
    ];
    
    screenshotCategories.forEach(category => {
      if (!graphicAssets.screenshots[category] || graphicAssets.screenshots[category].length === 0) {
        missingAssets.push(`Screenshots for ${category}`);
      }
    });
    
    // Verificar imágenes promocionales
    if (!graphicAssets.promotional.featureGraphic) {
      missingAssets.push("Feature Graphic");
    }
    
    if (!graphicAssets.promotional.promoGraphic) {
      missingAssets.push("Promo Graphic");
    }
    
    return {
      isComplete: missingAssets.length === 0,
      missingAssets
    };
  }
  
  /**
   * Genera un informe de preparación para la publicación
   * @param {Object} config - Configuración de la aplicación
   * @returns {Object} - Informe de preparación
   */
  static generatePublishingReport(config) {
    const { publishingChecklist } = config;
    const completedItems = [];
    const pendingItems = [];
    
    // Combinar todas las categorías de la lista de verificación
    const allChecklistItems = [
      ...publishingChecklist.legal,
      ...publishingChecklist.technical,
      ...publishingChecklist.content,
      ...publishingChecklist.security
    ];
    
    // En una implementación real, esto verificaría el estado real de cada elemento
    // Por ahora, simulamos que algunos elementos están completados
    allChecklistItems.forEach(item => {
      if (Math.random() > 0.3) { // Simulación: 70% de probabilidad de estar completado
        completedItems.push(item);
      } else {
        pendingItems.push(item);
      }
    });
    
    return {
      totalItems: allChecklistItems.length,
      completedItems,
      pendingItems,
      completionPercentage: (completedItems.length / allChecklistItems.length) * 100,
      readyForSubmission: pendingItems.length === 0
    };
  }
  
  /**
   * Genera un script para automatizar la subida de metadatos a App Store Connect
   * @param {Object} config - Configuración de la aplicación
   * @returns {string} - Script para Fastlane
   */
  static generateFastlaneScript(config) {
    const { appInfo, appStore } = config;
    
    return `
# Fastlane script for App Store submission
default_platform(:ios)

platform :ios do
  desc "Submit app to App Store Connect"
  lane :submit_app do
    # Incrementar el número de build
    increment_build_number(
      build_number: Time.now.strftime("%Y%m%d%H%M")
    )
    
    # Actualizar información de la app
    deliver(
      app_identifier: "com.pnlcoach.app",
      app_version: "${appInfo.version}",
      submit_for_review: true,
      automatic_release: true,
      force: true,
      skip_binary_upload: false,
      skip_screenshots: false,
      skip_metadata: false,
      
      # Metadatos
      name: "${appInfo.name}",
      description: "${appInfo.description}",
      subtitle: "${appStore.metadata.subtitle}",
      keywords: "${appInfo.keywords.join(", ")}",
      promotional_text: "${appStore.metadata.promotionalText}",
      support_url: "${appStore.metadata.supportUrl}",
      marketing_url: "${appStore.metadata.marketingUrl}",
      privacy_url: "${appStore.metadata.privacyPolicyUrl}",
      
      # Información de revisión
      app_review_information: {
        first_name: "${appStore.contactInfo.firstName}",
        last_name: "${appStore.contactInfo.lastName}",
        phone_number: "${appStore.contactInfo.phone}",
        email_address: "${appStore.contactInfo.email}",
        demo_user: "${appStore.review.demoAccount.username}",
        demo_password: "${appStore.review.demoAccount.password}",
        notes: "${appStore.review.notes}"
      },
      
      # Categorización
      primary_category: "${appInfo.category}",
      secondary_category: "Medical",
      
      # Precios
      price_tier: ${appStore.pricing.price === 0 ? 0 : 1}
    )
  end
end
    `;
  }
}

export default StorePreparationUtils;
