const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const VoiceIntegrationService = require('../services/VoiceIntegrationService');
const User = require('../models/User');

// Middleware para verificar token
const auth = require('../middleware/auth');

// Configurar multer para almacenamiento temporal de archivos de audio
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads');
    // Crear directorio si no existe
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'voice-interaction-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // Límite de 10MB
  },
  fileFilter: function (req, file, cb) {
    // Aceptar solo archivos de audio comunes
    const filetypes = /wav|mp3|ogg|m4a|webm/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Solo se permiten archivos de audio (WAV, MP3, OGG, M4A, WEBM)'));
  }
});

/**
 * @route   POST api/voice/interact
 * @desc    Procesar interacción de voz completa (STT + PNL + TTS)
 * @access  Private
 */
router.post('/interact', [auth, upload.single('audio')], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ msg: req.translate('errors.audioRequired') });
    }

    // Obtener usuario
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: req.translate('errors.notFound') });
    }

    // Obtener ID de conversación si se proporciona
    const conversationId = req.body.conversationId;
    
    // Obtener historial de conversación (en una implementación real, esto vendría de la base de datos)
    // Por ahora, simulamos un historial vacío o mínimo
    const conversationHistory = [];

    // Leer archivo de audio
    const audioData = fs.readFileSync(req.file.path);

    // Procesar interacción de voz
    const result = await VoiceIntegrationService.processVoiceInteraction(
      audioData,
      user,
      conversationHistory
    );

    // Eliminar archivo temporal
    fs.unlinkSync(req.file.path);

    // En una implementación real, aquí guardaríamos la conversación en la base de datos
    
    res.json(result);
  } catch (err) {
    console.error('Error procesando interacción de voz:', err.message);
    
    // Eliminar archivo temporal si existe
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   PUT api/voice/preferences
 * @desc    Actualizar preferencias de voz del usuario
 * @access  Private
 */
router.put('/preferences', auth, async (req, res) => {
  try {
    const { voiceType, voiceSpeed } = req.body;
    
    // Obtener usuario
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: req.translate('errors.notFound') });
    }
    
    // Actualizar preferencias de voz
    const updatedPreferences = await VoiceIntegrationService.updateVoicePreferences(
      user,
      { voiceType, voiceSpeed }
    );
    
    // En una implementación real, aquí actualizaríamos el usuario en la base de datos
    // Por ahora, simulamos una respuesta exitosa
    
    res.json({
      success: true,
      preferences: updatedPreferences
    });
  } catch (err) {
    console.error('Error actualizando preferencias de voz:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   GET api/voice/available-voices
 * @desc    Obtener voces disponibles para el usuario
 * @access  Private
 */
router.get('/available-voices', auth, async (req, res) => {
  try {
    // Obtener usuario
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: req.translate('errors.notFound') });
    }
    
    // Obtener voces disponibles
    const voices = await VoiceIntegrationService.getAvailableVoices(user);
    
    res.json(voices);
  } catch (err) {
    console.error('Error obteniendo voces disponibles:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

module.exports = router;
