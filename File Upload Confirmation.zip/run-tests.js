/**
 * Script para ejecutar todas las pruebas
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuración
const config = {
  backend: {
    dir: path.resolve(__dirname, '../backend'),
    unitTestDir: path.resolve(__dirname, '../backend/test/unit'),
    integrationTestDir: path.resolve(__dirname, '../backend/test/integration'),
    testCommand: 'npm test'
  },
  mobile: {
    dir: path.resolve(__dirname, '../mobile'),
    e2eTestDir: path.resolve(__dirname, '../mobile/e2e'),
    testCommand: 'npm run test:e2e'
  },
  reportDir: path.resolve(__dirname, '../test-reports')
};

// Crear directorio de informes si no existe
if (!fs.existsSync(config.reportDir)) {
  fs.mkdirSync(config.reportDir, { recursive: true });
}

// Función para ejecutar pruebas
function runTests(type) {
  console.log(`\n========== Ejecutando pruebas ${type} ==========\n`);
  
  try {
    let command;
    let cwd;
    
    switch (type) {
      case 'backend-unit':
        cwd = config.backend.dir;
        command = 'npx jest --testMatch="**/test/unit/**/*.test.js" --json --outputFile="../test-reports/backend-unit.json"';
        break;
      case 'backend-integration':
        cwd = config.backend.dir;
        command = 'npx jest --testMatch="**/test/integration/**/*.test.js" --json --outputFile="../test-reports/backend-integration.json"';
        break;
      case 'mobile-e2e':
        cwd = config.mobile.dir;
        command = 'npx detox test --configuration ios.sim.debug --cleanup --json-report-path="../test-reports/mobile-e2e.json"';
        break;
      default:
        throw new Error(`Tipo de prueba desconocido: ${type}`);
    }
    
    console.log(`Ejecutando: ${command}`);
    const output = execSync(command, { cwd, stdio: 'inherit' });
    
    console.log(`\n✅ Pruebas ${type} completadas con éxito\n`);
    return true;
  } catch (error) {
    console.error(`\n❌ Error ejecutando pruebas ${type}:`);
    console.error(error.message);
    return false;
  }
}

// Función para generar informe de pruebas
function generateTestReport() {
  console.log('\n========== Generando informe de pruebas ==========\n');
  
  const report = {
    timestamp: new Date().toISOString(),
    summary: {
      total: 0,
      passed: 0,
      failed: 0,
      skipped: 0
    },
    tests: {}
  };
  
  // Leer informes JSON
  const reportFiles = [
    { name: 'backend-unit', path: path.join(config.reportDir, 'backend-unit.json') },
    { name: 'backend-integration', path: path.join(config.reportDir, 'backend-integration.json') },
    { name: 'mobile-e2e', path: path.join(config.reportDir, 'mobile-e2e.json') }
  ];
  
  reportFiles.forEach(file => {
    if (fs.existsSync(file.path)) {
      try {
        const data = JSON.parse(fs.readFileSync(file.path, 'utf8'));
        
        report.tests[file.name] = {
          numTotalTests: data.numTotalTests || 0,
          numPassedTests: data.numPassedTests || 0,
          numFailedTests: data.numFailedTests || 0,
          numPendingTests: data.numPendingTests || 0,
          testResults: data.testResults || []
        };
        
        report.summary.total += data.numTotalTests || 0;
        report.summary.passed += data.numPassedTests || 0;
        report.summary.failed += data.numFailedTests || 0;
        report.summary.skipped += data.numPendingTests || 0;
      } catch (error) {
        console.error(`Error procesando informe ${file.name}:`, error.message);
        report.tests[file.name] = { error: error.message };
      }
    } else {
      report.tests[file.name] = { error: 'Informe no encontrado' };
    }
  });
  
  // Guardar informe consolidado
  const reportPath = path.join(config.reportDir, 'test-report.json');
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  
  // Generar informe HTML
  const htmlReportPath = path.join(config.reportDir, 'test-report.html');
  const htmlContent = generateHtmlReport(report);
  fs.writeFileSync(htmlReportPath, htmlContent);
  
  console.log(`\n✅ Informe de pruebas generado en ${reportPath}`);
  console.log(`✅ Informe HTML generado en ${htmlReportPath}`);
  
  return report;
}

// Función para generar informe HTML
function generateHtmlReport(report) {
  const passRate = report.summary.total > 0 
    ? Math.round((report.summary.passed / report.summary.total) * 100) 
    : 0;
  
  return `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Informe de Pruebas - PNL Coach</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    h1, h2, h3 {
      color: #2c3e50;
    }
    .summary {
      background-color: #f8f9fa;
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 30px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    .summary-item {
      text-align: center;
      padding: 15px;
      border-radius: 8px;
    }
    .total {
      background-color: #e3f2fd;
    }
    .passed {
      background-color: #e8f5e9;
    }
    .failed {
      background-color: #ffebee;
    }
    .skipped {
      background-color: #fff8e1;
    }
    .progress-bar {
      height: 20px;
      background-color: #eceff1;
      border-radius: 10px;
      margin: 20px 0;
      overflow: hidden;
    }
    .progress-value {
      height: 100%;
      background-color: #4caf50;
      border-radius: 10px;
      width: ${passRate}%;
    }
    .test-section {
      margin-bottom: 40px;
      background-color: white;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .test-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    .test-stats {
      display: flex;
      gap: 15px;
    }
    .test-stat {
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 14px;
    }
    .test-details {
      margin-top: 20px;
    }
    .test-suite {
      margin-bottom: 15px;
      padding: 10px;
      background-color: #f8f9fa;
      border-radius: 4px;
    }
    .test-suite-header {
      font-weight: bold;
      margin-bottom: 10px;
    }
    .test-case {
      padding: 8px 15px;
      margin: 5px 0;
      border-radius: 4px;
    }
    .test-case.passed {
      background-color: #e8f5e9;
    }
    .test-case.failed {
      background-color: #ffebee;
    }
    .test-case.skipped {
      background-color: #fff8e1;
    }
    .timestamp {
      color: #7f8c8d;
      font-size: 14px;
      margin-top: 40px;
      text-align: center;
    }
  </style>
</head>
<body>
  <h1>Informe de Pruebas - PNL Coach</h1>
  
  <div class="summary">
    <h2>Resumen</h2>
    <div class="progress-bar">
      <div class="progress-value"></div>
    </div>
    <p style="text-align: center;">Tasa de éxito: ${passRate}%</p>
    
    <div class="summary-grid">
      <div class="summary-item total">
        <h3>Total</h3>
        <p>${report.summary.total}</p>
      </div>
      <div class="summary-item passed">
        <h3>Exitosas</h3>
        <p>${report.summary.passed}</p>
      </div>
      <div class="summary-item failed">
        <h3>Fallidas</h3>
        <p>${report.summary.failed}</p>
      </div>
      <div class="summary-item skipped">
        <h3>Omitidas</h3>
        <p>${report.summary.skipped}</p>
      </div>
    </div>
  </div>
  
  ${Object.entries(report.tests).map(([name, data]) => `
    <div class="test-section">
      <div class="test-header">
        <h2>${formatTestName(name)}</h2>
        <div class="test-stats">
          <span class="test-stat total">Total: ${data.numTotalTests || 0}</span>
          <span class="test-stat passed">Exitosas: ${data.numPassedTests || 0}</span>
          <span class="test-stat failed">Fallidas: ${data.numFailedTests || 0}</span>
          <span class="test-stat skipped">Omitidas: ${data.numPendingTests || 0}</span>
        </div>
      </div>
      
      ${data.error ? `<p>Error: ${data.error}</p>` : ''}
      
      <div class="test-details">
        ${(data.testResults || []).map(suite => `
          <div class="test-suite">
            <div class="test-suite-header">${suite.name || 'Suite sin nombre'}</div>
            ${(suite.assertionResults || []).map(test => `
              <div class="test-case ${test.status}">
                ${test.title || 'Prueba sin nombre'} - ${test.status}
              </div>
            `).join('')}
          </div>
        `).join('')}
      </div>
    </div>
  `).join('')}
  
  <p class="timestamp">Informe generado el: ${new Date(report.timestamp).toLocaleString()}</p>
</body>
</html>
  `;
}

// Función auxiliar para formatear nombres de prueba
function formatTestName(name) {
  switch (name) {
    case 'backend-unit':
      return 'Pruebas Unitarias (Backend)';
    case 'backend-integration':
      return 'Pruebas de Integración (Backend)';
    case 'mobile-e2e':
      return 'Pruebas End-to-End (Móvil)';
    default:
      return name;
  }
}

// Ejecutar pruebas
console.log('========== INICIANDO EJECUCIÓN DE PRUEBAS ==========');

const results = {
  'backend-unit': runTests('backend-unit'),
  'backend-integration': runTests('backend-integration'),
  'mobile-e2e': runTests('mobile-e2e')
};

// Generar informe
const report = generateTestReport();

// Mostrar resumen
console.log('\n========== RESUMEN DE PRUEBAS ==========');
console.log(`Total: ${report.summary.total}`);
console.log(`Exitosas: ${report.summary.passed}`);
console.log(`Fallidas: ${report.summary.failed}`);
console.log(`Omitidas: ${report.summary.skipped}`);
console.log(`Tasa de éxito: ${report.summary.total > 0 ? Math.round((report.summary.passed / report.summary.total) * 100) : 0}%`);

// Determinar estado de salida
const allTestsPassed = Object.values(results).every(result => result === true);
process.exit(allTestsPassed ? 0 : 1);
