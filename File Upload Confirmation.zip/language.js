/**
 * Middleware para gestionar el idioma en las solicitudes
 */
const I18nService = require('../services/I18nService');

module.exports = function(req, res, next) {
  // Obtener el idioma de la solicitud
  // Prioridad: 1. Parámetro de consulta, 2. Encabezado personalizado, 3. Accept-Language, 4. Idioma por defecto
  const queryLang = req.query.lang;
  const headerLang = req.header('X-Preferred-Language');
  const acceptLanguage = req.header('Accept-Language');
  
  let language;
  
  if (queryLang && I18nService.isSupported(queryLang)) {
    language = queryLang;
  } else if (headerLang && I18nService.isSupported(headerLang)) {
    language = headerLang;
  } else if (acceptLanguage) {
    language = I18nService.detectLanguage(acceptLanguage);
  } else {
    language = I18nService.getDefaultLanguage();
  }
  
  // Añadir el idioma y la función de traducción al objeto de solicitud
  req.language = language;
  req.translate = (key) => I18nService.translate(key, language);
  
  // Modificar el método json de la respuesta para incluir el idioma
  const originalJson = res.json;
  res.json = function(obj) {
    // Si es un objeto, añadir el idioma
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
      obj._language = language;
    }
    return originalJson.call(this, obj);
  };
  
  next();
};
