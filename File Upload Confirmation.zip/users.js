const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const User = require('../models/User');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   GET api/users/profile
 * @desc    Obtener perfil del usuario
 * @access  Private
 */
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   PUT api/users/profile
 * @desc    Actualizar perfil del usuario
 * @access  Private
 */
router.put('/profile', [
  auth,
  [
    check('name', 'El nombre es obligatorio').optional().not().isEmpty(),
    check('email', 'Por favor incluya un email válido').optional().isEmail(),
    check('language', 'Idioma no válido').optional().isIn(['es', 'en', 'fr'])
  ]
], async (req, res) => {
  // Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, email, language, preferences } = req.body;
    
    // Construir objeto de actualización
    const updateFields = {};
    if (name) updateFields.name = name;
    if (email) updateFields.email = email;
    if (language) updateFields.language = language;
    
    // Actualizar preferencias si se proporcionan
    if (preferences) {
      updateFields.preferences = {};
      if (preferences.theme) updateFields.preferences.theme = preferences.theme;
      if (preferences.notifications !== undefined) updateFields.preferences.notifications = preferences.notifications;
      if (preferences.voiceType) updateFields.preferences.voiceType = preferences.voiceType;
      if (preferences.voiceSpeed) updateFields.preferences.voiceSpeed = preferences.voiceSpeed;
    }
    
    // Actualizar usuario
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $set: updateFields },
      { new: true }
    ).select('-password');
    
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   PUT api/users/goals
 * @desc    Actualizar metas del usuario
 * @access  Private
 */
router.put('/goals', auth, async (req, res) => {
  try {
    const { goals } = req.body;
    
    if (!goals || !Array.isArray(goals)) {
      return res.status(400).json({ msg: 'Formato de metas inválido' });
    }
    
    // Actualizar metas
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $set: { goals } },
      { new: true }
    ).select('-password');
    
    res.json(user.goals);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   PUT api/users/goals/:id
 * @desc    Actualizar una meta específica
 * @access  Private
 */
router.put('/goals/:id', auth, async (req, res) => {
  try {
    const { title, description, targetDate, completed, progress } = req.body;
    const goalId = req.params.id;
    
    // Obtener usuario
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    // Encontrar índice de la meta
    const goalIndex = user.goals.findIndex(goal => goal._id.toString() === goalId);
    if (goalIndex === -1) {
      return res.status(404).json({ msg: 'Meta no encontrada' });
    }
    
    // Actualizar campos de la meta
    if (title) user.goals[goalIndex].title = title;
    if (description) user.goals[goalIndex].description = description;
    if (targetDate) user.goals[goalIndex].targetDate = targetDate;
    if (completed !== undefined) user.goals[goalIndex].completed = completed;
    if (progress !== undefined) user.goals[goalIndex].progress = progress;
    
    await user.save();
    res.json(user.goals[goalIndex]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   DELETE api/users/goals/:id
 * @desc    Eliminar una meta
 * @access  Private
 */
router.delete('/goals/:id', auth, async (req, res) => {
  try {
    const goalId = req.params.id;
    
    // Obtener usuario
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    // Filtrar metas para eliminar la especificada
    user.goals = user.goals.filter(goal => goal._id.toString() !== goalId);
    
    await user.save();
    res.json({ msg: 'Meta eliminada' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/users/progress
 * @desc    Obtener progreso del usuario
 * @access  Private
 */
router.get('/progress', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select('progress')
      .populate('progress.completedExercises', 'title type level duration');
    
    if (!user) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    res.json(user.progress);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

module.exports = router;
