/**
 * Pruebas E2E para la aplicación móvil
 */
const { device, element, by, waitFor } = require('detox');
const { reloadApp } = require('detox/runners/jest/adapter');

describe('Aplicación PNL Coach', () => {
  beforeAll(async () => {
    await device.launchApp();
  });

  beforeEach(async () => {
    await reloadApp();
  });

  describe('Flujo de autenticación', () => {
    it('debe mostrar la pantalla de bienvenida al iniciar', async () => {
      await expect(element(by.id('welcome-screen'))).toBeVisible();
      await expect(element(by.text('Bienvenido a PNL Coach'))).toBeVisible();
    });

    it('debe navegar a la pantalla de registro', async () => {
      await element(by.id('register-button')).tap();
      await expect(element(by.id('register-screen'))).toBeVisible();
      await expect(element(by.text('Crear una cuenta'))).toBeVisible();
    });

    it('debe registrar un nuevo usuario', async () => {
      // Navegar a la pantalla de registro
      await element(by.id('register-button')).tap();
      
      // Completar formulario
      await element(by.id('name-input')).typeText('Usuario Prueba');
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('confirm-password-input')).typeText('Password123!');
      
      // Enviar formulario
      await element(by.id('submit-button')).tap();
      
      // Verificar que se redirige a la pantalla principal
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
    });

    it('debe iniciar sesión con credenciales válidas', async () => {
      // Navegar a la pantalla de login
      await element(by.id('login-button')).tap();
      
      // Completar formulario
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      
      // Enviar formulario
      await element(by.id('submit-button')).tap();
      
      // Verificar que se redirige a la pantalla principal
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
    });

    it('debe mostrar error con credenciales inválidas', async () => {
      // Navegar a la pantalla de login
      await element(by.id('login-button')).tap();
      
      // Completar formulario con credenciales incorrectas
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('PasswordIncorrecto!');
      
      // Enviar formulario
      await element(by.id('submit-button')).tap();
      
      // Verificar que se muestra mensaje de error
      await expect(element(by.text('Credenciales inválidas'))).toBeVisible();
    });

    it('debe cerrar sesión correctamente', async () => {
      // Primero iniciar sesión
      await element(by.id('login-button')).tap();
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('submit-button')).tap();
      
      // Esperar a que cargue la pantalla principal
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
      
      // Abrir menú y cerrar sesión
      await element(by.id('menu-button')).tap();
      await element(by.id('logout-button')).tap();
      
      // Verificar que vuelve a la pantalla de bienvenida
      await expect(element(by.id('welcome-screen'))).toBeVisible();
    });
  });

  describe('Navegación principal', () => {
    beforeEach(async () => {
      // Iniciar sesión antes de cada prueba
      await element(by.id('login-button')).tap();
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('submit-button')).tap();
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
    });

    it('debe navegar a la pantalla de ejercicios', async () => {
      await element(by.id('exercises-tab')).tap();
      await expect(element(by.id('exercises-screen'))).toBeVisible();
      await expect(element(by.text('Ejercicios de PNL'))).toBeVisible();
    });

    it('debe navegar a la pantalla de chat', async () => {
      await element(by.id('chat-tab')).tap();
      await expect(element(by.id('chat-screen'))).toBeVisible();
      await expect(element(by.text('Coach PNL'))).toBeVisible();
    });

    it('debe navegar a la pantalla de perfil', async () => {
      await element(by.id('profile-tab')).tap();
      await expect(element(by.id('profile-screen'))).toBeVisible();
      await expect(element(by.text('Mi Perfil'))).toBeVisible();
    });

    it('debe navegar a la pantalla de progreso', async () => {
      await element(by.id('progress-tab')).tap();
      await expect(element(by.id('progress-screen'))).toBeVisible();
      await expect(element(by.text('Mi Progreso'))).toBeVisible();
    });
  });

  describe('Funcionalidad de ejercicios', () => {
    beforeEach(async () => {
      // Iniciar sesión y navegar a la pantalla de ejercicios
      await element(by.id('login-button')).tap();
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('submit-button')).tap();
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
      await element(by.id('exercises-tab')).tap();
    });

    it('debe mostrar lista de ejercicios', async () => {
      await expect(element(by.id('exercises-list'))).toBeVisible();
      // Verificar que hay al menos un ejercicio
      await expect(element(by.id('exercise-item-0'))).toBeVisible();
    });

    it('debe filtrar ejercicios por categoría', async () => {
      // Seleccionar filtro de categoría
      await element(by.id('filter-button')).tap();
      await element(by.id('category-filter')).tap();
      await element(by.text('Anclaje')).tap();
      await element(by.id('apply-filter-button')).tap();
      
      // Verificar que se muestran ejercicios filtrados
      await expect(element(by.id('exercises-list'))).toBeVisible();
      // Verificar que el primer ejercicio es de la categoría seleccionada
      await expect(element(by.text('Anclaje'))).toBeVisible();
    });

    it('debe abrir detalle de un ejercicio', async () => {
      // Seleccionar el primer ejercicio
      await element(by.id('exercise-item-0')).tap();
      
      // Verificar que se muestra la pantalla de detalle
      await expect(element(by.id('exercise-detail-screen'))).toBeVisible();
      await expect(element(by.id('exercise-title'))).toBeVisible();
      await expect(element(by.id('exercise-description'))).toBeVisible();
      await expect(element(by.id('exercise-steps'))).toBeVisible();
    });

    it('debe iniciar y completar un ejercicio', async () => {
      // Seleccionar el primer ejercicio
      await element(by.id('exercise-item-0')).tap();
      
      // Iniciar ejercicio
      await element(by.id('start-exercise-button')).tap();
      
      // Verificar que se muestra la pantalla de ejercicio en curso
      await expect(element(by.id('exercise-in-progress-screen'))).toBeVisible();
      
      // Avanzar por los pasos del ejercicio
      await element(by.id('next-step-button')).tap();
      await element(by.id('next-step-button')).tap();
      await element(by.id('next-step-button')).tap();
      
      // Completar ejercicio
      await element(by.id('complete-exercise-button')).tap();
      
      // Verificar que se muestra la pantalla de ejercicio completado
      await expect(element(by.id('exercise-completed-screen'))).toBeVisible();
      await expect(element(by.text('¡Ejercicio Completado!'))).toBeVisible();
    });
  });

  describe('Funcionalidad de chat con IA', () => {
    beforeEach(async () => {
      // Iniciar sesión y navegar a la pantalla de chat
      await element(by.id('login-button')).tap();
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('submit-button')).tap();
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
      await element(by.id('chat-tab')).tap();
    });

    it('debe mostrar la interfaz de chat', async () => {
      await expect(element(by.id('chat-screen'))).toBeVisible();
      await expect(element(by.id('message-input'))).toBeVisible();
      await expect(element(by.id('send-button'))).toBeVisible();
    });

    it('debe enviar un mensaje y recibir respuesta', async () => {
      // Enviar un mensaje
      await element(by.id('message-input')).typeText('Hola, necesito ayuda con mi ansiedad');
      await element(by.id('send-button')).tap();
      
      // Verificar que el mensaje se muestra en la conversación
      await expect(element(by.text('Hola, necesito ayuda con mi ansiedad'))).toBeVisible();
      
      // Esperar respuesta del coach (puede tardar)
      await waitFor(element(by.id('assistant-message-0'))).toBeVisible().withTimeout(10000);
    });

    it('debe activar y utilizar entrada de voz', async () => {
      // Activar entrada de voz
      await element(by.id('voice-input-button')).tap();
      
      // Verificar que se muestra la interfaz de grabación
      await expect(element(by.id('recording-interface'))).toBeVisible();
      
      // Simular grabación (en un entorno real esto requeriría permisos)
      await element(by.id('stop-recording-button')).tap();
      
      // Esperar respuesta del coach (puede tardar)
      await waitFor(element(by.id('assistant-message-0'))).toBeVisible().withTimeout(10000);
    });
  });

  describe('Cambio de idioma', () => {
    beforeEach(async () => {
      // Iniciar sesión
      await element(by.id('login-button')).tap();
      await element(by.id('email-input')).typeText('test@example.com');
      await element(by.id('password-input')).typeText('Password123!');
      await element(by.id('submit-button')).tap();
      await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(5000);
    });

    it('debe cambiar el idioma de la aplicación', async () => {
      // Navegar a la pantalla de perfil
      await element(by.id('profile-tab')).tap();
      
      // Abrir configuración de idioma
      await element(by.id('language-settings-button')).tap();
      
      // Seleccionar idioma francés
      await element(by.text('Français')).tap();
      
      // Verificar que la interfaz cambia al francés
      await expect(element(by.text('Mon Profil'))).toBeVisible();
    });
  });
});
