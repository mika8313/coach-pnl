/**
 * Middleware para limitar la tasa de solicitudes
 */
const rateLimit = require('express-rate-limit');

// Configuración básica de rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // Límite de 100 solicitudes por ventana por IP
  standardHeaders: true, // Devolver info de rate limit en los headers `RateLimit-*`
  legacyHeaders: false, // Deshabilitar los headers `X-RateLimit-*`
  message: {
    status: 429,
    message: 'Demasiadas solicitudes, por favor intenta de nuevo más tarde.'
  }
});

// Configuración más estricta para rutas sensibles
const authLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hora
  max: 10, // Límite de 10 solicitudes por ventana por IP
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: 429,
    message: 'Demasiados intentos de autenticación, por favor intenta de nuevo más tarde.'
  }
});

module.exports = {
  apiLimiter,
  authLimiter
};
