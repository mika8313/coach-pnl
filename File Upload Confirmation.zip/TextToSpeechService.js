const { ElevenLabs } = require('elevenlabs');
const dotenv = require('dotenv');

// Cargar variables de entorno
dotenv.config();

// Configuración de ElevenLabs
const elevenlabs = new ElevenLabs({
  apiKey: process.env.ELEVENLABS_API_KEY
});

/**
 * Servicio para síntesis de voz utilizando ElevenLabs
 */
class TextToSpeechService {
  // Mapeo de voces disponibles por idioma
  #voiceOptions = {
    es: {
      female1: 'Nicole', // ID real sería reemplazado en producción
      female2: 'Clara',
      male1: 'Antonio'
    },
    en: {
      female1: 'Rachel',
      female2: 'Domi',
      male1: 'Adam'
    },
    fr: {
      female1: 'Amélie',
      female2: 'Sophie',
      male1: 'Pierre'
    }
  };

  /**
   * Convierte texto a voz utilizando ElevenLabs
   * @param {string} text - Texto a convertir en voz
   * @param {string} language - Idioma del texto (es, en, fr)
   * @param {string} voiceType - Tipo de voz (female1, female2, male1)
   * @param {number} voiceSpeed - Velocidad de la voz (0.5-2.0)
   * @returns {Promise<Buffer>} - Audio generado en formato buffer
   */
  async textToSpeech(text, language = 'es', voiceType = 'female1', voiceSpeed = 1.0) {
    try {
      // Obtener ID de voz según idioma y tipo
      const voiceId = this.#getVoiceId(language, voiceType);
      
      // En una implementación real, esto usaría la API de ElevenLabs
      // Por ahora, simulamos la respuesta para desarrollo
      
      // Ejemplo de cómo sería con la API real:
      /*
      const audioStream = await elevenlabs.textToSpeech({
        text: text,
        voice_id: voiceId,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
          style: 0.0,
          use_speaker_boost: true,
          speaking_rate: voiceSpeed
        }
      });
      
      // Convertir stream a buffer
      const chunks = [];
      for await (const chunk of audioStream) {
        chunks.push(chunk);
      }
      return Buffer.concat(chunks);
      */
      
      // Simulación para desarrollo
      console.log(`Generando audio para: "${text.substring(0, 30)}..." en idioma ${language} con voz ${voiceType} a velocidad ${voiceSpeed}`);
      
      // Devolver un buffer simulado
      return Buffer.from('Audio simulado');
    } catch (error) {
      console.error('Error generando voz con ElevenLabs:', error);
      throw error;
    }
  }

  /**
   * Obtiene el ID de voz según idioma y tipo
   * @param {string} language - Idioma (es, en, fr)
   * @param {string} voiceType - Tipo de voz (female1, female2, male1)
   * @returns {string} - ID de la voz
   * @private
   */
  #getVoiceId(language, voiceType) {
    // Verificar si el idioma existe
    if (!this.#voiceOptions[language]) {
      console.warn(`Idioma ${language} no soportado, usando español por defecto`);
      language = 'es';
    }
    
    // Verificar si el tipo de voz existe
    if (!this.#voiceOptions[language][voiceType]) {
      console.warn(`Tipo de voz ${voiceType} no soportado, usando female1 por defecto`);
      voiceType = 'female1';
    }
    
    // En una implementación real, aquí devolveríamos el ID real de la voz
    // Por ahora, devolvemos el nombre de la voz como simulación
    return this.#voiceOptions[language][voiceType];
  }

  /**
   * Obtiene las voces disponibles para un idioma
   * @param {string} language - Idioma (es, en, fr)
   * @returns {Object} - Voces disponibles para el idioma
   */
  getAvailableVoices(language = 'es') {
    // Verificar si el idioma existe
    if (!this.#voiceOptions[language]) {
      console.warn(`Idioma ${language} no soportado, usando español por defecto`);
      language = 'es';
    }
    
    return this.#voiceOptions[language];
  }
}

module.exports = new TextToSpeechService();
