const express = require('express');
const router = express.Router();
const ProgressTrackingService = require('../services/ProgressTrackingService');
const User = require('../models/User');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   POST api/progress/exercise-completion
 * @desc    Registrar finalización de ejercicio
 * @access  Private
 */
router.post('/exercise-completion', auth, async (req, res) => {
  try {
    const { exerciseId, completionData } = req.body;
    
    if (!exerciseId) {
      return res.status(400).json({ msg: req.translate('errors.fieldsRequired') });
    }
    
    // Registrar finalización de ejercicio
    const result = await ProgressTrackingService.recordExerciseCompletion(
      req.user.id,
      exerciseId,
      completionData || {}
    );
    
    res.json(result);
  } catch (err) {
    console.error('Error registrando finalización de ejercicio:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   POST api/progress/journal-entry
 * @desc    Registrar nueva entrada de diario
 * @access  Private
 */
router.post('/journal-entry', auth, async (req, res) => {
  try {
    const { journalEntryId } = req.body;
    
    if (!journalEntryId) {
      return res.status(400).json({ msg: req.translate('errors.fieldsRequired') });
    }
    
    // Registrar entrada de diario
    const result = await ProgressTrackingService.recordJournalEntry(
      req.user.id,
      journalEntryId
    );
    
    res.json(result);
  } catch (err) {
    console.error('Error registrando entrada de diario:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   POST api/progress/coach-interaction
 * @desc    Registrar interacción con coach
 * @access  Private
 */
router.post('/coach-interaction', auth, async (req, res) => {
  try {
    const { conversationId, techniques } = req.body;
    
    if (!conversationId) {
      return res.status(400).json({ msg: req.translate('errors.fieldsRequired') });
    }
    
    // Registrar interacción con coach
    const result = await ProgressTrackingService.recordCoachInteraction(
      req.user.id,
      conversationId,
      techniques || []
    );
    
    res.json(result);
  } catch (err) {
    console.error('Error registrando interacción con coach:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   GET api/progress/report
 * @desc    Obtener informe de progreso
 * @access  Private
 */
router.get('/report', auth, async (req, res) => {
  try {
    const { timeframe = 'all' } = req.query;
    
    // Generar informe de progreso
    const report = await ProgressTrackingService.generateProgressReport(
      req.user.id,
      timeframe
    );
    
    res.json(report);
  } catch (err) {
    console.error('Error generando informe de progreso:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   GET api/progress/recommendations
 * @desc    Obtener recomendaciones personalizadas
 * @access  Private
 */
router.get('/recommendations', auth, async (req, res) => {
  try {
    // Generar recomendaciones personalizadas
    const recommendations = await ProgressTrackingService.generatePersonalizedRecommendations(
      req.user.id
    );
    
    res.json(recommendations);
  } catch (err) {
    console.error('Error generando recomendaciones personalizadas:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   GET api/progress/stats
 * @desc    Obtener estadísticas de progreso
 * @access  Private
 */
router.get('/stats', auth, async (req, res) => {
  try {
    // Obtener usuario con datos de progreso
    const user = await User.findById(req.user.id)
      .select('progress')
      .populate('progress.completedExercises', 'title type level');
    
    if (!user) {
      return res.status(404).json({ msg: req.translate('errors.notFound') });
    }
    
    // Calcular estadísticas adicionales
    const nextLevelProgress = ProgressTrackingService._calculateNextLevelProgress(user.progress);
    
    res.json({
      progress: user.progress,
      nextLevelProgress
    });
  } catch (err) {
    console.error('Error obteniendo estadísticas de progreso:', err.message);
    res.status(500).send(req.translate('errors.serverError'));
  }
});

module.exports = router;
