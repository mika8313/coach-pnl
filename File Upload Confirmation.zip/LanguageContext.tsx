import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Importaciones de recursos de idioma (se implementarán más adelante)
import translationES from '../i18n/es.json';
import translationEN from '../i18n/en.json';
import translationFR from '../i18n/fr.json';

// Configuración de i18next
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      es: {
        translation: translationES
      },
      en: {
        translation: translationEN
      },
      fr: {
        translation: translationFR
      }
    },
    fallbackLng: 'es',
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage']
    },
    interpolation: {
      escapeValue: false
    }
  });

interface LanguageContextType {
  language: string;
  changeLanguage: (lang: string) => void;
  detectLanguage: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<string>(i18n.language || 'es');

  useEffect(() => {
    // Actualizar el estado cuando cambie el idioma
    const handleLanguageChanged = (lng: string) => {
      setLanguage(lng);
    };

    i18n.on('languageChanged', handleLanguageChanged);

    return () => {
      i18n.off('languageChanged', handleLanguageChanged);
    };
  }, []);

  const changeLanguage = (lang: string) => {
    i18n.changeLanguage(lang);
  };

  const detectLanguage = () => {
    // Utilizar el detector de idioma del navegador
    const detectedLng = navigator.language.split('-')[0];
    if (['es', 'en', 'fr'].includes(detectedLng)) {
      changeLanguage(detectedLng);
    } else {
      // Si no es uno de los idiomas soportados, usar el idioma por defecto
      changeLanguage('es');
    }
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, detectLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage debe ser usado dentro de un LanguageProvider');
  }
  return context;
};
