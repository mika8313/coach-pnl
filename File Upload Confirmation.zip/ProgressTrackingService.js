/**
 * Servicio para gestionar el seguimiento de progreso de los usuarios
 */
class ProgressTrackingService {
  constructor() {
    this.User = require('../models/User');
    this.Exercise = require('../models/Exercise');
    this.JournalEntry = require('../models/JournalEntry');
    this.Conversation = require('../models/Conversation');
    this.OpenAIPNLService = require('./OpenAIPNLService');
  }

  /**
   * Registra la finalización de un ejercicio y actualiza el progreso del usuario
   * @param {string} userId - ID del usuario
   * @param {string} exerciseId - ID del ejercicio completado
   * @param {Object} completionData - Datos de la finalización (tiempo, puntuación, etc.)
   * @returns {Promise<Object>} - Progreso actualizado
   */
  async recordExerciseCompletion(userId, exerciseId, completionData) {
    try {
      // Obtener usuario y ejercicio
      const user = await this.User.findById(userId);
      const exercise = await this.Exercise.findById(exerciseId);
      
      if (!user || !exercise) {
        throw new Error('Usuario o ejercicio no encontrado');
      }
      
      // Verificar si el ejercicio ya está en la lista de completados
      const exerciseIndex = user.progress.completedExercises.findIndex(
        ex => ex.toString() === exerciseId
      );
      
      // Si no está en la lista, añadirlo
      if (exerciseIndex === -1) {
        user.progress.completedExercises.push(exerciseId);
      }
      
      // Actualizar estadísticas de progreso
      user.progress.totalExercisesCompleted += 1;
      user.progress.lastActivityDate = new Date();
      
      // Actualizar puntos de experiencia basados en el nivel del ejercicio
      const xpGained = this._calculateExperiencePoints(exercise.level, completionData);
      user.progress.experiencePoints += xpGained;
      
      // Actualizar nivel del usuario si es necesario
      this._updateUserLevel(user);
      
      // Actualizar estadísticas específicas según el tipo de ejercicio
      switch (exercise.type) {
        case 'anchoring':
          user.progress.stats.anchoringExercises += 1;
          break;
        case 'reframing':
          user.progress.stats.reframingExercises += 1;
          break;
        case 'visualization':
          user.progress.stats.visualizationExercises += 1;
          break;
        case 'beliefs':
          user.progress.stats.beliefsExercises += 1;
          break;
        case 'timeline':
          user.progress.stats.timelineExercises += 1;
          break;
        default:
          user.progress.stats.otherExercises += 1;
      }
      
      // Guardar usuario actualizado
      await user.save();
      
      // Devolver progreso actualizado
      return {
        progress: user.progress,
        xpGained,
        levelUp: completionData.levelUp || false,
        newAchievements: completionData.newAchievements || []
      };
    } catch (error) {
      console.error('Error registrando finalización de ejercicio:', error);
      throw error;
    }
  }

  /**
   * Registra una nueva entrada de diario y actualiza el progreso del usuario
   * @param {string} userId - ID del usuario
   * @param {string} journalEntryId - ID de la entrada de diario
   * @returns {Promise<Object>} - Progreso actualizado
   */
  async recordJournalEntry(userId, journalEntryId) {
    try {
      // Obtener usuario y entrada de diario
      const user = await this.User.findById(userId);
      const journalEntry = await this.JournalEntry.findById(journalEntryId);
      
      if (!user || !journalEntry) {
        throw new Error('Usuario o entrada de diario no encontrada');
      }
      
      // Actualizar estadísticas de progreso
      user.progress.totalJournalEntries += 1;
      user.progress.lastActivityDate = new Date();
      
      // Añadir puntos de experiencia por escribir en el diario
      const xpGained = 10; // Valor base por entrada de diario
      user.progress.experiencePoints += xpGained;
      
      // Actualizar nivel del usuario si es necesario
      this._updateUserLevel(user);
      
      // Actualizar estadísticas de consistencia
      const today = new Date();
      const lastEntryDate = user.progress.lastJournalDate;
      
      if (lastEntryDate) {
        // Verificar si es un día consecutivo
        const diffTime = Math.abs(today - lastEntryDate);
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          user.progress.stats.consecutiveJournalDays += 1;
          
          // Verificar si es un nuevo récord
          if (user.progress.stats.consecutiveJournalDays > user.progress.stats.maxConsecutiveJournalDays) {
            user.progress.stats.maxConsecutiveJournalDays = user.progress.stats.consecutiveJournalDays;
          }
        } else if (diffDays > 1) {
          // Reiniciar contador de días consecutivos
          user.progress.stats.consecutiveJournalDays = 1;
        }
      } else {
        // Primera entrada de diario
        user.progress.stats.consecutiveJournalDays = 1;
      }
      
      // Actualizar fecha de última entrada
      user.progress.lastJournalDate = today;
      
      // Guardar usuario actualizado
      await user.save();
      
      // Devolver progreso actualizado
      return {
        progress: user.progress,
        xpGained,
        consecutiveDays: user.progress.stats.consecutiveJournalDays
      };
    } catch (error) {
      console.error('Error registrando entrada de diario:', error);
      throw error;
    }
  }

  /**
   * Registra una nueva conversación con el coach IA y actualiza el progreso
   * @param {string} userId - ID del usuario
   * @param {string} conversationId - ID de la conversación
   * @param {Array} techniques - Técnicas de PNL utilizadas en la conversación
   * @returns {Promise<Object>} - Progreso actualizado
   */
  async recordCoachInteraction(userId, conversationId, techniques = []) {
    try {
      // Obtener usuario y conversación
      const user = await this.User.findById(userId);
      const conversation = await this.Conversation.findById(conversationId);
      
      if (!user || !conversation) {
        throw new Error('Usuario o conversación no encontrada');
      }
      
      // Actualizar estadísticas de progreso
      user.progress.totalCoachInteractions += 1;
      user.progress.lastActivityDate = new Date();
      
      // Añadir puntos de experiencia por interactuar con el coach
      const xpGained = 5 + (techniques.length * 2); // Base + bonus por técnicas
      user.progress.experiencePoints += xpGained;
      
      // Actualizar nivel del usuario si es necesario
      this._updateUserLevel(user);
      
      // Actualizar estadísticas de técnicas utilizadas
      techniques.forEach(technique => {
        switch (technique) {
          case 'reframing':
            user.progress.stats.reframingTechniques += 1;
            break;
          case 'anchoring':
            user.progress.stats.anchoringTechniques += 1;
            break;
          case 'rapport':
            user.progress.stats.rapportTechniques += 1;
            break;
          case 'timeline':
            user.progress.stats.timelineTechniques += 1;
            break;
          case 'visualization':
            user.progress.stats.visualizationTechniques += 1;
            break;
          case 'submodalities':
            user.progress.stats.submodalitiesTechniques += 1;
            break;
          case 'metamodel':
            user.progress.stats.metamodelTechniques += 1;
            break;
        }
      });
      
      // Guardar usuario actualizado
      await user.save();
      
      // Devolver progreso actualizado
      return {
        progress: user.progress,
        xpGained,
        techniquesUsed: techniques
      };
    } catch (error) {
      console.error('Error registrando interacción con coach:', error);
      throw error;
    }
  }

  /**
   * Genera un informe de progreso para el usuario
   * @param {string} userId - ID del usuario
   * @param {string} timeframe - Período de tiempo (week, month, all)
   * @returns {Promise<Object>} - Informe de progreso
   */
  async generateProgressReport(userId, timeframe = 'all') {
    try {
      // Obtener usuario con datos de progreso
      const user = await this.User.findById(userId)
        .populate('progress.completedExercises')
        .exec();
      
      if (!user) {
        throw new Error('Usuario no encontrado');
      }
      
      // Determinar fecha de inicio según timeframe
      let startDate = new Date(0); // Epoch time (1970)
      const now = new Date();
      
      if (timeframe === 'week') {
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 7);
      } else if (timeframe === 'month') {
        startDate = new Date(now);
        startDate.setMonth(now.getMonth() - 1);
      }
      
      // Obtener ejercicios completados en el período
      const completedExercises = await this.Exercise.find({
        _id: { $in: user.progress.completedExercises },
        completedAt: { $gte: startDate }
      });
      
      // Obtener entradas de diario en el período
      const journalEntries = await this.JournalEntry.find({
        user: userId,
        createdAt: { $gte: startDate }
      });
      
      // Obtener conversaciones en el período
      const conversations = await this.Conversation.find({
        user: userId,
        createdAt: { $gte: startDate }
      });
      
      // Calcular estadísticas
      const stats = {
        exercisesCompleted: completedExercises.length,
        journalEntriesCreated: journalEntries.length,
        coachInteractions: conversations.length,
        experienceGained: this._calculateExperienceInPeriod(user, startDate),
        mostUsedTechniques: this._getMostUsedTechniques(user.progress.stats),
        consistencyScore: this._calculateConsistencyScore(user, startDate),
        emotionalTrends: await this._analyzeEmotionalTrends(journalEntries, conversations),
        strengthAreas: this._identifyStrengthAreas(user.progress.stats),
        improvementAreas: this._identifyImprovementAreas(user.progress.stats),
        nextLevelProgress: this._calculateNextLevelProgress(user.progress)
      };
      
      return {
        user: {
          name: user.name,
          level: user.progress.level,
          experiencePoints: user.progress.experiencePoints
        },
        timeframe,
        stats,
        completedExercises: completedExercises.map(ex => ({
          id: ex._id,
          title: ex.title,
          type: ex.type,
          level: ex.level,
          completedAt: ex.completedAt
        })),
        journalEntries: journalEntries.map(entry => ({
          id: entry._id,
          title: entry.title,
          createdAt: entry.createdAt
        })),
        conversations: conversations.map(conv => ({
          id: conv._id,
          title: conv.title || 'Conversación con Coach',
          createdAt: conv.createdAt,
          messageCount: conv.messages.length
        }))
      };
    } catch (error) {
      console.error('Error generando informe de progreso:', error);
      throw error;
    }
  }

  /**
   * Genera recomendaciones personalizadas basadas en el progreso del usuario
   * @param {string} userId - ID del usuario
   * @returns {Promise<Object>} - Recomendaciones personalizadas
   */
  async generatePersonalizedRecommendations(userId) {
    try {
      // Obtener usuario con datos de progreso
      const user = await this.User.findById(userId)
        .populate('progress.completedExercises')
        .populate('goals')
        .exec();
      
      if (!user) {
        throw new Error('Usuario no encontrado');
      }
      
      // Identificar áreas de mejora
      const improvementAreas = this._identifyImprovementAreas(user.progress.stats);
      
      // Obtener ejercicios no completados que se alineen con áreas de mejora
      const recommendedExercises = await this.Exercise.find({
        _id: { $nin: user.progress.completedExercises },
        type: { $in: improvementAreas },
        level: { $lte: user.progress.level + 1 } // Ejercicios de nivel adecuado
      }).limit(3);
      
      // Generar recomendaciones para el diario
      const journalPrompts = await this._generateJournalPrompts(user);
      
      // Generar recomendaciones de técnicas de PNL
      const pnlTechniques = this._recommendPNLTechniques(user.progress.stats, user.goals);
      
      return {
        recommendedExercises: recommendedExercises.map(ex => ({
          id: ex._id,
          title: ex.title,
          type: ex.type,
          level: ex.level,
          duration: ex.duration,
          reason: `Este ejercicio te ayudará a mejorar en ${this._translateExerciseType(ex.type)}`
        })),
        journalPrompts,
        pnlTechniques,
        nextMilestone: this._calculateNextMilestone(user.progress),
        consistencyTip: this._generateConsistencyTip(user.progress)
      };
    } catch (error) {
      console.error('Error generando recomendaciones personalizadas:', error);
      throw error;
    }
  }

  /**
   * Calcula los puntos de experiencia ganados por completar un ejercicio
   * @param {string} exerciseLevel - Nivel del ejercicio (beginner, intermediate, advanced)
   * @param {Object} completionData - Datos de la finalización
   * @returns {number} - Puntos de experiencia ganados
   * @private
   */
  _calculateExperiencePoints(exerciseLevel, completionData) {
    // Puntos base según nivel
    let basePoints = 0;
    switch (exerciseLevel) {
      case 'beginner':
        basePoints = 10;
        break;
      case 'intermediate':
        basePoints = 20;
        break;
      case 'advanced':
        basePoints = 30;
        break;
      default:
        basePoints = 10;
    }
    
    // Bonus por tiempo de finalización (si está disponible)
    let timeBonus = 0;
    if (completionData.completionTime) {
      // Si completó rápido, dar bonus
      const expectedTime = completionData.expectedTime || 300; // 5 minutos por defecto
      if (completionData.completionTime < expectedTime) {
        timeBonus = Math.floor((1 - (completionData.completionTime / expectedTime)) * 5);
      }
    }
    
    // Bonus por puntuación (si está disponible)
    let scoreBonus = 0;
    if (completionData.score) {
      scoreBonus = Math.floor(completionData.score / 20); // 0-5 puntos bonus
    }
    
    return basePoints + timeBonus + scoreBonus;
  }

  /**
   * Actualiza el nivel del usuario basado en sus puntos de experiencia
   * @param {Object} user - Usuario a actualizar
   * @private
   */
  _updateUserLevel(user) {
    // Fórmula para calcular nivel: nivel = Math.floor(Math.sqrt(xp / 100))
    const newLevel = Math.floor(Math.sqrt(user.progress.experiencePoints / 100));
    
    // Verificar si subió de nivel
    if (newLevel > user.progress.level) {
      user.progress.level = newLevel;
      return true; // Indica que subió de nivel
    }
    
    return false;
  }

  /**
   * Calcula la experiencia ganada en un período de tiempo
   * @param {Object} user - Usuario
   * @param {Date} startDate - Fecha de inicio del período
   * @returns {number} - Experiencia ganada en el período
   * @private
   */
  _calculateExperienceInPeriod(user, startDate) {
    // En una implementación real, esto requeriría un registro de XP por fecha
    // Por ahora, simulamos un cálculo aproximado
    
    // Obtener días desde startDate
    const now = new Date();
    const diffTime = Math.abs(now - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Estimar XP diaria promedio (total / días desde registro)
    const userCreatedAt = new Date(user.createdAt);
    const totalUserDays = Math.ceil(Math.abs(now - userCreatedAt) / (1000 * 60 * 60 * 24));
    const avgDailyXP = user.progress.experiencePoints / Math.max(totalUserDays, 1);
    
    // Estimar XP en el período
    return Math
(Content truncated due to size limit. Use line ranges to read in chunks)