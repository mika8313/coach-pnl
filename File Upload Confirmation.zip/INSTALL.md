# Guía de Instalación y Uso - PNL Coach

Esta guía proporciona instrucciones detalladas para instalar, configurar y utilizar la aplicación PNL Coach.

## Instalación

### Requisitos Previos

- Node.js 16+
- MongoDB 4.4+
- Xcode 13+ (para iOS)
- Android Studio (para Android)
- Cuenta de OpenAI con API Key
- Cuenta de ElevenLabs con API Key

### Pasos de Instalación

#### Backend

1. Clonar el repositorio:
```bash
git clone https://github.com/pnlcoach/pnl-coach-app.git
cd pnl-coach-app/backend
```

2. Instalar dependencias:
```bash
npm install
```

3. Configurar variables de entorno:
```bash
cp .env.example .env
```

4. Editar el archivo `.env` con tus credenciales:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/pnl-coach
JWT_SECRET=tu_secreto_jwt
OPENAI_API_KEY=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
ELEVENLABS_API_KEY=sk_4215594470eabc34c023494f918e9147eb1d5beb87102ac9
```

5. Iniciar el servidor:
```bash
npm run dev
```

#### Aplicación Móvil

1. Navegar al directorio de la aplicación móvil:
```bash
cd ../mobile
```

2. Instalar dependencias:
```bash
npm install
```

3. Instalar pods (solo iOS):
```bash
cd ios && pod install && cd ..
```

4. Configurar variables de entorno:
```bash
cp .env.example .env
```

5. Editar el archivo `.env` con la URL del backend:
```
API_URL=http://localhost:5000/api
```

6. Iniciar la aplicación:
```bash
# Para iOS
npm run ios

# Para Android
npm run android
```

## Uso Rápido

### Registro e Inicio de Sesión

1. Al abrir la aplicación, selecciona "Crear una cuenta" para registrarte
2. Completa el formulario con tu nombre, correo electrónico y contraseña
3. Para inicios posteriores, usa "Iniciar sesión" con tu correo y contraseña

### Chat con Coach IA

1. Navega a la pestaña "Coach" en la barra inferior
2. Escribe tu mensaje o usa el botón de micrófono para hablar
3. El coach IA responderá utilizando técnicas de PNL

### Ejercicios de PNL

1. Navega a la pestaña "Ejercicios" en la barra inferior
2. Selecciona un ejercicio para ver sus detalles
3. Presiona "Comenzar" para iniciar el ejercicio
4. Sigue las instrucciones paso a paso

### Cambio de Idioma

1. Navega a la pestaña "Perfil" en la barra inferior
2. Selecciona "Configuración de idioma"
3. Elige entre español, francés o inglés

## Funcionalidades Principales

- **Chatbot Inteligente**: Interactúa con un coach de PNL basado en IA
- **Ejercicios Interactivos**: Accede a una biblioteca de ejercicios de PNL
- **Análisis Emocional**: Detección de estados emocionales a través de texto y voz
- **Integración de Voz**: Interactúa con la aplicación mediante voz
- **Seguimiento de Progreso**: Visualiza tu avance y recibe recomendaciones personalizadas
- **Soporte Multilingüe**: Disponible en español, francés e inglés

## Solución de Problemas

### La aplicación no se conecta al backend

- Verifica que el servidor backend esté en ejecución
- Comprueba que la URL en el archivo .env de la aplicación móvil sea correcta
- Asegúrate de que no haya restricciones de firewall bloqueando la conexión

### Problemas con las funcionalidades de IA

- Verifica que la clave API de OpenAI sea válida y tenga saldo disponible
- Comprueba la conexión a internet
- Revisa los logs del servidor para ver errores específicos

### Problemas con la síntesis de voz

- Verifica que la clave API de ElevenLabs sea válida
- Comprueba la conexión a internet
- Asegúrate de que el dispositivo tenga el volumen activado

## Contacto y Soporte

Para obtener ayuda adicional, contacta con nosotros:

- Email: support@pnlcoach.com
- Sitio web: https://pnlcoach.com/support
- Teléfono: +33 123 456 789
