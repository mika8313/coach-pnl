const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { Conversation, Message } = require('../models/Conversation');
const User = require('../models/User');
const { OpenAI } = require('openai');
const axios = require('axios');

// Configuración de OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   POST api/chat/message
 * @desc    Enviar un mensaje y obtener respuesta del coach IA
 * @access  Private
 */
router.post('/message', [
  auth,
  [
    check('content', 'El contenido del mensaje es obligatorio').not().isEmpty(),
    check('conversationId', 'ID de conversación inválido').optional()
  ]
], async (req, res) => {
  // Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { content, conversationId, audioData, language = 'es' } = req.body;
    const userId = req.user.id;

    // Obtener o crear conversación
    let conversation;
    if (conversationId) {
      conversation = await Conversation.findById(conversationId);
      if (!conversation) {
        return res.status(404).json({ msg: 'Conversación no encontrada' });
      }
      // Verificar que la conversación pertenece al usuario
      if (conversation.userId.toString() !== userId) {
        return res.status(401).json({ msg: 'No autorizado' });
      }
    } else {
      // Crear nueva conversación
      conversation = new Conversation({
        userId,
        title: content.substring(0, 30) + '...',
        messages: []
      });
    }

    // Analizar emociones en el texto (simulado por ahora)
    const emotionalState = analyzeEmotionalState(content);
    
    // Crear mensaje del usuario
    const userMessage = {
      content,
      sender: 'user',
      emotionalState: emotionalState.state,
      emotionalIntensity: emotionalState.intensity,
      language
    };

    // Si hay datos de audio, procesar análisis de voz (simulado por ahora)
    if (audioData) {
      userMessage.audioUrl = 'path/to/audio/file.mp3'; // En implementación real, guardar audio
      userMessage.metadata = {
        voiceAnalysis: simulateVoiceAnalysis()
      };
    }

    // Añadir mensaje a la conversación
    conversation.messages.push(userMessage);

    // Generar respuesta de IA basada en PNL
    const aiResponse = await generatePNLResponse(content, conversation.messages, emotionalState, language);

    // Crear mensaje de IA
    const aiMessage = {
      content: aiResponse.message,
      sender: 'ai',
      emotionalState: 'neutral',
      emotionalIntensity: 0.5,
      language
    };

    // Añadir mensaje de IA a la conversación
    conversation.messages.push(aiMessage);

    // Guardar conversación
    await conversation.save();

    // Responder con los mensajes y metadatos
    res.json({
      conversationId: conversation._id,
      userMessage: userMessage,
      aiMessage: aiMessage,
      analysis: {
        emotionalState: emotionalState,
        nlpTechniques: aiResponse.techniques
      }
    });
  } catch (err) {
    console.error('Error en chat/message:', err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/chat/conversations
 * @desc    Obtener todas las conversaciones del usuario
 * @access  Private
 */
router.get('/conversations', auth, async (req, res) => {
  try {
    const conversations = await Conversation.find({ userId: req.user.id })
      .sort({ updatedAt: -1 })
      .select('title updatedAt');
    
    res.json(conversations);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/chat/conversations/:id
 * @desc    Obtener una conversación específica
 * @access  Private
 */
router.get('/conversations/:id', auth, async (req, res) => {
  try {
    const conversation = await Conversation.findById(req.params.id);
    
    if (!conversation) {
      return res.status(404).json({ msg: 'Conversación no encontrada' });
    }

    // Verificar que la conversación pertenece al usuario
    if (conversation.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'No autorizado' });
    }

    res.json(conversation);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Conversación no encontrada' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   DELETE api/chat/conversations/:id
 * @desc    Eliminar una conversación
 * @access  Private
 */
router.delete('/conversations/:id', auth, async (req, res) => {
  try {
    const conversation = await Conversation.findById(req.params.id);
    
    if (!conversation) {
      return res.status(404).json({ msg: 'Conversación no encontrada' });
    }

    // Verificar que la conversación pertenece al usuario
    if (conversation.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'No autorizado' });
    }

    await conversation.remove();
    res.json({ msg: 'Conversación eliminada' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Conversación no encontrada' });
    }
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   POST api/chat/voice
 * @desc    Procesar audio y obtener respuesta del coach IA
 * @access  Private
 */
router.post('/voice', auth, async (req, res) => {
  try {
    const { audioData, conversationId, language = 'es' } = req.body;
    
    if (!audioData) {
      return res.status(400).json({ msg: 'Datos de audio requeridos' });
    }

    // Analizar el audio con el servicio de voz y emociones
    const voiceAnalysis = await VoiceEmotionService.analyzeVoiceEmotion(audioData, language);
    const transcription = voiceAnalysis.transcription;
    
    // Crear objeto de solicitud para el endpoint de mensaje
    const messageRequest = {
      content: transcription,
      conversationId,
      audioData: true, // Indicar que proviene de audio
      language
    };

    // Llamar al endpoint de mensaje para procesar la respuesta
    const response = await axios.post(
      `${req.protocol}://${req.get('host')}/api/chat/message`,
      messageRequest,
      { headers: { 'x-auth-token': req.header('x-auth-token') } }
    );

    // Añadir análisis de voz a la respuesta
    response.data.voiceAnalysis = voiceAnalysis;
    
    res.json(response.data);
  } catch (err) {
    console.error('Error en chat/voice:', err.message);
    res.status(500).send('Error en el servidor');
  }
});

// Importar el servicio de OpenAI PNL
const OpenAIPNLService = require('../services/OpenAIPNLService');

// Función para analizar el estado emocional del texto
async function analyzeEmotionalState(text) {
  try {
    return await OpenAIPNLService.analyzeEmotionalState(text);
  } catch (error) {
    console.error('Error al analizar estado emocional:', error);
    // Fallback en caso de error
    return {
      state: 'neutral',
      intensity: 0.5
    };
  }
}

// Importar servicio de análisis de voz y emociones
const VoiceEmotionService = require('../services/VoiceEmotionService');

// Función para analizar voz
async function analyzeVoice(audioData, language = 'es') {
  try {
    return await VoiceEmotionService.analyzeVoiceEmotion(audioData, language);
  } catch (error) {
    console.error('Error al analizar voz:', error);
    // Fallback en caso de error
    return {
      pitch: 0.5,
      tempo: 0.5,
      volume: 0.5,
      voiceCharacteristics: ['clear', 'articulate']
    };
  }
}

// Función para generar respuesta basada en PNL
async function generatePNLResponse(userMessage, conversationHistory, emotionalState, language) {
  try {
    // Utilizar el servicio de OpenAI PNL para generar una respuesta
    return await OpenAIPNLService.generatePNLResponse(userMessage, conversationHistory, emotionalState, language);
  } catch (error) {
    console.error('Error generando respuesta PNL:', error);
    return {
      message: "Lo siento, estoy teniendo dificultades para procesar tu mensaje. ¿Podrías intentarlo de nuevo?",
      techniques: []
    };
  }
}

module.exports = router;
