import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import LanguageSwitcher from '../language/LanguageSwitcher';
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = () => {
  const { t } = useTranslation();
  const { isAuthenticated, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container-zen py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-zen-dark">PNL Coach</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-neutral-darkest hover:text-zen-green transition-colors">
              {t('header.home')}
            </Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.dashboard')}
                </Link>
                <Link to="/chat" className="text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.chat')}
                </Link>
                <Link to="/exercises" className="text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.exercises')}
                </Link>
                <Link to="/profile" className="text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.profile')}
                </Link>
                <button 
                  onClick={logout}
                  className="btn btn-primary"
                >
                  {t('header.logout')}
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.login')}
                </Link>
                <Link to="/register" className="btn btn-primary">
                  {t('header.register')}
                </Link>
              </>
            )}
            <LanguageSwitcher />
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 rounded-md text-zen-dark hover:bg-zen-cream"
            onClick={toggleMenu}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3">
            <Link to="/" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
              {t('header.home')}
            </Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.dashboard')}
                </Link>
                <Link to="/chat" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.chat')}
                </Link>
                <Link to="/exercises" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.exercises')}
                </Link>
                <Link to="/profile" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.profile')}
                </Link>
                <button 
                  onClick={logout}
                  className="w-full text-left py-2 text-neutral-darkest hover:text-zen-green transition-colors"
                >
                  {t('header.logout')}
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.login')}
                </Link>
                <Link to="/register" className="block py-2 text-neutral-darkest hover:text-zen-green transition-colors">
                  {t('header.register')}
                </Link>
              </>
            )}
            <div className="py-2">
              <LanguageSwitcher />
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
