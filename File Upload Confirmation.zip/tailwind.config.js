module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#8ecae6',
          DEFAULT: '#219ebc',
          dark: '#023047',
        },
        secondary: {
          light: '#ffb703',
          DEFAULT: '#fb8500',
          dark: '#d62828',
        },
        neutral: {
          lightest: '#f8f9fa',
          light: '#e9ecef',
          medium: '#dee2e6',
          dark: '#adb5bd',
          darkest: '#495057',
        },
        zen: {
          green: '#84a98c',
          blue: '#a4c3b2',
          cream: '#f6fff8',
          gray: '#cad2c5',
          dark: '#52796f',
        },
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'],
        serif: ['Merriweather', 'serif'],
      },
      spacing: {
        '72': '18rem',
        '84': '21rem',
        '96': '24rem',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '2rem',
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'inner-soft': 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)',
      },
    },
  },
  plugins: [],
}
