const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  language: {
    type: String,
    enum: ['es', 'en', 'fr'],
    default: 'es'
  },
  preferences: {
    theme: {
      type: String,
      enum: ['light', 'dark'],
      default: 'light'
    },
    notifications: {
      type: Boolean,
      default: true
    },
    voiceType: {
      type: String,
      enum: ['female1', 'female2', 'male1'],
      default: 'female1'
    },
    voiceSpeed: {
      type: Number,
      default: 1.0,
      min: 0.5,
      max: 2.0
    }
  },
  progress: {
    completedExercises: [{
      type: Schema.Types.ObjectId,
      ref: 'Exercise'
    }],
    lastActivity: {
      type: Date,
      default: Date.now
    },
    streak: {
      type: Number,
      default: 0
    }
  },
  goals: [{
    title: String,
    description: String,
    targetDate: Date,
    completed: {
      type: Boolean,
      default: false
    },
    progress: {
      type: Number,
      default: 0,
      min: 0,
      max: 100
    }
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('User', UserSchema);
