/**
 * Configuración de seguridad para la aplicación móvil
 */
const securityConfig = {
  // Configuración de autenticación
  auth: {
    // Tiempo de expiración del token JWT (en segundos)
    tokenExpiration: 86400, // 24 horas
    
    // Tiempo de expiración del token de refresco (en segundos)
    refreshTokenExpiration: 2592000, // 30 días
    
    // Número máximo de intentos de inicio de sesión fallidos
    maxLoginAttempts: 5,
    
    // Tiempo de bloqueo después de alcanzar el máximo de intentos (en segundos)
    lockoutTime: 1800, // 30 minutos
    
    // Requerir autenticación de dos factores para acciones sensibles
    require2FAForSensitiveActions: true,
    
    // Lista de acciones que requieren 2FA
    sensitiveActions: [
      'change-password',
      'update-email',
      'delete-account',
      'export-data'
    ]
  },
  
  // Configuración de almacenamiento seguro
  storage: {
    // Cifrar datos sensibles en almacenamiento local
    encryptLocalStorage: true,
    
    // Algoritmo de cifrado para almacenamiento local
    encryptionAlgorithm: 'AES-256-GCM',
    
    // Tiempo de caducidad de la caché (en segundos)
    cacheExpiration: 3600, // 1 hora
    
    // Borrar datos sensibles al cerrar sesión
    clearOnLogout: true,
    
    // Datos a conservar después del cierre de sesión
    persistAfterLogout: [
      'language',
      'theme',
      'accessibility-settings'
    ]
  },
  
  // Configuración de red
  network: {
    // Usar HTTPS para todas las comunicaciones
    enforceHttps: true,
    
    // Implementar certificate pinning
    certificatePinning: true,
    
    // Certificados confiables (hashes SHA-256)
    trustedCertificates: [
      'sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      'sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB='
    ],
    
    // Tiempo de espera de las solicitudes (en milisegundos)
    requestTimeout: 30000, // 30 segundos
    
    // Número máximo de reintentos para solicitudes fallidas
    maxRetries: 3
  },
  
  // Configuración de privacidad
  privacy: {
    // Solicitar consentimiento para recopilación de datos
    requireConsent: true,
    
    // Categorías de consentimiento
    consentCategories: [
      'analytics',
      'personalization',
      'marketing'
    ],
    
    // Permitir a los usuarios exportar sus datos
    allowDataExport: true,
    
    // Permitir a los usuarios eliminar su cuenta y datos
    allowAccountDeletion: true,
    
    // Período de retención de datos (en días)
    dataRetentionPeriod: 365 // 1 año
  },
  
  // Configuración de seguridad de la aplicación
  appSecurity: {
    // Detectar dispositivos rooteados/con jailbreak
    detectRootedDevices: true,
    
    // Acción a tomar si se detecta un dispositivo rooteado
    rootedDeviceAction: 'warn', // 'block', 'warn', 'allow'
    
    // Bloquear capturas de pantalla en pantallas sensibles
    preventScreenshots: true,
    
    // Pantallas sensibles donde se bloquean capturas
    sensitiveScreens: [
      'login',
      'register',
      'profile',
      'journal',
      'payment'
    ],
    
    // Tiempo de inactividad antes de bloqueo (en segundos)
    inactivityTimeout: 300, // 5 minutos
    
    // Requerir autenticación después de inactividad
    requireAuthAfterInactivity: true
  }
};

export default securityConfig;
