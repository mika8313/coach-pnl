import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../context/ThemeContext';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

const WelcomeScreen = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const navigation = useNavigation();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    scrollView: {
      flex: 1,
    },
    heroSection: {
      padding: 20,
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: 300,
    },
    logo: {
      width: 120,
      height: 120,
      marginBottom: 20,
      borderRadius: 60,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold',
      color: theme.text,
      textAlign: 'center',
      marginBottom: 10,
    },
    subtitle: {
      fontSize: 16,
      color: theme.text,
      textAlign: 'center',
      marginBottom: 30,
      paddingHorizontal: 20,
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      width: '100%',
      marginBottom: 20,
    },
    button: {
      paddingVertical: 12,
      paddingHorizontal: 30,
      borderRadius: 25,
      marginHorizontal: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    primaryButton: {
      backgroundColor: theme.primary,
    },
    secondaryButton: {
      backgroundColor: theme.secondary,
    },
    buttonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
    },
    featuresSection: {
      padding: 20,
    },
    sectionTitle: {
      fontSize: 22,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 20,
      textAlign: 'center',
    },
    featureCard: {
      backgroundColor: theme.card,
      borderRadius: 10,
      padding: 20,
      marginBottom: 15,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 2,
    },
    featureTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 8,
    },
    featureDescription: {
      fontSize: 14,
      color: theme.text,
      opacity: 0.8,
    },
    featureIcon: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.primary + '20',
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 15,
    },
    howItWorksSection: {
      padding: 20,
      backgroundColor: theme.background + '80',
    },
    stepsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      flexWrap: 'wrap',
    },
    stepItem: {
      alignItems: 'center',
      width: '30%',
      marginBottom: 20,
    },
    stepNumber: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 10,
    },
    stepNumberText: {
      color: 'white',
      fontWeight: 'bold',
    },
    stepTitle: {
      fontSize: 14,
      fontWeight: 'bold',
      color: theme.text,
      textAlign: 'center',
      marginBottom: 5,
    },
    stepDescription: {
      fontSize: 12,
      color: theme.text,
      opacity: 0.8,
      textAlign: 'center',
    },
    ctaSection: {
      padding: 20,
      backgroundColor: theme.primary,
      margin: 20,
      borderRadius: 15,
      alignItems: 'center',
    },
    ctaTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: 'white',
      textAlign: 'center',
      marginBottom: 10,
    },
    ctaDescription: {
      fontSize: 14,
      color: 'white',
      textAlign: 'center',
      marginBottom: 20,
      opacity: 0.9,
    },
    ctaButton: {
      backgroundColor: 'white',
      paddingVertical: 12,
      paddingHorizontal: 30,
      borderRadius: 25,
    },
    ctaButtonText: {
      color: theme.primary,
      fontWeight: 'bold',
      fontSize: 16,
    },
  });

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.logo}>
            <Icon name="leaf-outline" size={60} color="white" />
          </View>
          <Text style={styles.title}>{t('auth.welcome')}</Text>
          <Text style={styles.subtitle}>{t('auth.welcomeSubtitle')}</Text>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[styles.button, styles.primaryButton]}
              onPress={() => navigation.navigate('Register')}
            >
              <Text style={styles.buttonText}>{t('auth.register')}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.secondaryButton]}
              onPress={() => navigation.navigate('Login')}
            >
              <Text style={styles.buttonText}>{t('auth.login')}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Features Section */}
        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>{t('home.features.title')}</Text>
          
          <View style={styles.featureCard}>
            <View style={styles.featureIcon}>
              <Icon name="chatbubbles-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.featureTitle}>{t('home.features.feature1.title')}</Text>
            <Text style={styles.featureDescription}>{t('home.features.feature1.description')}</Text>
          </View>
          
          <View style={styles.featureCard}>
            <View style={styles.featureIcon}>
              <Icon name="fitness-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.featureTitle}>{t('home.features.feature2.title')}</Text>
            <Text style={styles.featureDescription}>{t('home.features.feature2.description')}</Text>
          </View>
          
          <View style={styles.featureCard}>
            <View style={styles.featureIcon}>
              <Icon name="mic-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.featureTitle}>{t('home.features.feature3.title')}</Text>
            <Text style={styles.featureDescription}>{t('home.features.feature3.description')}</Text>
          </View>
        </View>

        {/* How It Works Section */}
        <View style={styles.howItWorksSection}>
          <Text style={styles.sectionTitle}>{t('home.howItWorks.title')}</Text>
          <View style={styles.stepsContainer}>
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>1</Text>
              </View>
              <Text style={styles.stepTitle}>{t('home.howItWorks.step1.title')}</Text>
              <Text style={styles.stepDescription}>{t('home.howItWorks.step1.description')}</Text>
            </View>
            
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>2</Text>
              </View>
              <Text style={styles.stepTitle}>{t('home.howItWorks.step2.title')}</Text>
              <Text style={styles.stepDescription}>{t('home.howItWorks.step2.description')}</Text>
            </View>
            
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>3</Text>
              </View>
              <Text style={styles.stepTitle}>{t('home.howItWorks.step3.title')}</Text>
              <Text style={styles.stepDescription}>{t('home.howItWorks.step3.description')}</Text>
            </View>
          </View>
        </View>

        {/* CTA Section */}
        <View style={styles.ctaSection}>
          <Text style={styles.ctaTitle}>{t('home.cta.title')}</Text>
          <Text style={styles.ctaDescription}>{t('home.cta.description')}</Text>
          <TouchableOpacity
            style={styles.ctaButton}
            onPress={() => navigation.navigate('Register')}
          >
            <Text style={styles.ctaButtonText}>{t('home.cta.button')}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default WelcomeScreen;
