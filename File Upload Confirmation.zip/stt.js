const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const SpeechToTextService = require('../services/SpeechToTextService');

// Middleware para verificar token
const auth = require('../middleware/auth');

// Configurar multer para almacenamiento temporal de archivos de audio
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads');
    // Crear directorio si no existe
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'audio-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // Límite de 10MB
  },
  fileFilter: function (req, file, cb) {
    // Aceptar solo archivos de audio comunes
    const filetypes = /wav|mp3|ogg|m4a|webm/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Solo se permiten archivos de audio (WAV, MP3, OGG, M4A, WEBM)'));
  }
});

/**
 * @route   POST api/stt/transcribe
 * @desc    Transcribir audio a texto
 * @access  Private
 */
router.post('/transcribe', [auth, upload.single('audio')], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ msg: req.translate('errors.audioRequired') });
    }

    // Obtener opciones de transcripción
    const language = req.body.language || req.language;
    const translateToEnglish = req.body.translateToEnglish === 'true';
    const prompt = req.body.prompt || '';

    // Leer archivo de audio
    const audioData = fs.readFileSync(req.file.path);

    // Transcribir audio
    const transcription = await SpeechToTextService.transcribeAudio(audioData, {
      language,
      translateToEnglish,
      prompt
    });

    // Eliminar archivo temporal
    fs.unlinkSync(req.file.path);

    res.json(transcription);
  } catch (err) {
    console.error('Error transcribiendo audio:', err.message);
    
    // Eliminar archivo temporal si existe
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).send(req.translate('errors.serverError'));
  }
});

/**
 * @route   POST api/stt/detect-language
 * @desc    Detectar idioma del audio
 * @access  Private
 */
router.post('/detect-language', [auth, upload.single('audio')], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ msg: req.translate('errors.audioRequired') });
    }

    // Leer archivo de audio
    const audioData = fs.readFileSync(req.file.path);

    // Detectar idioma
    const detectedLanguage = await SpeechToTextService.detectLanguage(audioData);

    // Eliminar archivo temporal
    fs.unlinkSync(req.file.path);

    res.json({ 
      language: detectedLanguage,
      languageName: detectedLanguage === 'es' ? 'Español' : 
                    detectedLanguage === 'en' ? 'English' : 
                    detectedLanguage === 'fr' ? 'Français' : 'Unknown'
    });
  } catch (err) {
    console.error('Error detectando idioma del audio:', err.message);
    
    // Eliminar archivo temporal si existe
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).send(req.translate('errors.serverError'));
  }
});

module.exports = router;
