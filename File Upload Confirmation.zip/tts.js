const express = require('express');
const router = express.Router();
const TextToSpeechService = require('../services/TextToSpeechService');

// Middleware para verificar token
const auth = require('../middleware/auth');

/**
 * @route   POST api/tts/generate
 * @desc    Generar audio a partir de texto
 * @access  Private
 */
router.post('/generate', auth, async (req, res) => {
  try {
    const { text, language = 'es', voiceType = 'female1', voiceSpeed = 1.0 } = req.body;
    
    if (!text) {
      return res.status(400).json({ msg: 'El texto es obligatorio' });
    }

    // Generar audio
    const audioBuffer = await TextToSpeechService.textToSpeech(text, language, voiceType, voiceSpeed);
    
    // En una implementación real, guardaríamos el audio en un almacenamiento
    // y devolveríamos la URL para acceder a él
    // Por ahora, simulamos una respuesta exitosa
    
    res.json({
      success: true,
      message: 'Audio generado correctamente',
      audioUrl: 'https://example.com/audio/generated.mp3', // URL simulada
      metadata: {
        text,
        language,
        voiceType,
        voiceSpeed
      }
    });
  } catch (err) {
    console.error('Error generando audio:', err.message);
    res.status(500).send('Error en el servidor');
  }
});

/**
 * @route   GET api/tts/voices
 * @desc    Obtener voces disponibles para un idioma
 * @access  Private
 */
router.get('/voices', auth, async (req, res) => {
  try {
    const { language = 'es' } = req.query;
    
    // Obtener voces disponibles
    const voices = TextToSpeechService.getAvailableVoices(language);
    
    res.json(voices);
  } catch (err) {
    console.error('Error obteniendo voces:', err.message);
    res.status(500).send('Error en el servidor');
  }
});

module.exports = router;
