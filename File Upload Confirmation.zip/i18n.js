const express = require('express');
const router = express.Router();
const I18nService = require('../services/I18nService');

/**
 * @route   GET api/i18n/languages
 * @desc    Obtener idiomas soportados
 * @access  Public
 */
router.get('/languages', (req, res) => {
  try {
    const languages = I18nService.getSupportedLanguages();
    res.json({
      default: I18nService.getDefaultLanguage(),
      supported: languages
    });
  } catch (err) {
    console.error('Error obteniendo idiomas:', err.message);
    res.status(500).send(I18nService.translate('errors.serverError', 'es'));
  }
});

/**
 * @route   GET api/i18n/detect
 * @desc    Detectar idioma preferido del usuario
 * @access  Public
 */
router.get('/detect', (req, res) => {
  try {
    const acceptLanguage = req.header('Accept-Language');
    const detectedLanguage = I18nService.detectLanguage(acceptLanguage);
    
    res.json({
      detected: detectedLanguage,
      acceptLanguageHeader: acceptLanguage || 'No proporcionado'
    });
  } catch (err) {
    console.error('Error detectando idioma:', err.message);
    res.status(500).send(I18nService.translate('errors.serverError', 'es'));
  }
});

/**
 * @route   GET api/i18n/translations/:language
 * @desc    Obtener traducciones para un idioma específico
 * @access  Public
 */
router.get('/translations/:language', (req, res) => {
  try {
    const language = req.params.language;
    
    // Verificar si el idioma es soportado
    if (!I18nService.isSupported(language)) {
      return res.status(400).json({ 
        error: `Idioma ${language} no soportado`,
        supportedLanguages: I18nService.getSupportedLanguages()
      });
    }
    
    // Crear un objeto con las traducciones más comunes
    // En una implementación real, esto podría cargar traducciones desde archivos
    const translations = {
      errors: {
        serverError: I18nService.translate('errors.serverError', language),
        notFound: I18nService.translate('errors.notFound', language),
        unauthorized: I18nService.translate('errors.unauthorized', language),
        invalidCredentials: I18nService.translate('errors.invalidCredentials', language),
        fieldsRequired: I18nService.translate('errors.fieldsRequired', language)
      },
      success: {
        registered: I18nService.translate('success.registered', language),
        loggedIn: I18nService.translate('success.loggedIn', language),
        profileUpdated: I18nService.translate('success.profileUpdated', language)
      },
      pnl: {
        welcomeMessage: I18nService.translate('pnl.welcomeMessage', language),
        exerciseIntro: I18nService.translate('pnl.exerciseIntro', language),
        journalPrompt: I18nService.translate('pnl.journalPrompt', language)
      }
    };
    
    res.json(translations);
  } catch (err) {
    console.error('Error obteniendo traducciones:', err.message);
    res.status(500).send(I18nService.translate('errors.serverError', 'es'));
  }
});

module.exports = router;
