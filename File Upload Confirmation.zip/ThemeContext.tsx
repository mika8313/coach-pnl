import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useColorScheme } from 'react-native';

// Definición de colores para el tema zen
const lightTheme = {
  background: '#F6FFF8', // zen-cream
  card: '#FFFFFF',
  text: '#495057', // neutral-darkest
  border: '#CAD2C5', // zen-gray
  primary: '#84A98C', // zen-green
  secondary: '#A4C3B2', // zen-blue
  accent: '#52796F', // zen-dark
  error: '#D62828',
  success: '#2A9D8F',
  warning: '#E9C46A',
  info: '#219EBC',
  disabled: '#ADB5BD', // neutral-dark
  placeholder: '#DEE2E6', // neutral-medium
};

// Versión oscura del tema zen
const darkTheme = {
  background: '#2F3E46',
  card: '#354F52',
  text: '#F6FFF8', // zen-cream
  border: '#52796F', // zen-dark
  primary: '#84A98C', // zen-green
  secondary: '#A4C3B2', // zen-blue
  accent: '#CAD2C5', // zen-gray
  error: '#E63946',
  success: '#2A9D8F',
  warning: '#F4A261',
  info: '#219EBC',
  disabled: '#6C757D',
  placeholder: '#495057',
};

// Tipos para el contexto del tema
type ThemeType = typeof lightTheme;

interface ThemeContextType {
  theme: ThemeType;
  isDark: boolean;
  toggleTheme: () => void;
}

// Creación del contexto
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Props para el proveedor del tema
interface ThemeProviderProps {
  children: ReactNode;
}

// Proveedor del tema
export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  // Detectar el esquema de color del sistema
  const colorScheme = useColorScheme();
  const [isDark, setIsDark] = useState<boolean>(colorScheme === 'dark');
  const theme = isDark ? darkTheme : lightTheme;

  // Función para cambiar entre temas
  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  return (
    <ThemeContext.Provider value={{ theme, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Hook personalizado para usar el tema
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme debe ser usado dentro de un ThemeProvider');
  }
  return context;
};
